' Dev-Cut - double-click to open (no console window)
Set fso = CreateObject("Scripting.FileSystemObject")
base = fso.GetParentFolderName(WScript.ScriptFullName)
cmd = "conhost.exe --headless powershell -NoProfile -ExecutionPolicy Bypass -File """ & base & "\launcher\run.ps1"""
CreateObject("WScript.Shell").Run cmd, 0, False
