﻿# Dev-Cut Launcher — โปรแกรมหลัก พร้อมช่องแชทในตัว (ภาษาไทยแสดงผลสมบูรณ์)
Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase

Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public class DevCutNative {
    [DllImport("shell32.dll", SetLastError=true)]
    public static extern int SetCurrentProcessExplicitAppUserModelID(
        [MarshalAs(UnmanagedType.LPWStr)] string AppID);
    [DllImport("user32.dll", SetLastError=true, CharSet=CharSet.Unicode)]
    public static extern IntPtr FindWindow(string lpClassName, string lpWindowName);
    [DllImport("user32.dll")]
    public static extern bool SetForegroundWindow(IntPtr hWnd);
    [DllImport("user32.dll")]
    public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
    [DllImport("user32.dll")]
    public static extern bool IsIconic(IntPtr hWnd);
}
"@
[DevCutNative]::SetCurrentProcessExplicitAppUserModelID("DevCut.Launcher") | Out-Null

# ---------- กันเปิดซ้อนหลายหน้าต่าง (single instance) ----------
# เปิดครั้งแรกจองชื่อ mutex ไว้ ครั้งต่อไปถ้าเจอว่ามีอยู่แล้ว = มี Dev-Cut เปิดค้างอยู่
# → ดึงหน้าต่างเดิมขึ้นมาโฟกัส แล้วปิดตัวใหม่ทิ้ง (ไม่เปิดหน้าต่างซ้อน)
$createdNew = $false
$script:SingleInstanceMutex = New-Object System.Threading.Mutex(
    $true, "Local\DevCutLauncherSingleInstance", [ref]$createdNew)
if (-not $createdNew) {
    $SW_RESTORE = 9
    $hWnd = [DevCutNative]::FindWindow($null, "Dev-Cut")
    if ($hWnd -ne [IntPtr]::Zero) {
        # ถ้าย่อไว้ (minimized) คืนขนาดก่อน แล้วดึงมาอยู่หน้าสุด
        if ([DevCutNative]::IsIconic($hWnd)) { [DevCutNative]::ShowWindow($hWnd, $SW_RESTORE) | Out-Null }
        [DevCutNative]::SetForegroundWindow($hWnd) | Out-Null
    }
    exit
}

$KitRoot = Split-Path -Parent $PSScriptRoot
$LogoPath = Join-Path $KitRoot "logo.png"
$IconPath = Join-Path $PSScriptRoot "logo.ico"

[xml]$Xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Dev-Cut" Width="900" Height="720" WindowStartupLocation="CenterScreen"
        Background="#111318" FontFamily="LINE Seed Sans TH, Segoe UI">
  <Window.Resources>
    <Style x:Key="Btn" TargetType="Button">
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="Foreground" Value="#e2e8f0"/>
      <Setter Property="Background" Value="#23262f"/>
      <Setter Property="FontSize" Value="13"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="Button">
            <Border x:Name="bd" Background="{TemplateBinding Background}" CornerRadius="10"
                    Padding="{TemplateBinding Padding}">
              <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsMouseOver" Value="True">
                <Setter TargetName="bd" Property="Opacity" Value="0.82"/>
              </Trigger>
              <Trigger Property="IsEnabled" Value="False">
                <Setter TargetName="bd" Property="Opacity" Value="0.4"/>
              </Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>
    <Style x:Key="Pill" TargetType="Border">
      <Setter Property="CornerRadius" Value="14"/>
      <Setter Property="Background" Value="#1a1d24"/>
      <Setter Property="Padding" Value="12,6"/>
      <Setter Property="Margin" Value="0,0,8,8"/>
    </Style>
  </Window.Resources>

  <Grid Margin="20">
    <Grid.RowDefinitions>
      <RowDefinition Height="Auto"/>
      <RowDefinition Height="Auto"/>
      <RowDefinition Height="Auto"/>
      <RowDefinition Height="*"/>
      <RowDefinition Height="Auto"/>
    </Grid.RowDefinitions>

    <Grid Grid.Row="0" Margin="0,0,0,12">
      <StackPanel Orientation="Horizontal">
        <Border CornerRadius="12" Background="White" Width="52" Height="52" Margin="0,0,12,0">
          <Image x:Name="LogoImg" Width="46" Height="46"/>
        </Border>
        <StackPanel VerticalAlignment="Center">
          <StackPanel Orientation="Horizontal">
            <TextBlock Text="Dev-" FontSize="26" FontWeight="Bold" Foreground="White"/>
            <TextBlock Text="Cut" FontSize="26" FontWeight="Bold" Foreground="#e11d48"/>
          </StackPanel>
          <TextBlock Text="โปรแกรมตัดต่อด้วย AI สำหรับ CapCut" FontSize="12" Foreground="#8b93a5"/>
        </StackPanel>
      </StackPanel>
      <StackPanel Orientation="Horizontal" HorizontalAlignment="Right" VerticalAlignment="Center">
        <Button x:Name="BtnInstall" Style="{StaticResource Btn}" Padding="10,7" Margin="0,0,6,0" Content="⚙ ติดตั้งครั้งแรก"/>
        <Button x:Name="BtnLogin" Style="{StaticResource Btn}" Padding="10,7" Margin="0,0,6,0" Content="🔗 เชื่อม Claude"/>
        <Button x:Name="BtnNew" Style="{StaticResource Btn}" Padding="10,7" Margin="0,0,6,0" Content="＋ แชทใหม่"/>
        <Button x:Name="BtnHelp" Style="{StaticResource Btn}" Padding="10,7" Margin="0,0,6,0" Content="ⓘ ฟีเจอร์"/>
        <Button x:Name="BtnRefresh" Style="{StaticResource Btn}" Padding="10,7" Content="⟳"/>
      </StackPanel>
    </Grid>

    <WrapPanel Grid.Row="1" Margin="0,0,0,8">
      <Border Style="{StaticResource Pill}"><TextBlock x:Name="StPython" Text="Python" Foreground="Gray" FontSize="12.5"/></Border>
      <Border Style="{StaticResource Pill}"><TextBlock x:Name="StFfmpeg" Text="ffmpeg" Foreground="Gray" FontSize="12.5"/></Border>
      <Border Style="{StaticResource Pill}"><TextBlock x:Name="StNode" Text="Node.js" Foreground="Gray" FontSize="12.5"/></Border>
      <Border Style="{StaticResource Pill}"><TextBlock x:Name="StClaude" Text="Claude Code" Foreground="Gray" FontSize="12.5"/></Border>
      <Border Style="{StaticResource Pill}"><TextBlock x:Name="StLibs" Text="ไลบรารี" Foreground="Gray" FontSize="12.5"/></Border>
      <Border Style="{StaticResource Pill}"><TextBlock x:Name="StFont" Text="ฟอนต์ LINE Seed" Foreground="Gray" FontSize="12.5"/></Border>
      <Border Style="{StaticResource Pill}"><TextBlock x:Name="StModel" Text="โมเดลถอดเสียง" Foreground="Gray" FontSize="12.5"/></Border>
      <Border Style="{StaticResource Pill}"><TextBlock x:Name="StVocal" Text="ตัวแยกเสียงพูด" Foreground="Gray" FontSize="12.5"/></Border>
    </WrapPanel>

    <WrapPanel Grid.Row="2" Margin="0,0,0,8">
      <Button x:Name="BtnPick" Style="{StaticResource Btn}" Padding="10,6" Margin="0,0,6,0"
              FontSize="12" Background="#2d3340" Content="📁 เลือกคลิป"/>
      <Button x:Name="BtnRecent" Style="{StaticResource Btn}" Padding="10,6" Margin="0,0,10,0"
              FontSize="12" Background="#2d3340" Content="🎞 คลิปล่าสุด ▾"/>
      <Button x:Name="ChipTikTok" Style="{StaticResource Btn}" Padding="10,6" Margin="0,0,6,0"
              FontSize="12" Content="🎬 ตัด+ซับ ลง TikTok"/>
      <Button x:Name="ChipYT" Style="{StaticResource Btn}" Padding="10,6" Margin="0,0,6,0"
              FontSize="12" Content="🎬 ตัด+ซับ ลง YouTube"/>
      <Button x:Name="ChipSub" Style="{StaticResource Btn}" Padding="10,6"
              FontSize="12" Content="💬 ใส่ซับอย่างเดียว"/>
    </WrapPanel>

    <Border Grid.Row="3" Background="#0a0c10" CornerRadius="12" Padding="14" Margin="0,0,0,10">
      <ScrollViewer x:Name="ChatScroll" VerticalScrollBarVisibility="Auto">
        <StackPanel x:Name="ChatPanel"/>
      </ScrollViewer>
    </Border>

    <Grid Grid.Row="4">
      <Grid.ColumnDefinitions>
        <ColumnDefinition Width="*"/>
        <ColumnDefinition Width="Auto"/>
      </Grid.ColumnDefinitions>
      <Border Grid.Column="0" Background="#1a1d24" CornerRadius="12" Padding="12,4" Margin="0,0,8,0">
        <TextBox x:Name="InputBox" Background="Transparent" BorderThickness="0" Foreground="White"
                 FontSize="14" VerticalContentAlignment="Center" MinHeight="40" MaxHeight="120"
                 TextWrapping="Wrap" AcceptsReturn="False" CaretBrush="White"/>
      </Border>
      <Button Grid.Column="1" x:Name="BtnSend" Style="{StaticResource Btn}"
              Background="#e11d48" Foreground="White" FontWeight="Bold" FontSize="14"
              Padding="22,10" Content="ส่ง ➤"/>
    </Grid>

    <!-- ป๊อปอัพฟีเจอร์ -->
    <Grid x:Name="HelpOverlay" Grid.RowSpan="5" Visibility="Collapsed" Background="#d9000000">
      <Border Background="#171a21" CornerRadius="14" MaxWidth="600" MaxHeight="560"
              Padding="18" VerticalAlignment="Center" HorizontalAlignment="Center"
              BorderBrush="#2d3340" BorderThickness="1">
        <Grid>
          <Grid.RowDefinitions>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="*"/>
          </Grid.RowDefinitions>
          <Grid Grid.Row="0" Margin="0,0,0,10">
            <TextBlock Text="ฟีเจอร์ทั้งหมดของ Dev-Cut" FontSize="17" FontWeight="Bold" Foreground="White"/>
            <Button x:Name="BtnHelpClose" Style="{StaticResource Btn}" Padding="10,4"
                    HorizontalAlignment="Right" Content="✕ ปิด"/>
          </Grid>
          <ScrollViewer Grid.Row="1" VerticalScrollBarVisibility="Auto">
            <StackPanel x:Name="HelpList"/>
          </ScrollViewer>
        </Grid>
      </Border>
    </Grid>

    <!-- หน้าเลือกสไตล์ซับ (เห็นภาพจริง) -->
    <Grid x:Name="StyleOverlay" Grid.RowSpan="5" Visibility="Collapsed" Background="#d9000000">
      <Border Background="#171a21" CornerRadius="14" MaxWidth="760"
              Padding="22" VerticalAlignment="Center" HorizontalAlignment="Center"
              BorderBrush="#2d3340" BorderThickness="1">
        <StackPanel>
          <Grid Margin="0,0,0,4">
            <TextBlock Text="เลือกสไตล์ซับ" FontSize="18" FontWeight="Bold" Foreground="White" VerticalAlignment="Center"/>
            <StackPanel Orientation="Horizontal" HorizontalAlignment="Right">
              <Button x:Name="BtnStyleBack" Style="{StaticResource Btn}" Padding="10,4" Margin="0,0,6,0" Content="← กลับ"/>
              <Button x:Name="BtnStyleClose" Style="{StaticResource Btn}" Padding="10,4" Content="✕ ปิด"/>
            </StackPanel>
          </Grid>
          <TextBlock Text="ทุกสไตล์ export ได้ฟรี · มี karaoke ไฮไลต์คำในตัว (ลากแก้ต่อใน CapCut ได้)"
                     FontSize="12.5" Foreground="#8b93a5" Margin="0,0,0,16"/>
          <StackPanel x:Name="StyleCards" Orientation="Horizontal" HorizontalAlignment="Center"/>
          <StackPanel Orientation="Horizontal" HorizontalAlignment="Center" Margin="0,18,0,0">
            <TextBlock Text="สีไฮไลต์คำ:" Foreground="#cbd5e1" FontSize="13.5" VerticalAlignment="Center" Margin="0,0,12,0"/>
            <StackPanel x:Name="ColorRow" Orientation="Horizontal"/>
          </StackPanel>
        </StackPanel>
      </Border>
    </Grid>

    <!-- หน้าเลือกแบบกราฟิก -->
    <Grid x:Name="GfxOverlay" Grid.RowSpan="5" Visibility="Collapsed" Background="#d9000000">
      <Border Background="#171a21" CornerRadius="14" MaxWidth="760"
              Padding="22" VerticalAlignment="Center" HorizontalAlignment="Center"
              BorderBrush="#2d3340" BorderThickness="1">
        <StackPanel>
          <Grid Margin="0,0,0,4">
            <TextBlock Text="เลือกแบบกราฟิก" FontSize="18" FontWeight="Bold" Foreground="White" VerticalAlignment="Center"/>
            <StackPanel Orientation="Horizontal" HorizontalAlignment="Right">
              <Button x:Name="BtnGfxBack" Style="{StaticResource Btn}" Padding="10,4" Margin="0,0,6,0" Content="← กลับ"/>
              <Button x:Name="BtnGfxClose" Style="{StaticResource Btn}" Padding="10,4" Content="✕ ปิด"/>
            </StackPanel>
          </Grid>
          <TextBlock Text="เลือกแบบ แล้วพิมพ์ข้อความที่อยากได้ในช่องแชท (ฟอนต์ LINE Seed · ฟรี)"
                     FontSize="12.5" Foreground="#8b93a5" Margin="0,0,0,16"/>
          <WrapPanel x:Name="GfxCards" HorizontalAlignment="Center" MaxWidth="700"/>
        </StackPanel>
      </Border>
    </Grid>

    <!-- หน้าเลือกเสียง SFX (มีปุ่มฟัง) -->
    <Grid x:Name="SfxOverlay" Grid.RowSpan="5" Visibility="Collapsed" Background="#d9000000">
      <Border Background="#171a21" CornerRadius="14" MaxWidth="560"
              Padding="22" VerticalAlignment="Center" HorizontalAlignment="Center"
              BorderBrush="#2d3340" BorderThickness="1">
        <StackPanel>
          <Grid Margin="0,0,0,4">
            <TextBlock Text="เลือกเสียงประกอบ" FontSize="18" FontWeight="Bold" Foreground="White" VerticalAlignment="Center"/>
            <StackPanel Orientation="Horizontal" HorizontalAlignment="Right">
              <Button x:Name="BtnSfxBack" Style="{StaticResource Btn}" Padding="10,4" Margin="0,0,6,0" Content="← กลับ"/>
              <Button x:Name="BtnSfxClose" Style="{StaticResource Btn}" Padding="10,4" Content="✕ ปิด"/>
            </StackPanel>
          </Grid>
          <TextBlock Text="กด ▶ ฟังก่อนเลือก · เสียงในกล่อง 18 เสียง ไม่ติดลิขสิทธิ์ ใช้ขายได้"
                     FontSize="12.5" Foreground="#8b93a5" Margin="0,0,0,14"/>
          <ScrollViewer MaxHeight="420" VerticalScrollBarVisibility="Auto">
            <StackPanel x:Name="SfxList"/>
          </ScrollViewer>
        </StackPanel>
      </Border>
    </Grid>
  </Grid>
</Window>
"@

$Reader = New-Object System.Xml.XmlNodeReader $Xaml
$Win = [Windows.Markup.XamlReader]::Load($Reader)
$C = @{}
foreach ($name in @("StPython","StFfmpeg","StNode","StClaude","StLibs","StFont","StModel","StVocal",
                    "BtnInstall","BtnLogin","BtnNew","BtnRefresh","ChipTikTok","ChipYT","ChipSub",
                    "BtnPick","BtnRecent","BtnHelp","BtnHelpClose","HelpOverlay","HelpList",
                    "BtnStyleBack","BtnStyleClose","StyleOverlay","StyleCards","ColorRow",
                    "BtnGfxBack","BtnGfxClose","GfxOverlay","GfxCards",
                    "BtnSfxBack","BtnSfxClose","SfxOverlay","SfxList",
                    "LogoImg","ChatScroll","ChatPanel","InputBox","BtnSend")) {
    $C[$name] = $Win.FindName($name)
}

# โลโก้ + ไอคอน
$LogoTight = Join-Path $PSScriptRoot "logo_tight.png"
$logoShow = if (Test-Path $LogoTight) { $LogoTight } else { $LogoPath }
if (Test-Path $logoShow) {
    try {
        $bmp = New-Object System.Windows.Media.Imaging.BitmapImage
        $bmp.BeginInit(); $bmp.UriSource = [Uri]$logoShow; $bmp.EndInit()
        $C.LogoImg.Source = $bmp
    } catch { }
}
try {
    # ใช้ PNG (ครอปแล้ว) เป็นไอคอนหน้าต่าง/taskbar — WPF อ่าน .ico หลายขนาดไม่เสถียร
    if (Test-Path $logoShow) {
        $ico = New-Object System.Windows.Media.Imaging.BitmapImage
        $ico.BeginInit(); $ico.UriSource = [Uri]$logoShow; $ico.EndInit()
        $Win.Icon = $ico
    }
} catch { }

# ---------- ประวัติแชท (คงอยู่ข้ามการปิด-เปิดโปรแกรม) ----------

$script:HistFile = Join-Path $PSScriptRoot "chat-history.jsonl"
function SaveHist($w, $t) {
    try {
        (@{ w = $w; t = $t } | ConvertTo-Json -Compress) |
            Out-File $script:HistFile -Append -Encoding utf8
    } catch { }
}

# ---------- log ถาวร (ดูย้อนหลัง/แนบตอนแจ้งปัญหาได้) ----------

$script:AppLog = Join-Path $PSScriptRoot "app.log"
function LogFile($m) {
    try {
        ("[{0}] {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $m) |
            Out-File $script:AppLog -Append -Encoding utf8
    } catch { }
}
LogFile "===== เปิดโปรแกรม ====="

# ---------- chat UI ----------

function AddBubble($who, $text, $color, $bg) {
    $bd = New-Object System.Windows.Controls.Border
    $bd.CornerRadius = "10"; $bd.Padding = "12,8"; $bd.Margin = "0,0,0,8"
    $bd.Background = New-Object System.Windows.Media.SolidColorBrush(
        [System.Windows.Media.ColorConverter]::ConvertFromString($bg))
    $sp = New-Object System.Windows.Controls.StackPanel
    if ($who) {
        $h = New-Object System.Windows.Controls.TextBlock
        $h.Text = $who; $h.FontSize = 11; $h.FontWeight = "Bold"
        $h.Foreground = New-Object System.Windows.Media.SolidColorBrush(
            [System.Windows.Media.ColorConverter]::ConvertFromString($color))
        $h.Margin = "0,0,0,3"
        $sp.Children.Add($h) | Out-Null
    }
    # ใช้ TextBox แบบอ่านอย่างเดียว → ลากเมาส์เลือก/คัดลอกข้อความได้
    $tb = New-Object System.Windows.Controls.TextBox
    $tb.Text = $text; $tb.TextWrapping = "Wrap"; $tb.FontSize = 13.5
    $tb.IsReadOnly = $true
    $tb.BorderThickness = "0"
    $tb.Background = [System.Windows.Media.Brushes]::Transparent
    $tb.Padding = "0"
    $tb.IsTabStop = $false
    $tb.Foreground = New-Object System.Windows.Media.SolidColorBrush(
        [System.Windows.Media.ColorConverter]::ConvertFromString("#e2e8f0"))
    $sp.Children.Add($tb) | Out-Null
    $bd.Child = $sp
    $C.ChatPanel.Children.Add($bd) | Out-Null
    # ก้อนสถานะโหลดดิ้งให้ลอยอยู่ล่างสุดเสมอ
    if ($script:BusyTb) {
        try {
            $bb = $script:BusyTb.Parent.Parent
            if ($bb -and ($bb -ne $bd)) {
                $C.ChatPanel.Children.Remove($bb) | Out-Null
                $C.ChatPanel.Children.Add($bb) | Out-Null
            }
        } catch { }
    }
    ScrollSmart
    return $tb
}

# แถบคำถามเด่นสีแดง — โผล่เมื่อ AI ถามผู้ใช้ ให้เห็นชัดว่าต้องตอบ
function AddQuestion($text) {
    $bd = New-Object System.Windows.Controls.Border
    $bd.CornerRadius = "10"; $bd.Padding = "14,10"; $bd.Margin = "0,2,0,10"
    $bd.Background = New-Object System.Windows.Media.SolidColorBrush(
        [System.Windows.Media.ColorConverter]::ConvertFromString("#3a0d16"))
    $bd.BorderBrush = New-Object System.Windows.Media.SolidColorBrush(
        [System.Windows.Media.ColorConverter]::ConvertFromString("#e11d48"))
    $bd.BorderThickness = "2"
    $sp = New-Object System.Windows.Controls.StackPanel
    $h = New-Object System.Windows.Controls.TextBlock
    $h.Text = "❓ Dev-Cut ถามคุณ — พิมพ์ตอบในช่องด้านล่างได้เลย"
    $h.FontSize = 11.5; $h.FontWeight = "Bold"; $h.Margin = "0,0,0,4"
    $h.Foreground = New-Object System.Windows.Media.SolidColorBrush(
        [System.Windows.Media.ColorConverter]::ConvertFromString("#f87171"))
    $tb = New-Object System.Windows.Controls.TextBox
    $tb.Text = $text; $tb.TextWrapping = "Wrap"; $tb.FontSize = 14.5
    $tb.FontWeight = "Bold"; $tb.IsReadOnly = $true; $tb.BorderThickness = "0"
    $tb.Background = [System.Windows.Media.Brushes]::Transparent; $tb.IsTabStop = $false
    $tb.Foreground = [System.Windows.Media.Brushes]::White
    $sp.Children.Add($h) | Out-Null; $sp.Children.Add($tb) | Out-Null
    $bd.Child = $sp
    $C.ChatPanel.Children.Add($bd) | Out-Null
    $C.ChatScroll.ScrollToEnd()
    $C.InputBox.Focus() | Out-Null
}

function DetectQuestions($text) {
    if (-not $text) { return }
    $qs = @()
    foreach ($ln in ($text -split "`n")) {
        $lt = $ln.Trim()
        if ($lt -match '^❓\s*(.+)$') { $qs += $Matches[1] }
    }
    if ($qs.Count -eq 0) {
        $last = (@($text -split "`n") | Where-Object { $_.Trim() } | Select-Object -Last 1)
        if ($last -and ($last.Trim() -match '(\?|ไหม\s*(ครับ|คะ|นะ)?[\s\?]*)$')) { $qs += $last.Trim() }
    }
    foreach ($q in $qs) { AddQuestion $q }
}

# เลื่อนลงล่างเฉพาะเมื่อผู้ใช้อยู่แถวล่างอยู่แล้ว — ถ้าเลื่อนขึ้นไปอ่าน จะไม่ดึงจอ
function ScrollSmart {
    try {
        $sv = $C.ChatScroll
        if (($sv.VerticalOffset + $sv.ViewportHeight) -ge ($sv.ExtentHeight - 80)) {
            $sv.ScrollToEnd()
        }
    } catch { }
}

function SysMsg($text) {
    AddBubble $null $text "#8b93a5" "#161a22" | Out-Null
    LogFile $text
}

function Has($cmd) { [bool](Get-Command $cmd -ErrorAction SilentlyContinue) }

function ClaudeCmd {
    if (Has "claude") { return "claude" }
    $p = Join-Path $env:APPDATA "npm\claude.cmd"     # ติดตั้งใหม่ใน session นี้ PATH ยังไม่รู้จัก
    if (Test-Path $p) { return "`"$p`"" }
    return $null
}

function HasFont {
    foreach ($d in @("$env:LOCALAPPDATA\Microsoft\Windows\Fonts", "C:\Windows\Fonts")) {
        if (Test-Path $d) {
            $f = Get-ChildItem $d -ErrorAction SilentlyContinue |
                 Where-Object { ($_.Name -replace '\s','') -match 'LINESeed.*TH' -and $_.Length -gt 10000 }
            if ($f) { return $true }
        }
    }
    return $false
}

function HasLibs {
    $py = Join-Path $KitRoot ".venv\Scripts\python.exe"
    if (-not (Test-Path $py)) { $py = "python" }
    try {
        & $py -c "import pycapcut, pythainlp" 2>$null
        return ($LASTEXITCODE -eq 0)
    } catch { return $false }
}

function InjectVenvPath($psi) {
    # เติม .venv\Scripts หน้า PATH ของ process ลูก — ทำให้ `python` ใน skill = python ของ .venv
    # (lib อย่าง pycapcut/pythainlp อยู่ใน .venv) skill ไม่ต้องรู้ path เอง ลูกค้ารันครั้งแรกไม่พัง
    $venvScripts = Join-Path $KitRoot ".venv\Scripts"
    if (Test-Path $venvScripts) {
        $cur = $psi.EnvironmentVariables["PATH"]
        $psi.EnvironmentVariables["PATH"] = "$venvScripts;$cur"
    }
}

function SetStatus($ctrl, $ok, $label) {
    if ($ok) { $ctrl.Text = "✓ $label"; $ctrl.Foreground = "#4ade80" }
    else     { $ctrl.Text = "✗ $label"; $ctrl.Foreground = "#f87171" }
}

function Refresh {
    SetStatus $C.StPython (Has "python") "Python"
    SetStatus $C.StFfmpeg (Has "ffmpeg") "ffmpeg"
    SetStatus $C.StNode   ((Has "node") -or (Test-Path "$env:ProgramFiles\nodejs\node.exe")) "Node.js"
    SetStatus $C.StClaude ([bool](ClaudeCmd)) "Claude Code"
    SetStatus $C.StLibs   (HasLibs)      "ไลบรารี"
    SetStatus $C.StFont   (HasFont)      "ฟอนต์ LINE Seed"
    $modelDir = Join-Path $KitRoot "models\hub"
    $hasModel = (Test-Path $modelDir) -and
                ((Get-ChildItem $modelDir -Directory -ErrorAction SilentlyContinue |
                  Where-Object { $_.Name -match "whisper" }).Count -gt 0)
    SetStatus $C.StModel $hasModel "โมเดลถอดเสียง"
    SetStatus $C.StVocal (Test-Path (Join-Path $KitRoot ".venv\Lib\site-packages\demucs")) "ตัวแยกเสียงพูด"
}

# ---------- ส่งข้อความให้ Claude (เบื้องหลัง, stream) ----------

$script:Proc = $null
$script:FirstMsg = $true
$script:CurBubble = $null
$script:CurText = ""

$script:OutFile = Join-Path $env:TEMP "devcut_out.jsonl"
$script:ErrFile = Join-Path $env:TEMP "devcut_err.txt"
$script:LineDone = 0
$script:GotText = $false
$script:BusyTb = $null
$script:TickN = 0
$script:WorkStart = Get-Date

function FmtDur($sec) {
    if ($sec -lt 60) { return "$sec วิ" }
    return "{0}:{1:d2} นาที" -f [int][math]::Floor($sec / 60), ($sec % 60)
}

$script:ProgFile = Join-Path $env:TEMP "devcut_progress.txt"
function ReadProgress {
    try {
        if (-not (Test-Path $script:ProgFile)) { return $null }
        $fi = Get-Item $script:ProgFile
        if (((Get-Date) - $fi.LastWriteTime).TotalSeconds -gt 30) { return $null }  # ข้อมูลเก่า
        $line = Get-Content $script:ProgFile -Tail 1 -Encoding UTF8 -ErrorAction SilentlyContinue
        if (-not $line) { return $null }
        $parts = ([string]$line) -split '\|', 2
        $pct = 0
        if (-not [int]::TryParse($parts[0], [ref]$pct)) { return $null }
        $filled = [math]::Min(10, [math]::Max(0, [int][math]::Round($pct / 10)))
        $bar = ("▰" * $filled) + ("▱" * (10 - $filled))
        $label = ""
        if ($parts.Count -gt 1) { $label = " " + $parts[1] }
        return "$bar $pct%$label"
    } catch { return $null }
}

function SetBusy($busy) {
    if ($busy) {
        $C.BtnSend.Content = "หยุด ■"
        $C.BtnSend.Background = New-Object System.Windows.Media.SolidColorBrush(
            [System.Windows.Media.ColorConverter]::ConvertFromString("#475569"))
    } else {
        $C.BtnSend.Content = "ส่ง ➤"
        $C.BtnSend.Background = New-Object System.Windows.Media.SolidColorBrush(
            [System.Windows.Media.ColorConverter]::ConvertFromString("#e11d48"))
        $C.InputBox.Focus() | Out-Null
    }
}

function StopWork {
    if ($script:Proc -and -not $script:Proc.HasExited) {
        try {
            $psi = New-Object System.Diagnostics.ProcessStartInfo
            $psi.FileName = "taskkill.exe"
            $psi.Arguments = "/PID $($script:Proc.Id) /T /F"
            $psi.UseShellExecute = $false
            $psi.CreateNoWindow = $true
            $kp = [System.Diagnostics.Process]::Start($psi)
            $kp.WaitForExit(3000) | Out-Null
        } catch { }
        if ($script:BusyTb) { $script:BusyTb.Text = "⏹ หยุดโดยผู้ใช้"; $script:BusyTb = $null }
        SysMsg "⏹ หยุดงานแล้ว — พิมพ์คำสั่งใหม่ได้เลย (งานที่ทำไปแล้วไม่หาย ไฟล์ต้นฉบับปลอดภัยเสมอ)"
    }
}

function HandleLine($line) {
    if (-not $line) { return }
    $obj = $null
    try { $obj = $line | ConvertFrom-Json } catch { return }
    if ($obj.type -eq "assistant" -and $obj.message.content) {
        foreach ($part in $obj.message.content) {
            if ($part.type -eq "text" -and $part.text) {
                if (-not $script:CurBubble) {
                    $script:CurText = ""
                    $script:CurBubble = AddBubble "Dev-Cut" "" "#e11d48" "#1c1017"
                }
                $script:GotText = $true
                $script:CurText += $part.text
                $script:CurBubble.Text = $script:CurText.Trim()
                ScrollSmart
            } elseif ($part.type -eq "tool_use") {
                # ไม่สร้างก้อนใหม่ — อัปเดตสถานะในก้อนโหลดดิ้งก้อนเดียว (กันแชทท่วม)
                if ($script:CurText.Trim()) { SaveHist "Dev-Cut" $script:CurText.Trim() }
                $script:CurBubble = $null
                $script:ToolCount++
                $script:StepStart = Get-Date
                $desc = ""
                if ($part.input -and $part.input.description) { $desc = ": " + $part.input.description }
                $script:CurTool = $part.name + $desc
                LogFile ("ขั้นที่ $($script:ToolCount): " + $script:CurTool)
            }
        }
    } elseif ($obj.type -eq "result") {
        $script:CurBubble = $null
        if ($obj.is_error -and $obj.result) { SysMsg ("เกิดข้อผิดพลาด: " + $obj.result) }
    }
}

# ตัวจับเวลาอ่านผลจากไฟล์ (เลี่ยงปัญหา event ไม่ทำงานระหว่างหน้าต่างเปิด)
$ChatTimer = New-Object System.Windows.Threading.DispatcherTimer
$ChatTimer.Interval = [TimeSpan]::FromMilliseconds(250)
$ChatTimer.Add_Tick({
  try {
    $alive = ($script:Proc -and -not $script:Proc.HasExited)

    # โหลดดิ้ง: จุดวิ่ง + เวลา + ขั้นตอนล่าสุด (อัปเดตในก้อนเดียว ไม่สร้างก้อนใหม่)
    if ($alive -and $script:BusyTb) {
        $script:TickN = ($script:TickN + 1) % 4
        $dots = "." * ($script:TickN + 1)
        $sec = [int]((Get-Date) - $script:WorkStart).TotalSeconds
        $status = "⏳ กำลังทำงาน$dots (รวม $(FmtDur $sec))"
        if ($script:CurTool) {
            $stepSec = [int]((Get-Date) - $script:StepStart).TotalSeconds
            $status += "`n⚙ ขั้นที่ $($script:ToolCount) · " + $script:CurTool +
                       "  (ขั้นนี้ $(FmtDur $stepSec))"
            # หลอดความคืบหน้าจริงจากสคริปต์ (เช่นถอดเสียง) ถ้ามีไฟล์รายงานสด
            $prog = ReadProgress
            if ($prog) { $status += "`n$prog" }
            elseif ($stepSec -gt 120) {
                $status += "`n⏱ ขั้นตอนนี้ใช้เวลานานได้เป็นปกติ (เช่นถอดเสียงด้วย CPU) — ยังทำงานอยู่"
            }
        }
        $script:BusyTb.Text = $status
    }

    $lines = @()
    if (Test-Path $script:OutFile) {
        try { $lines = @(Get-Content $script:OutFile -Encoding UTF8 -ErrorAction SilentlyContinue) } catch { }
    }
    # ระหว่างรัน: เว้นบรรทัดสุดท้ายไว้ (อาจเขียนไม่จบ) / จบแล้ว: เก็บให้หมด
    $upTo = if ($alive) { $lines.Count - 1 } else { $lines.Count }
    while ($script:LineDone -lt $upTo) {
        HandleLine $lines[$script:LineDone]
        $script:LineDone++
    }
    if (-not $alive) {
        $ChatTimer.Stop()
        SetBusy $false
        $sec = [int]((Get-Date) - $script:WorkStart).TotalSeconds
        # เก็บ stderr ลง log เสมอ (แม้งานสำเร็จ) เผื่อใช้ตามรอยปัญหา
        $err = ""
        if (Test-Path $script:ErrFile) {
            try {
                $raw = Get-Content $script:ErrFile -Raw -Encoding UTF8
                if ($raw) { $err = [string]$raw }   # ไฟล์ว่าง Get-Content คืน null — กัน .Trim() พัง
            } catch { }
        }
        if ($err.Trim()) { LogFile ("STDERR: " + $err.Trim()) }
        if ($script:GotText) {
            if ($script:CurText.Trim()) { SaveHist "Dev-Cut" $script:CurText.Trim() }
            DetectQuestions $script:CurText
            if ($script:BusyTb) {
                $steps = ""
                if ($script:ToolCount -gt 0) { $steps = " · $($script:ToolCount) ขั้นตอน" }
                $script:BusyTb.Text = "✓ เสร็จแล้ว ($(FmtDur $sec)$steps)"
            }
            LogFile "งานเสร็จ ($sec วินาที, $($script:ToolCount) ขั้นตอน)"
        } else {
            if ($script:BusyTb) { $script:BusyTb.Text = "✗ งานไม่สำเร็จ ($sec วินาที)" }
            if ($err -match "login|auth|credential|API key") {
                SysMsg "ยังไม่ได้ล็อกอิน Claude — เปิดหน้าต่างล็อกอินให้แล้ว พิมพ์ /login แล้วทำตามขั้นตอน (ครั้งเดียวเท่านั้น) เสร็จแล้วปิดหน้าต่างนั้นและกลับมาแชทต่อ"
                Start-Process cmd -ArgumentList "/k","cd /d `"$KitRoot`" && claude" -WorkingDirectory $KitRoot
            } elseif ($err.Trim()) {
                SysMsg ("ผิดพลาด: " + $err.Trim().Substring(0, [Math]::Min(300, $err.Trim().Length)) +
                        "  (log เต็ม: launcher\app.log)")
            } else {
                SysMsg "ไม่มีคำตอบกลับมา — ลองส่งใหม่ หรือดู launcher\app.log"
            }
        }
        $script:BusyTb = $null
    }
  } catch {
    LogFile ("chat tick error: " + $_.Exception.Message)
  }
})

function SendMsg {
    $text = $C.InputBox.Text.Trim()
    if (-not $text) { return }
    # คำสั่งพิเศษ: ใส่ API key → เปิด .env ให้เลย ไม่ต้องถาม AI
    if ($text -match '^(ใส่|เพิ่ม|แก้)?\s*(api\s*key|key|คีย์)\s*$') {
        $envFile = Join-Path $KitRoot ".env"
        if (-not (Test-Path $envFile)) { Copy-Item (Join-Path $KitRoot ".env.example") $envFile }
        Start-Process notepad $envFile
        SysMsg "เปิดไฟล์ตั้งค่า key ใน Notepad ให้แล้ว — ใส่แล้วกด Save (ไม่ใส่ก็ใช้งานได้)"
        $C.InputBox.Text = ""
        return
    }
    $cc = ClaudeCmd
    if (-not $cc) { SysMsg "ยังไม่ได้ติดตั้ง Claude Code — กดปุ่ม '⚙ ติดตั้งครั้งแรก' มุมขวาบน"; return }
    if ($script:Proc -and -not $script:Proc.HasExited) { return }
    $C.InputBox.Text = ""
    AddBubble "คุณ" $text "#60a5fa" "#141c2b" | Out-Null
    SaveHist "คุณ" $text
    LogFile ("ผู้ใช้: " + $text)
    SetBusy $true
    $script:WorkStart = Get-Date
    $script:StepStart = Get-Date
    $script:CurTool = ""
    $script:ToolCount = 0
    Remove-Item $script:ProgFile -ErrorAction SilentlyContinue
    $script:BusyTb = AddBubble $null "⏳ กำลังทำงาน..." "#f59e0b" "#161a22"
    $script:CurBubble = $null
    $script:CurText = ""
    $script:GotText = $false
    $script:LineDone = 0
    Remove-Item $script:OutFile, $script:ErrFile -ErrorAction SilentlyContinue

    $safe = $text -replace '"', "'"
    # อนุญาตเครื่องมือของ kit ตั้งแต่บรรทัดคำสั่ง — โหมดแชทไม่มีหน้าจอให้กด Yes
    $flags = "--output-format stream-json --verbose " +
             "--allowedTools `"Bash,Read,Edit,Write,Glob,Grep,WebFetch,WebSearch,Skill,TodoWrite`""
    if (-not $script:FirstMsg) { $flags += " --continue" }
    $script:FirstMsg = $false

    # ขยายเพดานเวลารันคำสั่งของ Claude Code เป็น 2 ชม. — งานถอดเสียงยาวไม่โดนฆ่ากลางทาง
    $cmdLine = "/d /c chcp 65001 >nul 2>&1 && " +
               "set BASH_DEFAULT_TIMEOUT_MS=1800000&& set BASH_MAX_TIMEOUT_MS=7200000&& " +
               "$cc -p `"$safe`" $flags " +
               ">`"$($script:OutFile)`" 2>`"$($script:ErrFile)`""
    # CreateNoWindow = ไม่สร้าง console เลย (กัน Windows Terminal เด้งหน้าต่างทั้งที่สั่งซ่อน)
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = "cmd.exe"
    $psi.Arguments = $cmdLine
    $psi.WorkingDirectory = $KitRoot
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    InjectVenvPath $psi
    $script:Proc = [System.Diagnostics.Process]::Start($psi)
    $ChatTimer.Start()
}

$C.BtnSend.Add_Click({
    if ($script:Proc -and -not $script:Proc.HasExited) { StopWork } else { SendMsg }
})
$C.InputBox.Add_KeyDown({
    param($s, $e)
    if ($e.Key -eq "Return") {
        if (-not ($script:Proc -and -not $script:Proc.HasExited)) { SendMsg }
        $e.Handled = $true
    }
})

# Ctrl+V รูปจากคลิปบอร์ด → เซฟเป็นไฟล์ แล้วแนบ path ให้ AI เปิดดู
$C.InputBox.Add_PreviewKeyDown({
    param($s, $e)
    if ($e.Key -eq "V" -and
        ([System.Windows.Input.Keyboard]::Modifiers -band [System.Windows.Input.ModifierKeys]::Control)) {
        if ([System.Windows.Clipboard]::ContainsImage()) {
            try {
                $img = [System.Windows.Clipboard]::GetImage()
                $dir = Join-Path $KitRoot "work\pasted"
                if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
                $fn = Join-Path $dir ("img_" + (Get-Date -Format "yyyyMMdd_HHmmss") + ".png")
                $enc = New-Object System.Windows.Media.Imaging.PngBitmapEncoder
                $enc.Frames.Add([System.Windows.Media.Imaging.BitmapFrame]::Create($img)) | Out-Null
                $fs = [System.IO.File]::Open($fn, "Create")
                $enc.Save($fs); $fs.Close()
                $C.InputBox.Text += " ดูรูปนี้ประกอบ: `"$fn`" "
                $C.InputBox.CaretIndex = $C.InputBox.Text.Length
                SysMsg ("📷 แนบรูปจากคลิปบอร์ดแล้ว: " + (Split-Path $fn -Leaf))
                $e.Handled = $true
            } catch { LogFile ("paste image error: " + $_.Exception.Message) }
        }
    }
})

# ลากไฟล์วิดีโอมาวางที่หน้าต่าง → เติมคำสั่งให้อัตโนมัติ
$Win.AllowDrop = $true
$Win.Add_PreviewDragOver({
    param($s, $e)
    if ($e.Data.GetDataPresent([Windows.DataFormats]::FileDrop)) {
        $e.Effects = [Windows.DragDropEffects]::Copy
        $e.Handled = $true
    }
})
$Win.Add_PreviewDrop({
    param($s, $e)
    if ($e.Data.GetDataPresent([Windows.DataFormats]::FileDrop)) {
        $files = $e.Data.GetData([Windows.DataFormats]::FileDrop)
        if ($files -and $files.Count -gt 0) {
            $f = $files[0]
            $ext = [System.IO.Path]::GetExtension($f).ToLower()
            if (@(".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif") -contains $ext) {
                # ไฟล์รูป → แนบให้ AI ดูประกอบ (ไม่ทับข้อความเดิม)
                $C.InputBox.Text += " ดูรูปนี้ประกอบ: `"$f`" "
                SysMsg "📷 แนบรูปแล้ว: $(Split-Path $f -Leaf)"
            } else {
                $script:LastFile = $f
                $C.InputBox.Text = "ตัดช่วงเงียบคลิป `"$f`" ใส่ซับไทย "
                SysMsg "รับไฟล์แล้ว: $f — กดปุ่มงานด่วนด้านบน หรือเติมรายละเอียดเองแล้วกดส่ง"
            }
            $C.InputBox.CaretIndex = $C.InputBox.Text.Length
            $C.InputBox.Focus() | Out-Null
        }
        $e.Handled = $true
    }
})

# ---------- งานติดตั้ง (รันซ่อน โชว์ความคืบหน้าในแชท) ----------

$script:JobProc = $null
$script:JobBubble = $null
$script:JobText = ""
$script:JobLineDone = 0
$script:InstOut = Join-Path $env:TEMP "devcut_inst.txt"

$script:JobQueue = New-Object System.Collections.Queue

function StartNextJob {
    if ($script:JobQueue.Count -eq 0) {
        if ($script:JobFails -gt 0) {
            SysMsg "⚠ ติดตั้งจบแต่มี $($script:JobFails) ขั้นตอนผิดพลาด — อ่านรายละเอียดด้านบน แล้วกด '⚙ ติดตั้งครั้งแรก' ซ้ำ (ขั้นที่สำเร็จแล้วจะข้ามเอง)"
        } else {
            SysMsg "✅ ติดตั้งครบทุกอย่างแล้ว — พร้อมใช้งาน พิมพ์สั่งได้เลย"
        }
        Refresh
        return
    }
    $job = $script:JobQueue.Dequeue()
    Remove-Item $script:InstOut -ErrorAction SilentlyContinue
    $script:JobLineDone = 0
    $script:JobText = ""
    $script:JobBubble = AddBubble "ติดตั้ง: $($job.Desc)" "กำลังเริ่ม..." "#f59e0b" "#1d180e"
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = "cmd.exe"
    $psi.Arguments = "/d /c chcp 65001 >nul 2>&1 && $($job.Args) >`"$($script:InstOut)`" 2>&1"
    $psi.WorkingDirectory = $KitRoot
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    InjectVenvPath $psi
    $script:JobProc = [System.Diagnostics.Process]::Start($psi)
    $JobTimer.Start()
}

$JobTimer = New-Object System.Windows.Threading.DispatcherTimer
$JobTimer.Interval = [TimeSpan]::FromMilliseconds(400)
$JobTimer.Add_Tick({
  try {
    $alive = ($script:JobProc -and -not $script:JobProc.HasExited)
    $lines = @()
    if (Test-Path $script:InstOut) {
        try { $lines = @(Get-Content $script:InstOut -Encoding UTF8 -ErrorAction SilentlyContinue) } catch { }
    }
    while ($script:JobLineDone -lt $lines.Count) {
        $ln = $lines[$script:JobLineDone]; $script:JobLineDone++
        if ($ln) {
            # winget วาด progress ด้วย \r — เก็บเฉพาะท่อนสุดท้าย และข้ามบรรทัดขยะ
            $ln = ($ln -split "`r")[-1].Trim()
            if ($ln -and $ln -notmatch '^[\s\-\\/|█▒░%\.\d]+$') {
                $script:JobText += $ln + "`n"
                $t = $script:JobText -split "`n"
                if ($t.Count -gt 25) { $script:JobText = ($t[-25..-1] -join "`n") }  # โชว์ 25 บรรทัดล่าสุด
                if ($script:JobBubble) { $script:JobBubble.Text = $script:JobText.Trim() }
                ScrollSmart
            }
        }
    }
    if (-not $alive) {
        $JobTimer.Stop()
        $code = 0
        try { $code = $script:JobProc.ExitCode } catch { }
        # exit 0 แต่ log มี ERROR/Traceback ก็ถือว่าพลาด (pip คืนค่า 0 ทั้งที่ล้มบางส่วนได้)
        $looksBad = ($code -ne 0) -or ($script:JobText -match "ERROR:|Traceback|ModuleNotFoundError")
        if ($looksBad) {
            $script:JobFails++
            SysMsg "⚠ ขั้นตอนนี้จบแบบมีข้อผิดพลาด — อ่านรายละเอียดด้านบน (ขั้นถัดไปจะทำต่อ)"
            LogFile ("ติดตั้งผิดพลาด (exit $code): " + $script:JobText)
        } else {
            LogFile "ติดตั้งขั้นตอนสำเร็จ"
        }
        Refresh
        StartNextJob
    }
  } catch {
    LogFile ("job tick error: " + $_.Exception.Message)
  }
})

$C.BtnInstall.Add_Click({
    if ($script:JobProc -and -not $script:JobProc.HasExited) {
        SysMsg "กำลังติดตั้งอยู่แล้ว รอสักครู่นะ"; return
    }
    $script:JobQueue.Clear()
    $script:JobFails = 0
    $script:JobQueue.Enqueue(@{
        Args = "powershell -NoProfile -ExecutionPolicy Bypass -File `"" +
               (Join-Path $KitRoot "INSTALL\windows\install.ps1") + "`""
        Desc = "ระบบ (Python + ffmpeg + ไลบรารี + ฟอนต์)" })
    # โหลดโมเดลถอดเสียงไทยล่วงหน้าตอนติดตั้ง — งานแรกของลูกค้าจะได้ไม่ต้องรอโหลด
    if (-not (Test-Path (Join-Path $KitRoot "models\hub"))) {
        $script:JobQueue.Enqueue(@{
            Args = "set HF_HOME=$KitRoot\models&& .venv\Scripts\python.exe -c " +
                   "`"from faster_whisper import WhisperModel; " +
                   "WhisperModel('Thaweewat/whisper-th-medium-ct2', device='cpu', compute_type='int8'); " +
                   "print('OK: model ready')`""
            Desc = "โมเดลถอดเสียงไทย (~1.5GB โหลดครั้งเดียว)" })
    }
    # ตัวแยกเสียงพูดจากเพลง (Demucs) — ความแม่นคลิปเพลงดังก้าวกระโดด
    if (-not (Test-Path (Join-Path $KitRoot ".venv\Lib\site-packages\demucs"))) {
        $script:JobQueue.Enqueue(@{
            Args = ".venv\Scripts\python.exe -m pip install demucs soundfile"
            Desc = "ตัวแยกเสียงพูดจากเพลง (~2GB โหลดครั้งเดียว)" })
    }
    if (-not ((Has "node") -or (Test-Path "$env:ProgramFiles\nodejs\node.exe"))) {
        $script:JobQueue.Enqueue(@{
            Args = "winget install --id OpenJS.NodeJS.LTS -e --accept-source-agreements --accept-package-agreements"
            Desc = "Node.js" })
    }
    if (-not (ClaudeCmd)) {
        $npm = "npm"
        if (-not (Has "npm")) { $npm = "`"$env:ProgramFiles\nodejs\npm.cmd`"" }
        $script:JobQueue.Enqueue(@{ Args = "$npm install -g @anthropic-ai/claude-code"
                                    Desc = "Claude Code (AI)" })
    }
    SysMsg "เริ่มติดตั้งทั้งหมด $($script:JobQueue.Count) ขั้นตอน — นั่งรอได้เลย เดี๋ยวรายงานทีละขั้น"
    StartNextJob
})

# ---------- เชื่อม Claude (ล็อกอิน) ----------
# เปิดหน้าต่าง terminal ให้ผู้ใช้พิมพ์ /login แล้วยืนยันในเบราว์เซอร์ (ครั้งเดียวต่อเครื่อง)
$C.BtnLogin.Add_Click({
    $cc = ClaudeCmd
    if (-not $cc) {
        SysMsg "ยังไม่ได้ติดตั้ง Claude Code — กดปุ่ม '⚙ ติดตั้งครั้งแรก' มุมขวาบนก่อน แล้วค่อยเชื่อม"
        return
    }
    SysMsg "เปิดหน้าต่างเชื่อม Claude ให้แล้ว — พิมพ์ /login ในหน้าต่างนั้นแล้วทำตามขั้นตอนในเบราว์เซอร์ (ครั้งเดียวต่อเครื่อง) เสร็จแล้วปิดหน้าต่างนั้นและกลับมาแชทต่อได้เลย"
    LogFile "ผู้ใช้กดปุ่มเชื่อม Claude"
    try {
        Start-Process cmd -ArgumentList "/k","cd /d `"$KitRoot`" && $cc" -WorkingDirectory $KitRoot
    } catch {
        SysMsg ("เปิดหน้าต่างเชื่อม Claude ไม่สำเร็จ: " + $_.Exception.Message)
    }
})

$C.BtnNew.Add_Click({
    if ($script:Proc -and -not $script:Proc.HasExited) { StopWork }
    $script:FirstMsg = $true
    $C.ChatPanel.Children.Clear()
    Remove-Item $script:HistFile -ErrorAction SilentlyContinue
    SysMsg "เริ่มแชทใหม่แล้ว — งานเก่าไม่หายไปไหน (โปรเจกต์ CapCut และไฟล์ใน work\ ยังอยู่ครบ)"
    SysMsg "ลากไฟล์คลิปมาวาง หรือกดปุ่มงานด่วนด้านบนได้เลย"
})

# ---------- ชิปงานด่วน ----------

function FillChip($template) {
    $file = if ($script:LastFile) { "`"$($script:LastFile)`"" } else { "<ลากไฟล์คลิปมาวางก่อน>" }
    $C.InputBox.Text = $template -replace "\{FILE\}", $file
    $C.InputBox.CaretIndex = $C.InputBox.Text.Length
    $C.InputBox.Focus() | Out-Null
    if (-not $script:LastFile) { SysMsg "ยังไม่ได้เลือกไฟล์ — ลากคลิปจาก File Explorer มาวางที่หน้าต่างนี้ก่อน แล้วกดปุ่มงานด่วนอีกครั้ง" }
}

$C.ChipTikTok.Add_Click({ FillChip "ตัดช่วงเงียบคลิป {FILE} ใส่ซับไทย สไตล์ vlog แนวตั้ง 9:16 ลง TikTok สร้างโปรเจกต์ CapCut" })
$C.ChipYT.Add_Click({ FillChip "ตัดช่วงเงียบคลิป {FILE} ใส่ซับไทย สไตล์ clean แนวนอน ลง YouTube สร้างโปรเจกต์ CapCut" })
$C.ChipSub.Add_Click({ FillChip "ใส่ซับไทยให้คลิป {FILE} โดยไม่ต้องตัด สร้างโปรเจกต์ CapCut" })

# ---------- เลือกไฟล์คลิป ----------

$VideoExts = @(".mp4", ".mov", ".mkv", ".avi", ".webm", ".m4v")
$ClipsDir = Join-Path $KitRoot "clips"
if (-not (Test-Path $ClipsDir)) { New-Item -ItemType Directory -Path $ClipsDir -Force | Out-Null }

function UseFile($path) {
    $script:LastFile = $path
    $C.BtnRecent.Content = "🎞 " + (ShortName (Split-Path $path -Leaf) 24) + " ▾"
    SysMsg "เลือกคลิปแล้ว: $(Split-Path $path -Leaf) — กดปุ่มงานด่วน หรือพิมพ์สั่งเองได้เลย"
}

$C.BtnPick.Add_Click({
    $dlg = New-Object Microsoft.Win32.OpenFileDialog
    $dlg.Title = "เลือกคลิปที่จะตัด"
    $dlg.Filter = "ไฟล์วิดีโอ|*.mp4;*.mov;*.mkv;*.avi;*.webm;*.m4v|ทุกไฟล์|*.*"
    if ($dlg.ShowDialog()) { UseFile $dlg.FileName }
})

function ShortName($name, $max = 34) {
    if ($name.Length -le $max) { return $name }
    return $name.Substring(0, $max - 1) + "…"
}

$C.BtnRecent.Add_Click({
    $dirs = @($ClipsDir, [Environment]::GetFolderPath("MyVideos"))
    $files = @()
    foreach ($d in $dirs) {
        if ($d -and (Test-Path $d)) {
            $files += Get-ChildItem $d -File -ErrorAction SilentlyContinue |
                Where-Object { $VideoExts -contains $_.Extension.ToLower() }
        }
    }
    $files = $files | Sort-Object LastWriteTime -Descending | Select-Object -First 15

    $menu = New-Object System.Windows.Controls.ContextMenu
    $menu.Background = New-Object System.Windows.Media.SolidColorBrush(
        [System.Windows.Media.ColorConverter]::ConvertFromString("#1a1d24"))
    $menu.Foreground = New-Object System.Windows.Media.SolidColorBrush(
        [System.Windows.Media.ColorConverter]::ConvertFromString("#e2e8f0"))
    $menu.BorderThickness = "1"
    $menu.BorderBrush = New-Object System.Windows.Media.SolidColorBrush(
        [System.Windows.Media.ColorConverter]::ConvertFromString("#2d3340"))

    if ($files.Count -eq 0) {
        $mi = New-Object System.Windows.Controls.MenuItem
        $mi.Header = "(ยังไม่มีคลิป — วางไฟล์ไว้ในโฟลเดอร์ clips หรือ Videos)"
        $mi.IsEnabled = $false
        $menu.Items.Add($mi) | Out-Null
    } else {
        foreach ($f in $files) {
            $mi = New-Object System.Windows.Controls.MenuItem
            $mi.Header = ShortName $f.Name
            $mi.ToolTip = $f.FullName
            $mi.Tag = $f.FullName
            $mi.Background = $menu.Background
            $mi.Foreground = $menu.Foreground
            $mi.Add_Click({ param($s, $ev) UseFile $s.Tag })
            $menu.Items.Add($mi) | Out-Null
        }
    }
    $menu.PlacementTarget = $C.BtnRecent
    $menu.Placement = "Bottom"
    $menu.IsOpen = $true
})

$C.BtnRefresh.Add_Click({ Refresh })

# ---------- ป๊อปอัพฟีเจอร์ ----------

$Features = @(
    # ---- มีให้เลือกเห็นภาพ (picker) — โซนบนสุด ----
    @{ Ic = "style"; Open = "style"; N = "เลือกสไตล์ซับ"; D = "clean (เรียบ YouTube) / bold (ซับใหญ่ TikTok) / pop (กล่องสีหลังคำ) / vlog (ซูมสลับท่อน) — กด 'ดูสไตล์' เห็นภาพตัวอย่างจริงแล้วเลือก · ทุกสไตล์ export ฟรี ไม่ต้องมี CapCut Pro"
       E = "ตัดคลิป {FILE} สไตล์ pop ซับกล่องดำ แนวตั้ง" }
    @{ Ic = "layout-template"; Open = "gfx"; N = "ทำกราฟิก"; D = "title card / แถบชื่อ / end card / พื้นหลัง ภาษาไทยฟอนต์ LINE Seed — กด 'เลือกแบบ' ดูตัวอย่างจริงแล้วเลือก"
       E = "ทำ title card เขียนว่า 'รีวิว 5 แอปฟรี EP.1' โทนสีน้ำเงิน แนวตั้ง" }
    @{ Ic = "music-4"; Open = "sfx"; N = "เสียงประกอบ (SFX)"; D = "เสียง whoosh/pop/ding/riser ฯลฯ 18 เสียงในกล่อง ไม่ติดลิขสิทธิ์ — กด 'เลือกเสียง' ฟังก่อนเลือกได้"
       E = "มีเสียงเอฟเฟกต์อะไรบ้าง แนะนำตัวที่เหมาะกับตอนเปลี่ยนฉากหน่อย" }

    # ---- ฟีเจอร์หลัก ----
    @{ Ic = "scissors"; N = "ตัดช่วงเงียบ + ใส่ซับ"; D = "ตัดช่วงเงียบ/ช่วงตายออกอัตโนมัติ ถอดเสียงไทยทำซับ ส่งเข้า CapCut พร้อมแก้ต่อ"
       E = "ตัดช่วงเงียบคลิป {FILE} ใส่ซับไทย ลง TikTok สร้างโปรเจกต์ CapCut" }
    @{ Ic = "captions"; N = "ใส่ซับอย่างเดียว"; D = "ถอดเสียงทำซับไทยโดยไม่ตัดอะไรเลย"
       E = "ใส่ซับไทยให้คลิป {FILE} โดยไม่ต้องตัด สร้างโปรเจกต์ CapCut" }
    @{ Ic = "highlighter"; N = "ซับ karaoke ไฮไลต์คำ (ใหม่)"; D = "คำที่กำลังพูดเปลี่ยนสีทีละคำ ซิงก์เวลาคำจริง — เปิดอัตโนมัติสำหรับคลิปแนวตั้ง (bold/vlog/pop) ฟรี ไม่ติด Pro"
       E = "ตัดคลิป {FILE} ใส่ซับ karaoke ไฮไลต์คำสีเหลือง แนวตั้ง 9:16 ลง TikTok สร้างโปรเจกต์ CapCut" }
    @{ Ic = "audio-lines"; N = "ถอดเสียงคลิปเพลงดัง แม่นขึ้น (ใหม่)"; D = "คลิปอนิเมะ/เกม/ไฮไลต์ที่มีเพลง-เอฟเฟกต์ดัง — ระบบแยกเสียงพูดออกจากเพลงก่อนถอด 'อัตโนมัติเมื่อเจอเพลง' ซับเพี้ยนน้อยลงมาก (ต้องติดตั้ง 'ตัวแยกเสียงพูด')"
       E = "คลิป {FILE} มีเพลงดัง แยกเสียงพูดก่อนถอด ใส่ซับไทย ลง TikTok สร้างโปรเจกต์ CapCut" }
    @{ Ic = "sparkles"; N = "โหมดถอดเสียงแม่นสูง (ใหม่)"; D = "โมเดลไทยตัวใหญ่ + จูนละเอียด — เหมาะ 'เสียงสะอาด/มี GPU' (ช้าลง ~4-8x บน CPU, โหลด ~1.5GB) *คลิปมีเพลงดังให้ใช้ 'แยกเสียงพูด' คุ้มกว่า"
       E = "ใส่ซับไทยให้คลิป {FILE} โหมดแม่นสูง (accuracy high) สร้างโปรเจกต์ CapCut" }
    @{ Ic = "replace"; N = "แก้คำถอดผิด ทั้งไฟล์ (ใหม่)"; D = "ชื่อ/คำที่ ASR ถอดผิดซ้ำ ๆ — แก้ทีเดียวทั้งซับ (เร็ว ทุกเครื่อง) ซับ+karaoke อัปเดตให้เอง"
       E = "ในซับคลิปที่เพิ่งทำ แก้คำว่า 'คำที่ผิด' เป็น 'คำที่ถูก' ทั้งไฟล์ แล้วสร้างโปรเจกต์ CapCut ใหม่" }

    # ---- ฟีเจอร์เสริม ----
    @{ Ic = "volume-2"; N = "เสียง whoosh ตอนตัด อัตโนมัติ (ใหม่)"; D = "ใส่เสียงเอฟเฟกต์ตรงรอยตัด jump cut ทุกจุดให้เอง (เสียงในกล่อง ไม่ติดลิขสิทธิ์)"
       E = "ตัดช่วงเงียบคลิป {FILE} ใส่ซับ + เสียง whoosh ตอนตัดทุกจุด แนวตั้ง 9:16 ลง TikTok สร้างโปรเจกต์ CapCut" }
    @{ Ic = "music"; N = "เพลงพื้นหลัง + หรี่เสียงอัตโนมัติ (ใหม่)"; D = "ใส่เพลงที่คุณเตรียมเอง วนยาวเต็มคลิป + หรี่เสียงเพลงลงตอนคนพูดให้อัตโนมัติ (auto-duck)"
       E = "ใส่เพลงพื้นหลังให้คลิป {FILE} หรี่เสียงตอนคนพูดอัตโนมัติ (ไฟล์เพลงอยู่ที่ <ลากไฟล์เพลงมาบอกที่อยู่>)" }
    @{ Ic = "eraser"; N = "ไดคัท (ลบพื้นหลัง)"; D = "ลบพื้นหลังรูปหรือวิดีโอ ได้ไฟล์โปร่งใสไปวางซ้อนใน CapCut"
       E = "ไดคัทช่วงวินาที 10-15 ของคลิป {FILE} เอาไว้ซ้อนฉากอื่น" }
    @{ Ic = "shapes"; N = "ไอคอน/สติกเกอร์"; D = "ไอคอน Lucide ~2,000 แบบในเครื่อง เลือกสี/ขนาดได้ ได้ PNG โปร่งใส"
       E = "ทำไอคอนรูปกล้องสีส้ม ขนาด 512 ไว้แปะในคลิป" }
    @{ Ic = "image"; N = "หารูป/b-roll ฟรี"; D = "ค้นรูปฟรีถูกลิขสิทธิ์พร้อมเครดิตอัตโนมัติ (b-roll วิดีโอต้องมี key Pexels ฟรี)"
       E = "หารูปตึกกรุงเทพตอนกลางคืนมา 3 รูป" }
    @{ Ic = "chart-column"; N = "วิเคราะห์คลิป"; D = "เช็คความยาว ความดังเสียง ช่วงเงียบ ก่อนตัดสินใจตัด"
       E = "วิเคราะห์คลิป {FILE} ให้หน่อยว่าควรตัดยังไง" }
    @{ Ic = "file-output"; N = "สรุปงานส่งต่อ editor"; D = "รายงาน + ไฟล์ซับ + EDL สำหรับ Premiere/Resolve"
       E = "สรุปงานทั้งหมดเป็น handoff package ส่งต่อ editor" }
)

foreach ($feat in $Features) {
    $card = New-Object System.Windows.Controls.Border
    $card.CornerRadius = "10"; $card.Padding = "12,9"; $card.Margin = "0,0,0,8"
    $card.Background = New-Object System.Windows.Media.SolidColorBrush(
        [System.Windows.Media.ColorConverter]::ConvertFromString("#1e222b"))
    $g = New-Object System.Windows.Controls.Grid
    $c0 = New-Object System.Windows.Controls.ColumnDefinition
    $c0.Width = [System.Windows.GridLength]::Auto
    $c1 = New-Object System.Windows.Controls.ColumnDefinition
    $c2 = New-Object System.Windows.Controls.ColumnDefinition
    $c2.Width = [System.Windows.GridLength]::Auto
    $g.ColumnDefinitions.Add($c0); $g.ColumnDefinitions.Add($c1); $g.ColumnDefinitions.Add($c2)
    # รูป thumbnail ไอคอนฟีเจอร์
    $thumbPath = Join-Path $PSScriptRoot ("previews\feat_" + $feat.Ic + ".png")
    if (Test-Path $thumbPath) {
        try {
            $tbm = New-Object System.Windows.Media.Imaging.BitmapImage
            $tbm.BeginInit(); $tbm.UriSource = [Uri]$thumbPath
            $tbm.CacheOption = [System.Windows.Media.Imaging.BitmapCacheOption]::OnLoad
            $tbm.EndInit()
            $thumb = New-Object System.Windows.Controls.Image
            $thumb.Source = $tbm; $thumb.Width = 52; $thumb.Height = 52
            $thumb.Margin = "0,0,12,0"; $thumb.VerticalAlignment = "Top"
            [System.Windows.Controls.Grid]::SetColumn($thumb, 0)
            $g.Children.Add($thumb) | Out-Null
        } catch { }
    }
    $sp = New-Object System.Windows.Controls.StackPanel
    $t1 = New-Object System.Windows.Controls.TextBlock
    $t1.Text = $feat.N; $t1.FontWeight = "Bold"; $t1.FontSize = 13.5
    $t1.Foreground = New-Object System.Windows.Media.SolidColorBrush(
        [System.Windows.Media.ColorConverter]::ConvertFromString("#ffffff"))
    $t2 = New-Object System.Windows.Controls.TextBlock
    $t2.Text = $feat.D; $t2.FontSize = 11.5; $t2.TextWrapping = "Wrap"; $t2.Margin = "0,2,0,3"
    $t2.Foreground = New-Object System.Windows.Media.SolidColorBrush(
        [System.Windows.Media.ColorConverter]::ConvertFromString("#8b93a5"))
    $t3 = New-Object System.Windows.Controls.TextBlock
    $t3.Text = [char]0x201C + ($feat.E -replace "\{FILE\}", "<คลิป>") + [char]0x201D
    $t3.FontSize = 11.5; $t3.TextWrapping = "Wrap"
    $t3.FontStyle = [System.Windows.FontStyles]::Italic
    $t3.Foreground = New-Object System.Windows.Media.SolidColorBrush(
        [System.Windows.Media.ColorConverter]::ConvertFromString("#94e2b8"))
    $sp.Children.Add($t1) | Out-Null; $sp.Children.Add($t2) | Out-Null; $sp.Children.Add($t3) | Out-Null
    [System.Windows.Controls.Grid]::SetColumn($sp, 1)
    $btn = New-Object System.Windows.Controls.Button
    $btn.Content = "ลองใช้"; $btn.Padding = "12,6"; $btn.Margin = "10,0,0,0"
    $btn.VerticalAlignment = "Center"
    $btn.Cursor = [System.Windows.Input.Cursors]::Hand
    try { $btn.Style = $Win.Resources["Btn"] } catch { }
    $btn.Background = New-Object System.Windows.Media.SolidColorBrush(
        [System.Windows.Media.ColorConverter]::ConvertFromString("#e11d48"))
    $btn.Foreground = New-Object System.Windows.Media.SolidColorBrush(
        [System.Windows.Media.ColorConverter]::ConvertFromString("#ffffff"))
    if ($feat.Open) {
        # ฟีเจอร์ที่มี picker เห็นภาพ (style/gfx) → เปิดหน้าเลือกแทนการเติมคำสั่ง
        $btn.Content = switch ($feat.Open) { "gfx" { "เลือกแบบ" } "sfx" { "เลือกเสียง" } default { "ดูสไตล์" } }
        $btn.Tag = $feat.Open
        $btn.Add_Click({
            param($s, $ev)
            $C.HelpOverlay.Visibility = "Collapsed"
            switch ($s.Tag) {
                "gfx" { $C.GfxOverlay.Visibility = "Visible" }
                "sfx" { $C.SfxOverlay.Visibility = "Visible" }
                default { $C.StyleOverlay.Visibility = "Visible" }
            }
        })
    } else {
        $btn.Tag = $feat.E
        $btn.Add_Click({
            param($s, $ev)
            $file = if ($script:LastFile) { "`"$($script:LastFile)`"" } else { "<ลากไฟล์คลิปมาวางก่อน>" }
            $C.InputBox.Text = $s.Tag -replace "\{FILE\}", $file
            $C.InputBox.CaretIndex = $C.InputBox.Text.Length
            $C.HelpOverlay.Visibility = "Collapsed"
            $C.InputBox.Focus() | Out-Null
        })
    }
    [System.Windows.Controls.Grid]::SetColumn($btn, 2)
    $g.Children.Add($sp) | Out-Null; $g.Children.Add($btn) | Out-Null
    $card.Child = $g
    $C.HelpList.Children.Add($card) | Out-Null
}

$C.BtnHelp.Add_Click({ $C.HelpOverlay.Visibility = "Visible" })
$C.BtnHelpClose.Add_Click({ $C.HelpOverlay.Visibility = "Collapsed" })
$C.HelpOverlay.Add_MouseLeftButtonDown({
    param($s, $e)
    if ($e.Source -eq $C.HelpOverlay) { $C.HelpOverlay.Visibility = "Collapsed" }
})

# ---------- หน้าเลือกสไตล์ซับ (เห็นภาพจริงก่อนเลือก) ----------
$StyleDefs = @(
    @{ Name = "clean"; Desc = "เรียบหรู ขอบบาง`nเหมาะ YouTube แนวนอน"
       Tmpl = "ตัดช่วงเงียบคลิป {FILE} ใส่ซับไทย สไตล์ clean แนวนอน ลง YouTube สร้างโปรเจกต์ CapCut" }
    @{ Name = "bold"; Desc = "ซับใหญ่ ขอบหนา`nเด่นบนมือถือ (TikTok)"
       Tmpl = "ตัดช่วงเงียบคลิป {FILE} ใส่ซับไทย สไตล์ bold แนวตั้ง 9:16 ลง TikTok สร้างโปรเจกต์ CapCut" }
    @{ Name = "pop"; Desc = "แถบสีหลังคำ ตัวใหญ่สุด`nสาย viral"
       Tmpl = "ตัดช่วงเงียบคลิป {FILE} ใส่ซับไทย สไตล์ pop แนวตั้ง 9:16 ลง TikTok สร้างโปรเจกต์ CapCut" }
)
$PrevDir = Join-Path $PSScriptRoot "previews"
foreach ($sd in $StyleDefs) {
    $card = New-Object System.Windows.Controls.Border
    $card.Width = 200; $card.Margin = "0,0,14,0"; $card.CornerRadius = "14"
    $card.Padding = "10"; $card.Cursor = "Hand"; $card.Tag = $sd.Tmpl
    $card.Background = New-Object System.Windows.Media.SolidColorBrush(
        [System.Windows.Media.ColorConverter]::ConvertFromString("#0e1015"))
    $card.BorderBrush = New-Object System.Windows.Media.SolidColorBrush(
        [System.Windows.Media.ColorConverter]::ConvertFromString("#2d3340"))
    $card.BorderThickness = "1"
    $sp = New-Object System.Windows.Controls.StackPanel
    $png = Join-Path $PrevDir ($sd.Name + ".png")
    if (Test-Path $png) {
        try {
            $bmp = New-Object System.Windows.Media.Imaging.BitmapImage
            $bmp.BeginInit(); $bmp.UriSource = [Uri]$png
            $bmp.CacheOption = [System.Windows.Media.Imaging.BitmapCacheOption]::OnLoad
            $bmp.EndInit()
            $im = New-Object System.Windows.Controls.Image
            $im.Source = $bmp; $im.Width = 176; $im.Margin = "0,0,0,8"; $im.Stretch = "Uniform"
            $sp.Children.Add($im) | Out-Null
        } catch { }
    }
    $desc = New-Object System.Windows.Controls.TextBlock
    $desc.Text = $sd.Desc; $desc.TextWrapping = "Wrap"; $desc.FontSize = 12.5
    $desc.TextAlignment = "Center"
    $desc.Foreground = New-Object System.Windows.Media.SolidColorBrush(
        [System.Windows.Media.ColorConverter]::ConvertFromString("#cbd5e1"))
    $sp.Children.Add($desc) | Out-Null
    # ปุ่มเลือกชัด ๆ (กันงงว่ากดตรงไหน)
    $sel = New-Object System.Windows.Controls.Button
    $sel.Content = "เลือกสไตล์นี้"; $sel.Padding = "0,8"; $sel.Margin = "0,12,0,0"
    $sel.FontWeight = "Bold"; $sel.Cursor = [System.Windows.Input.Cursors]::Hand; $sel.Tag = $sd.Tmpl
    try { $sel.Style = $Win.Resources["Btn"] } catch { }
    $sel.Background = New-Object System.Windows.Media.SolidColorBrush(
        [System.Windows.Media.ColorConverter]::ConvertFromString("#e11d48"))
    $sel.Foreground = New-Object System.Windows.Media.SolidColorBrush(
        [System.Windows.Media.ColorConverter]::ConvertFromString("#ffffff"))
    $sel.Add_Click({
        param($s, $e)
        $cmd = $s.Tag
        if ($script:StyleHiColor -and $script:StyleHiColor -ne "เหลือง") {
            $cmd = "$cmd ไฮไลต์คำสี$($script:StyleHiColor)"
        }
        FillChip $cmd
        $C.StyleOverlay.Visibility = "Collapsed"
    })
    $sp.Children.Add($sel) | Out-Null
    $card.Child = $sp
    $C.StyleCards.Children.Add($card) | Out-Null
}

# แถวเลือกสีไฮไลต์ karaoke (แนบเข้าคำสั่งตอนกด 'เลือกสไตล์นี้')
$script:StyleHiColor = "เหลือง"
$script:ColorSwatches = @()
$ColorDefs = @(
    @{ Th = "เหลือง"; Hex = "#ffe600" }
    @{ Th = "เขียว";  Hex = "#22c55e" }
    @{ Th = "ขาว";    Hex = "#ffffff" }
    @{ Th = "ฟ้า";    Hex = "#38bdf8" }
    @{ Th = "ชมพู";   Hex = "#ec4899" }
)
foreach ($cd in $ColorDefs) {
    $sw = New-Object System.Windows.Controls.Border
    $sw.Width = 30; $sw.Height = 30; $sw.CornerRadius = "15"; $sw.Margin = "0,0,10,0"
    $sw.Cursor = [System.Windows.Input.Cursors]::Hand; $sw.Tag = $cd.Th
    $sw.ToolTip = $cd.Th
    $sw.Background = New-Object System.Windows.Media.SolidColorBrush(
        [System.Windows.Media.ColorConverter]::ConvertFromString($cd.Hex))
    $sw.BorderThickness = "3"
    $edge = if ($cd.Th -eq "เหลือง") { "#ffffff" } else { "#171a21" }
    $sw.BorderBrush = New-Object System.Windows.Media.SolidColorBrush(
        [System.Windows.Media.ColorConverter]::ConvertFromString($edge))
    $sw.Add_MouseLeftButtonUp({
        param($s, $e)
        $script:StyleHiColor = $s.Tag
        foreach ($x in $script:ColorSwatches) {
            $c = if ($x -eq $s) { "#ffffff" } else { "#171a21" }
            $x.BorderBrush = New-Object System.Windows.Media.SolidColorBrush(
                [System.Windows.Media.ColorConverter]::ConvertFromString($c))
        }
    })
    $C.ColorRow.Children.Add($sw) | Out-Null
    $script:ColorSwatches += $sw
}

$C.BtnStyleBack.Add_Click({
    $C.StyleOverlay.Visibility = "Collapsed"
    $C.HelpOverlay.Visibility = "Visible"      # กลับไปหน้าฟีเจอร์
})
$C.BtnStyleClose.Add_Click({ $C.StyleOverlay.Visibility = "Collapsed" })
$C.StyleOverlay.Add_MouseLeftButtonDown({
    param($s, $e)
    if ($e.Source -eq $C.StyleOverlay) { $C.StyleOverlay.Visibility = "Collapsed" }
})

# ---------- หน้าเลือกแบบกราฟิก (เห็นภาพจริง) ----------
$GfxDefs = @(
    @{ Img = "gfx_title-card";  N = "Title card";           Tmpl = "ทำ title card เขียนว่า '<ใส่ข้อความ>' โทนสีน้ำเงิน แนวตั้ง" }
    @{ Img = "gfx_lower-third"; N = "แถบชื่อ (lower third)"; Tmpl = "ทำแถบชื่อ lower third ชื่อ '<ชื่อ>' ตำแหน่ง '<ตำแหน่ง>' แนวตั้ง" }
    @{ Img = "gfx_end-card";    N = "End card (การ์ดปิดท้าย)"; Tmpl = "ทำ end card เขียนว่า '<ข้อความปิดท้าย>' แนวตั้ง" }
    @{ Img = "gfx_bg-gradient"; N = "พื้นหลัง gradient";      Tmpl = "ทำพื้นหลัง gradient โทนสีน้ำเงิน แนวตั้ง" }
)
foreach ($gd in $GfxDefs) {
    $card = New-Object System.Windows.Controls.Border
    $card.Width = 320; $card.Margin = "0,0,14,14"; $card.CornerRadius = "12"; $card.Padding = "10"
    $card.Background = New-Object System.Windows.Media.SolidColorBrush(
        [System.Windows.Media.ColorConverter]::ConvertFromString("#0e1015"))
    $card.BorderBrush = New-Object System.Windows.Media.SolidColorBrush(
        [System.Windows.Media.ColorConverter]::ConvertFromString("#2d3340"))
    $card.BorderThickness = "1"
    $sp = New-Object System.Windows.Controls.StackPanel
    $png = Join-Path $PSScriptRoot ("previews\" + $gd.Img + ".png")
    if (Test-Path $png) {
        try {
            $bmp = New-Object System.Windows.Media.Imaging.BitmapImage
            $bmp.BeginInit(); $bmp.UriSource = [Uri]$png
            $bmp.CacheOption = [System.Windows.Media.Imaging.BitmapCacheOption]::OnLoad
            $bmp.EndInit()
            $im = New-Object System.Windows.Controls.Image
            $im.Source = $bmp; $im.Width = 296; $im.Margin = "0,0,0,8"; $im.Stretch = "Uniform"
            $sp.Children.Add($im) | Out-Null
        } catch { }
    }
    $nm = New-Object System.Windows.Controls.TextBlock
    $nm.Text = $gd.N; $nm.FontWeight = "Bold"; $nm.FontSize = 13.5; $nm.TextAlignment = "Center"
    $nm.Foreground = New-Object System.Windows.Media.SolidColorBrush(
        [System.Windows.Media.ColorConverter]::ConvertFromString("#ffffff"))
    $sp.Children.Add($nm) | Out-Null
    $use = New-Object System.Windows.Controls.Button
    $use.Content = "ใช้แบบนี้"; $use.Padding = "0,8"; $use.Margin = "0,10,0,0"; $use.FontWeight = "Bold"
    $use.Cursor = [System.Windows.Input.Cursors]::Hand; $use.Tag = $gd.Tmpl
    try { $use.Style = $Win.Resources["Btn"] } catch { }
    $use.Background = New-Object System.Windows.Media.SolidColorBrush(
        [System.Windows.Media.ColorConverter]::ConvertFromString("#e11d48"))
    $use.Foreground = New-Object System.Windows.Media.SolidColorBrush(
        [System.Windows.Media.ColorConverter]::ConvertFromString("#ffffff"))
    $use.Add_Click({
        param($s, $e)
        $C.InputBox.Text = $s.Tag                 # กราฟิกไม่ต้องมีไฟล์คลิป — ผู้ใช้พิมพ์ข้อความแทน <...>
        $C.InputBox.CaretIndex = $C.InputBox.Text.Length
        $C.GfxOverlay.Visibility = "Collapsed"
        $C.InputBox.Focus() | Out-Null
    })
    $sp.Children.Add($use) | Out-Null
    $card.Child = $sp
    $C.GfxCards.Children.Add($card) | Out-Null
}

$C.BtnGfxBack.Add_Click({
    $C.GfxOverlay.Visibility = "Collapsed"
    $C.HelpOverlay.Visibility = "Visible"
})
$C.BtnGfxClose.Add_Click({ $C.GfxOverlay.Visibility = "Collapsed" })
$C.GfxOverlay.Add_MouseLeftButtonDown({
    param($s, $e)
    if ($e.Source -eq $C.GfxOverlay) { $C.GfxOverlay.Visibility = "Collapsed" }
})

# ---------- หน้าเลือกเสียง SFX (มีปุ่มฟัง) ----------
$SfxDefs = @(
    @{ F = "whoosh_soft"; Th = "วูชนุ่ม" },      @{ F = "whoosh_fast"; Th = "วูชเร็ว" }
    @{ F = "swoosh_reverse"; Th = "วูชย้อน" },   @{ F = "transition_hit"; Th = "ฮิตเปลี่ยนฉาก" }
    @{ F = "pop"; Th = "ป๊อป" },                 @{ F = "pop_double"; Th = "ป๊อปคู่" }
    @{ F = "ding"; Th = "ติ๊ง" },                @{ F = "ding_high"; Th = "ติ๊งสูง" }
    @{ F = "chime_up"; Th = "ไชม์ขึ้น" },        @{ F = "click_soft"; Th = "คลิกเบา" }
    @{ F = "notification"; Th = "แจ้งเตือน" },   @{ F = "success"; Th = "สำเร็จ" }
    @{ F = "error_buzz"; Th = "เสียงผิดพลาด" },  @{ F = "riser_short"; Th = "ไรเซอร์ (บิลด์อัพ)" }
    @{ F = "impact_deep"; Th = "กระแทกลึก" },    @{ F = "boom_sub"; Th = "บูมเบสลึก" }
    @{ F = "thud"; Th = "ตุบ" },                 @{ F = "camera_shutter"; Th = "ชัตเตอร์กล้อง" }
)
$script:SfxPlayer = New-Object System.Media.SoundPlayer
$SfxDir = Join-Path $KitRoot "sfx-pack"
foreach ($sx in $SfxDefs) {
    $row = New-Object System.Windows.Controls.Border
    $row.CornerRadius = "8"; $row.Padding = "10,7"; $row.Margin = "0,0,0,6"
    $row.Background = New-Object System.Windows.Media.SolidColorBrush(
        [System.Windows.Media.ColorConverter]::ConvertFromString("#1e222b"))
    $rg = New-Object System.Windows.Controls.Grid
    foreach ($wd in @($null, "Auto", "Auto")) {
        $cdef = New-Object System.Windows.Controls.ColumnDefinition
        if ($wd) { $cdef.Width = [System.Windows.GridLength]::Auto }
        $rg.ColumnDefinitions.Add($cdef)
    }
    $lbl = New-Object System.Windows.Controls.TextBlock
    $lbl.Text = "$($sx.Th)  ($($sx.F))"; $lbl.FontSize = 13; $lbl.VerticalAlignment = "Center"
    $lbl.Foreground = New-Object System.Windows.Media.SolidColorBrush(
        [System.Windows.Media.ColorConverter]::ConvertFromString("#e2e8f0"))
    [System.Windows.Controls.Grid]::SetColumn($lbl, 0)
    $play = New-Object System.Windows.Controls.Button
    $play.Content = "▶ ฟัง"; $play.Padding = "12,5"; $play.Margin = "6,0,6,0"
    $play.Cursor = [System.Windows.Input.Cursors]::Hand
    try { $play.Style = $Win.Resources["Btn"] } catch { }
    $play.Tag = (Join-Path $SfxDir ($sx.F + ".wav"))
    $play.Add_Click({
        param($s, $e)
        try { $script:SfxPlayer.SoundLocation = $s.Tag; $script:SfxPlayer.Play() }
        catch { SysMsg "เล่นเสียงไม่สำเร็จ (ไฟล์อาจหาย)" }
    })
    [System.Windows.Controls.Grid]::SetColumn($play, 1)
    $useB = New-Object System.Windows.Controls.Button
    $useB.Content = "ใช้"; $useB.Padding = "14,5"; $useB.FontWeight = "Bold"
    $useB.Cursor = [System.Windows.Input.Cursors]::Hand
    try { $useB.Style = $Win.Resources["Btn"] } catch { }
    $useB.Background = New-Object System.Windows.Media.SolidColorBrush(
        [System.Windows.Media.ColorConverter]::ConvertFromString("#e11d48"))
    $useB.Foreground = New-Object System.Windows.Media.SolidColorBrush(
        [System.Windows.Media.ColorConverter]::ConvertFromString("#ffffff"))
    $useB.Tag = "ตัดช่วงเงียบคลิป {FILE} ใส่ซับไทย + เสียง $($sx.F) ตอนตัดทุกจุด แนวตั้ง 9:16 ลง TikTok สร้างโปรเจกต์ CapCut"
    $useB.Add_Click({
        param($s, $e)
        FillChip $s.Tag
        $C.SfxOverlay.Visibility = "Collapsed"
    })
    [System.Windows.Controls.Grid]::SetColumn($useB, 2)
    $rg.Children.Add($lbl) | Out-Null; $rg.Children.Add($play) | Out-Null; $rg.Children.Add($useB) | Out-Null
    $row.Child = $rg
    $C.SfxList.Children.Add($row) | Out-Null
}

$C.BtnSfxBack.Add_Click({
    $C.SfxOverlay.Visibility = "Collapsed"
    $C.HelpOverlay.Visibility = "Visible"
})
$C.BtnSfxClose.Add_Click({ $C.SfxOverlay.Visibility = "Collapsed" })
$C.SfxOverlay.Add_MouseLeftButtonDown({
    param($s, $e)
    if ($e.Source -eq $C.SfxOverlay) { $C.SfxOverlay.Visibility = "Collapsed" }
})

$Win.Add_Closing({
    if ($script:Proc -and -not $script:Proc.HasExited) { try { $script:Proc.Kill() } catch { } }
})

# โหลดประวัติแชทเดิม (ถ้ามี) — บทสนทนาฝั่ง Claude ต่อได้ด้วย --continue
$restored = 0
if (Test-Path $script:HistFile) {
    try {
        $histLines = @(Get-Content $script:HistFile -Encoding UTF8 -ErrorAction SilentlyContinue)
        if ($histLines.Count -gt 60) { $histLines = $histLines[-60..-1] }   # โชว์ 60 รายการล่าสุด
        foreach ($hl in $histLines) {
            if (-not $hl) { continue }
            try {
                $rec = $hl | ConvertFrom-Json
                if ($rec.w -eq "คุณ") { AddBubble "คุณ" $rec.t "#60a5fa" "#141c2b" | Out-Null }
                else { AddBubble "Dev-Cut" $rec.t "#e11d48" "#1c1017" | Out-Null }
                $restored++
            } catch { }
        }
    } catch { }
}
if ($restored -gt 0) {
    $script:FirstMsg = $false   # ข้อความถัดไปต่อบทสนทนาเดิมของ Claude
    SysMsg "โหลดแชทเดิมกลับมาแล้ว ($restored ข้อความ) — คุยต่อได้เลย หรือกด '＋ แชทใหม่' เพื่อเริ่มใหม่"
} else {
    SysMsg "ยินดีต้อนรับสู่ Dev-Cut — ลากไฟล์คลิปมาวางที่หน้าต่างนี้ หรือพิมพ์สั่งงานได้เลย เช่น: ตัดคลิป F:\clips\video.mp4 ใส่ซับไทย ลง TikTok"
    SysMsg "ครั้งแรกของเครื่อง: ถ้ายังไม่เคยล็อกอิน Claude ระบบจะเปิดหน้าต่างล็อกอินให้เองอัตโนมัติ"
}
Refresh
$C.InputBox.Focus() | Out-Null
$Win.ShowDialog() | Out-Null
