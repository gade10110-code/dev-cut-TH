#!/usr/bin/env python3
"""Dev-Cut - สร้างรูปพรีวิวสไตล์ซับ (ให้ผู้ใช้เห็นภาพจริงก่อนเลือกในโปรแกรม)
render ซับไทยด้วยฟอนต์ LINE Seed + karaoke ไฮไลต์ ตามแต่ละ preset — ออกเป็น PNG ลง launcher/previews/
รันครั้งเดียว (หรือเมื่อปรับสไตล์): python launcher/gen_style_previews.py
"""
import os, sys
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

OUT = Path(__file__).with_name("previews")
OUT.mkdir(exist_ok=True)

W, H = 300, 500                       # การ์ดแนวตั้ง 9:16
HILITE = (255, 230, 0)               # เหลือง karaoke (#ffe600)


def font_path(weight):
    """หาไฟล์ LINE Seed ในเครื่อง (เลี่ยงไฟล์ขยะ ._ ของ macOS)"""
    dirs = [Path(os.environ.get("LOCALAPPDATA", "")) / "Microsoft" / "Windows" / "Fonts",
            Path("C:/Windows/Fonts")]
    want = {"bd": "_bd", "xbd": "_xbd", "rg": "_rg"}[weight]
    hits = []
    for d in dirs:
        if d.exists():
            for p in d.rglob("*"):
                s = p.stem.replace(" ", "").lower()
                if (p.suffix.lower() in (".ttf", ".otf") and "lineseedsansth" in s
                        and not p.name.startswith("._") and p.stat().st_size > 10000):
                    hits.append((s, str(p)))
    for s, f in hits:
        if want in s:
            return f
    return hits[0][1] if hits else None


def vgrad(w, h, top, bot):
    """พื้นหลังไล่สี (จำลองเฟรมวิดีโอ)"""
    img = Image.new("RGB", (w, h))
    px = img.load()
    for y in range(h):
        t = y / max(1, h - 1)
        px_row = tuple(int(top[i] + (bot[i] - top[i]) * t) for i in range(3))
        for x in range(w):
            px[x, y] = px_row
    return img


def draw_words(draw, words, cy, font, stroke_w, stroke_fill):
    """วาดบรรทัดคำแบบจัดกึ่งกลาง + ระบายคำที่ไฮไลต์คนละสี (จำลอง karaoke)"""
    widths = [draw.textlength(w + " ", font=font) for w, _ in words]
    x = (W - sum(widths)) / 2
    for (word, hi), wdt in zip(words, widths):
        color = HILITE if hi else (255, 255, 255)
        draw.text((x, cy), word, font=font, fill=color,
                  stroke_width=stroke_w, stroke_fill=stroke_fill)
        x += wdt


def render(name, label, weight, size, stroke_w, box, badge_color):
    img = vgrad(W, H, (28, 32, 44), (12, 14, 20))
    d = ImageDraw.Draw(img, "RGBA")

    # แถบชื่อสไตล์บนหัว
    bf = ImageFont.truetype(font_path("bd"), 20)
    d.rounded_rectangle([14, 14, 14 + d.textlength(label, font=bf) + 24, 46],
                        radius=10, fill=badge_color)
    d.text((26, 18), label, font=bf, fill=(255, 255, 255))

    # ซับไตเติล 2 บรรทัด (บรรทัด 2 มีคำไฮไลต์ = karaoke)
    f = ImageFont.truetype(font_path(weight), size)
    line1 = [("ตัดคลิป", False), ("ยังไง", False)]
    line2 = [("ให้", False), ("ปัง", True), ("สุด", False)]
    y1, y2 = H - 150, H - 150 + size + 12

    if box:                              # pop: กล่องทึบหลังคำ
        for cy in (y1, y2):
            words = line1 if cy == y1 else line2
            tw = sum(d.textlength(w + " ", font=f) for w, _ in words)
            d.rounded_rectangle([(W - tw) / 2 - 16, cy - 6, (W + tw) / 2 + 8, cy + size + 8],
                                radius=14, fill=(0, 0, 0, 150))

    draw_words(d, line1, y1, f, stroke_w, (0, 0, 0))
    draw_words(d, line2, y2, f, stroke_w, (0, 0, 0))

    out = OUT / f"{name}.png"
    img.save(out)
    print(f"OK: {out}")


def make_sub_thumb(name):
    """thumbnail สี่เหลี่ยม (โชว์ซับจริง + karaoke) — ไว้ใช้เป็นรูปฟีเจอร์ 'สไตล์ซับ' แทนไอคอน"""
    S = 120
    img = vgrad(S, S, (32, 36, 46), (14, 16, 21)).convert("RGBA")
    mask = Image.new("L", (S, S), 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, S - 1, S - 1], radius=24, fill=255)
    img.putalpha(mask)
    d = ImageDraw.Draw(img)
    f = ImageFont.truetype(font_path("xbd"), 34)
    words = [("ตัด", False), ("ปัง", True)]
    widths = [d.textlength(w + " ", font=f) for w, _ in words]
    x = (S - sum(widths)) / 2
    y = (S - 34) / 2 - 4
    for (word, hi), wd in zip(words, widths):
        color = HILITE if hi else (255, 255, 255)
        d.text((x, y), word, font=f, fill=color, stroke_width=4, stroke_fill=(0, 0, 0))
        x += wd
    img.save(OUT / f"{name}.png")
    print(f"OK: {OUT / (name + '.png')}")


def main():
    if not font_path("bd"):
        sys.exit("ไม่พบฟอนต์ LINE Seed — ติดตั้งก่อน (INSTALL/fonts)")
    # name, label, weight, size, stroke, box, badge
    render("clean", "Clean · YouTube", "rg", 30, 2, False, (37, 99, 235))
    render("bold",  "Bold · TikTok",   "bd", 38, 6, False, (225, 29, 72))
    render("pop",   "Pop · Viral",     "xbd", 40, 3, True, (168, 85, 247))
    make_sub_thumb("feat_style")         # รูปฟีเจอร์ 'เลือกสไตล์ซับ' (ซับจริง ไม่ใช่ไอคอน)
    print("เสร็จ — พรีวิว 3 สไตล์ + thumbnail สไตล์ ใน launcher/previews/")


if __name__ == "__main__":
    main()
