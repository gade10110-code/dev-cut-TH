﻿# Dev-Cut bootstrap — เปิด launcher พร้อมดักจับ error ให้มองเห็น
try {
    & (Join-Path $PSScriptRoot "launcher.ps1")
} catch {
    $log = Join-Path $PSScriptRoot "error.log"
    (($_ | Out-String) + "`n--- stack ---`n" + $_.ScriptStackTrace) |
        Out-File $log -Encoding utf8
    try {
        Add-Type -AssemblyName PresentationFramework
        [void][System.Windows.MessageBox]::Show(
            "เปิด Dev-Cut ไม่สำเร็จ:`n`n" + $_.Exception.Message +
            "`n`nรายละเอียดถูกบันทึกไว้ที่ launcher\error.log",
            "Dev-Cut")
    } catch { }
}
