#!/usr/bin/env python3
"""Dev-Cut - สร้าง thumbnail ไอคอนต่อฟีเจอร์ (ไอคอน Lucide บนการ์ดไล่สี) ไว้โชว์ในหน้า 'ฟีเจอร์'
ออกเป็น launcher/previews/feat_<icon>.png — รันครั้งเดียว (หรือเมื่อเพิ่มฟีเจอร์): python launcher/gen_feature_thumbs.py
"""
import sys
from io import BytesIO
from pathlib import Path
from PIL import Image, ImageDraw

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

ICON_DIR = Path(__file__).resolve().parents[1] / "icons" / "lucide"
OUT = Path(__file__).with_name("previews")
OUT.mkdir(exist_ok=True)
S = 120

# (icon Lucide, สีแอคเซนต์) — ต้องเรียงตรงกับ $Features ใน launcher.ps1 (ใช้ชื่อ icon เป็น key)
FEATURES = [
    ("scissors", "#e11d48"), ("captions", "#3b82f6"), ("audio-lines", "#a855f7"),
    ("sparkles", "#f59e0b"), ("replace", "#14b8a6"), ("palette", "#ec4899"),
    ("highlighter", "#eab308"), ("volume-2", "#f97316"), ("music", "#6366f1"),
    ("eraser", "#06b6d4"), ("layout-template", "#8b5cf6"), ("shapes", "#f43f5e"),
    ("music-4", "#22c55e"), ("image", "#0ea5e9"), ("chart-column", "#84cc16"),
    ("file-output", "#64748b"),
]


def hex2rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def render_icon(name, size, color="#ffffff"):
    import resvg_py
    svg = (ICON_DIR / f"{name}.svg").read_text(encoding="utf-8")
    svg = svg.replace('stroke="currentColor"', f'stroke="{color}"')
    svg = svg.replace('stroke-width="2"', 'stroke-width="2.2"')
    data = resvg_py.svg_to_bytes(svg_string=svg, width=size, height=size)
    raw = bytes(data) if isinstance(data, (list, bytearray)) else data
    return Image.open(BytesIO(raw)).convert("RGBA")


def make_thumb(icon, color):
    top = hex2rgb(color)
    bot = tuple(int(c * 0.42) for c in top)
    card = Image.new("RGBA", (S, S))
    px = card.load()
    for y in range(S):
        t = y / (S - 1)
        row = tuple(int(top[i] + (bot[i] - top[i]) * t) for i in range(3)) + (255,)
        for x in range(S):
            px[x, y] = row
    mask = Image.new("L", (S, S), 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, S - 1, S - 1], radius=24, fill=255)
    card.putalpha(mask)
    ic = render_icon(icon, 60)
    card.alpha_composite(ic, ((S - 60) // 2, (S - 60) // 2))
    return card


def main():
    try:
        import resvg_py  # noqa: F401
    except ImportError:
        sys.exit("ยังไม่ได้ติดตั้ง resvg-py — รัน: pip install resvg-py")
    for icon, color in FEATURES:
        if not (ICON_DIR / f"{icon}.svg").exists():
            print(f"ข้าม: ไม่พบไอคอน {icon}")
            continue
        make_thumb(icon, color).save(OUT / f"feat_{icon}.png")
    print(f"OK: สร้าง thumbnail {len(FEATURES)} ฟีเจอร์ ที่ {OUT}")


if __name__ == "__main__":
    main()
