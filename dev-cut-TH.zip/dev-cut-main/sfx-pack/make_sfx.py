#!/usr/bin/env python3
"""Dev-Cut Kit - sfx-pack generator: สังเคราะห์เสียง SFX ทั้งแพ็กด้วยโค้ดล้วน ๆ
เสียงทุกไฟล์ในโฟลเดอร์นี้สร้างจากสคริปต์นี้ = ลิขสิทธิ์ของเจ้าของ kit 100%
รันซ้ำได้ทุกเมื่อ: python make_sfx.py   (อยากปรับโทน แก้พารามิเตอร์ในแต่ละฟังก์ชันได้เลย)
"""
import numpy as np
import wave
from pathlib import Path

import sys as _sys
if hasattr(_sys.stdout, "reconfigure"):  # กัน error ภาษาไทยบน Windows codepage
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace")


SR = 44100
OUT = Path(__file__).parent


def save(name, x, gain=0.9):
    x = np.asarray(x, dtype=np.float64)
    peak = np.max(np.abs(x)) or 1.0
    x = (x / peak * gain * 32767).astype(np.int16)
    with wave.open(str(OUT / f"{name}.wav"), "w") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes(x.tobytes())
    print(f"  {name}.wav ({len(x)/SR:.2f}s)")


def t(dur):
    return np.linspace(0, dur, int(SR * dur), endpoint=False)


def env_exp(dur, decay):
    return np.exp(-t(dur) * decay)


def noise(dur):
    rng = np.random.default_rng(42)
    return rng.standard_normal(int(SR * dur))


def bandpass_sweep(x, f_start, f_end, q=2.0):
    """simple time-varying one-pole resonator sweep"""
    out = np.zeros_like(x)
    n = len(x)
    y1 = y2 = 0.0
    for i in range(n):
        f = f_start + (f_end - f_start) * i / n
        w = 2 * np.pi * f / SR
        r = 1 - w / (2 * q)
        a = 2 * r * np.cos(w)
        b = r * r
        y = x[i] * (1 - r) + a * y1 - b * y2
        y2, y1 = y1, y
        out[i] = y
    return out


def sine(freq, dur, phase=0.0):
    return np.sin(2 * np.pi * freq * t(dur) + phase)


def chirp(f0, f1, dur):
    tt = t(dur)
    freqs = f0 * (f1 / f0) ** (tt / dur)
    phase = 2 * np.pi * np.cumsum(freqs) / SR
    return np.sin(phase)


print("== Dev-Cut sfx-pack generator ==")

# ---- transitions ----
save("whoosh_fast", bandpass_sweep(noise(0.45), 400, 3500) * env_exp(0.45, 6) * np.minimum(t(0.45) * 30, 1))
save("whoosh_soft", bandpass_sweep(noise(0.8), 200, 1200, q=1.5) * np.sin(np.pi * t(0.8) / 0.8) ** 2)
save("swoosh_reverse", bandpass_sweep(noise(0.6), 2500, 300) * np.minimum(t(0.6) * 4, 1) * env_exp(0.6, 3)[::-1])
save("riser_short", chirp(150, 1400, 1.2) * np.minimum(t(1.2), 1) * 0.7 + bandpass_sweep(noise(1.2), 300, 4000) * t(1.2) / 1.2 * 0.5)
save("transition_hit", (sine(60, 0.7) + sine(90, 0.7) * 0.5 + noise(0.7) * 0.3) * env_exp(0.7, 9))

# ---- pops & clicks ----
save("pop", chirp(900, 300, 0.09) * env_exp(0.09, 45))
save("pop_double", np.concatenate([chirp(900, 300, 0.08) * env_exp(0.08, 45), np.zeros(int(SR*0.07)), chirp(1100, 400, 0.08) * env_exp(0.08, 45)]))
save("click_soft", noise(0.03) * env_exp(0.03, 160) + sine(2000, 0.03) * env_exp(0.03, 120) * 0.4)
save("camera_shutter", np.concatenate([noise(0.02) * env_exp(0.02, 200), np.zeros(int(SR*0.04)), noise(0.05) * env_exp(0.05, 90)]))

# ---- dings & notifications ----
save("ding", (sine(880, 1.0) + sine(1760, 1.0) * 0.4 + sine(2640, 1.0) * 0.15) * env_exp(1.0, 4))
save("ding_high", (sine(1318.5, 0.8) + sine(2637, 0.8) * 0.3) * env_exp(0.8, 5))
save("chime_up", np.concatenate([(sine(f, 0.35) + sine(2*f, 0.35)*0.3) * env_exp(0.35, 7) for f in [523.25, 659.25, 783.99]]))
save("notification", np.concatenate([(sine(987.77, 0.12)) * env_exp(0.12, 18), (sine(1318.5, 0.3)) * env_exp(0.3, 8)]))

# ---- success / error ----
save("success", np.concatenate([(sine(523.25, 0.13) + sine(1046.5, 0.13)*0.3) * env_exp(0.13, 12), (sine(783.99, 0.4) + sine(1567.98, 0.4)*0.3) * env_exp(0.4, 6)]))
save("error_buzz", (sine(180, 0.35) * (1 + 0.6 * sine(30, 0.35))) * env_exp(0.35, 6))

# ---- impacts / bass ----
save("impact_deep", (chirp(120, 40, 0.8) + noise(0.8) * 0.15 * env_exp(0.8, 20)) * env_exp(0.8, 6))
save("thud", chirp(150, 55, 0.3) * env_exp(0.3, 14))
save("boom_sub", chirp(80, 35, 1.4) * env_exp(1.4, 3.5))

print("เสร็จ! เสียงทั้งหมดเป็นลิขสิทธิ์ของคุณ ใช้/ขาย/แจกได้อิสระ")
