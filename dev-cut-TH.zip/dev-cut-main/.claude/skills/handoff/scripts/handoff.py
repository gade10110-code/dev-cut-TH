#!/usr/bin/env python3
"""Dev-Cut Kit - handoff: สรุปงานตัดต่อเป็นแพ็กเกจส่งต่อ — รายงาน markdown + SRT + EDL
ใช้ตอนส่งงานให้ editor คนอื่น หรือเก็บบันทึกว่า AI ตัดอะไรไปบ้าง
Usage:
  python handoff.py --work-dir work/ --title "คลิปรีวิว EP1"
"""
import argparse, json
from datetime import datetime, timezone, timedelta
from pathlib import Path

import sys as _sys
if hasattr(_sys.stdout, "reconfigure"):  # กัน error ภาษาไทยบน Windows codepage
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace")



def fmt_tc(sec, fps=30):
    h, rem = divmod(sec, 3600); m, s = divmod(rem, 60)
    f = int((s % 1) * fps)
    return f"{int(h):02}:{int(m):02}:{int(s):02}:{f:02}"


def make_edl(plan, fps=30):
    """CMX3600-style EDL จาก cutplan (โปรแกรมตัดต่อส่วนใหญ่ import ได้)"""
    lines = ["TITLE: DEVCUT_CLEANCUT", "FCM: NON-DROP FRAME", ""]
    t = 0.0
    for i, k in enumerate(plan["keeps"], 1):
        dur = k["end"] - k["start"]
        lines.append(f"{i:03}  AX       V     C        "
                     f"{fmt_tc(k['start'], fps)} {fmt_tc(k['end'], fps)} "
                     f"{fmt_tc(t, fps)} {fmt_tc(t + dur, fps)}")
        t += dur
    return "\n".join(lines) + "\n"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--work-dir", default=".")
    ap.add_argument("--title", default="Dev-Cut Project")
    ap.add_argument("--fps", type=int, default=30)
    args = ap.parse_args()

    wd = Path(args.work_dir)
    out = wd / "handoff"; out.mkdir(parents=True, exist_ok=True)
    now = datetime.now(timezone(timedelta(hours=7))).strftime("%Y-%m-%d %H:%M")

    plan = json.loads((wd / "cutplan.json").read_text(encoding="utf-8")) \
        if (wd / "cutplan.json").exists() else None
    analysis = json.loads((wd / "analysis.json").read_text(encoding="utf-8")) \
        if (wd / "analysis.json").exists() else None
    transcript = json.loads((wd / "transcript.json").read_text(encoding="utf-8")) \
        if (wd / "transcript.json").exists() else None
    credits = json.loads((wd / "assets" / "credits.json").read_text(encoding="utf-8")) \
        if (wd / "assets" / "credits.json").exists() else []

    md = [f"# Handoff: {args.title}", f"_สร้างเมื่อ {now} (Dev-Cut Kit)_", ""]
    if analysis:
        i = analysis["info"]
        md += ["## ข้อมูลต้นฉบับ",
               f"- ไฟล์: `{analysis['source']}`",
               f"- ความยาว {i['duration']:.1f}s, {i['video']['width']}x{i['video']['height']} "
               f"@{i['video']['fps']}fps",
               f"- ความดังเฉลี่ย: {analysis.get('loudness', {}).get('integrated_lufs', 'n/a')} LUFS", ""]
    if plan:
        md += ["## การตัด (clean-cut)",
               f"- ต้นฉบับ {plan['source_duration']}s → เหลือ {plan['kept_duration']}s "
               f"(ตัดออก {plan['removed_duration']}s)",
               f"- จำนวนช่วง keep: {len(plan['keeps'])}",
               f"- พารามิเตอร์: เงียบต่ำกว่า {plan['params']['noise_db']}dB "
               f"นานเกิน {plan['params']['min_silence']}s", ""]
        (out / "cuts.edl").write_text(make_edl(plan, args.fps), encoding="utf-8")
    if transcript:
        md += ["## Transcript",
               f"- engine: {transcript['engine']}, ภาษา: {transcript.get('language')}",
               f"- {len(transcript.get('words', []))} คำ, "
               f"{len(transcript.get('segments', []))} ช่วงซับ", "",
               "> " + transcript.get("text", "")[:500] + ("..." if len(transcript.get("text", "")) > 500 else ""), ""]
    if credits:
        md += ["## เครดิต asset ที่ใช้ (ต้องใส่ใน description)"]
        md += [f"- {c['credit']} — {c['page']}" for c in credits]
        md += [""]
    md += ["## ไฟล์ในแพ็กเกจนี้",
           "- `cuts.edl` — import เข้าโปรแกรมตัดต่ออื่นได้" if plan else "",
           "- `captions.srt` — ไฟล์ซับ" if (wd / "captions.srt").exists() else "",
           "- `report.md` — ไฟล์นี้"]

    (out / "report.md").write_text("\n".join(x for x in md if x is not None), encoding="utf-8")
    if (wd / "captions.srt").exists():
        (out / "captions.srt").write_text((wd / "captions.srt").read_text(encoding="utf-8"),
                                          encoding="utf-8")
    print(f"OK: {out}/report.md" + (", cuts.edl" if plan else "") +
          (", captions.srt" if (wd / "captions.srt").exists() else ""))


if __name__ == "__main__":
    main()
