---
name: handoff
description: สรุปงานตัดต่อทั้งหมดเป็นแพ็กเกจส่งต่อ — รายงาน markdown, ไฟล์ซับ .srt, EDL สำหรับ import เข้าโปรแกรมอื่น ใช้เมื่อจบงาน, ผู้ใช้ขอ "สรุปงาน", "ส่งต่อให้ editor", "export edl", หรือขอบันทึกว่า AI ทำอะไรไปบ้าง
---

# handoff — ส่งมอบงาน

## วิธีใช้

```bash
python scripts/handoff.py --work-dir <work> --title "<ชื่อโปรเจกต์>"
```

รวบรวมทุกอย่างใน work dir (`analysis.json`, `cutplan.json`, `transcript.json`, `assets/credits.json`)
เป็นโฟลเดอร์ `<work>/handoff/`:

- `report.md` — สรุปการตัด สถิติ transcript และเครดิต asset
- `cuts.edl` — แผนการตัดแบบ CMX3600 (Premiere / Resolve import ได้)
- `captions.srt` — ไฟล์ซับ

## หลังรันเสร็จ

1. แจ้งผู้ใช้ว่าไฟล์อยู่ไหน และย้ำเรื่อง**เครดิต asset** ถ้ามีการใช้ find-assets
2. `--fps` ควรตรงกับ fps ของ footage (ดูจาก analysis.json) เพื่อให้ timecode ใน EDL ตรง
3. ถ้าผู้ใช้ทำงานคนเดียวและไม่ต้อง export ไปโปรแกรมอื่น skill นี้เป็น optional — อย่ารันโดยไม่จำเป็น
