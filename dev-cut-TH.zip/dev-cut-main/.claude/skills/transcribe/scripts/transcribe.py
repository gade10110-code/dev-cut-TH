#!/usr/bin/env python3
"""Dev-Cut Kit - transcribe: ถอดเสียงวิดีโอ/ออดิโอเป็น transcript.json + .srt
Engines: elevenlabs (แม่นสุดสำหรับภาษาไทย, ต้องมี ELEVENLABS_API_KEY) | whisper (ฟรี, ออฟไลน์)
Usage:
  python transcribe.py input.mp4 --engine elevenlabs --lang th --out-dir work/
"""
import argparse, json, os, re, shutil, subprocess, sys, tempfile
from pathlib import Path

import sys as _sys
if hasattr(_sys.stdout, "reconfigure"):  # กัน error ภาษาไทยบน Windows codepage
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace")



def load_env():
    """Load .env from cwd or kit root without external deps."""
    for p in [Path.cwd() / ".env", Path(__file__).resolve().parents[4] / ".env"]:
        if p.exists():
            for line in p.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, _, v = line.partition("=")
                    os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


def extract_audio(src: str) -> str:
    """Extract mono 16k wav for smaller upload / faster whisper."""
    out = tempfile.mktemp(suffix=".wav")
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", src, "-vn", "-ac", "1",
                    "-ar", "16000", out], check=True)
    return out


def _ffprobe_duration(path):
    try:
        r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                            "-of", "default=nw=1:nk=1", path], capture_output=True, text=True)
        return float(r.stdout.strip())
    except (ValueError, OSError):
        return 0.0


def detect_music(audio_path, thr_db=-30, min_sil=0.3, ratio_cut=0.06):
    """เดาว่าคลิปมีเพลง/เสียงดังต่อเนื่องไหม — วัดสัดส่วน 'ความเงียบ'
    (คลิปพูดปกติมีช่วงหยุดหายใจ = เงียบเป็นพัก ๆ / เพลงคลอตลอด = แทบไม่เงียบเลย)"""
    dur = _ffprobe_duration(audio_path)
    if dur <= 0:
        return False
    try:
        r = subprocess.run(["ffmpeg", "-hide_banner", "-i", audio_path, "-af",
                            f"silencedetect=noise={thr_db}dB:d={min_sil}", "-f", "null", "-"],
                           capture_output=True, text=True)
    except OSError:
        return False
    sil = sum(float(x) for x in re.findall(r"silence_duration:\s*([0-9.]+)", r.stderr))
    return (sil / dur) < ratio_cut


def demucs_available():
    import importlib.util
    return importlib.util.find_spec("demucs") is not None


def run_separation(src, out_dir):
    """เรียก separate_vocals.py แยกเสียงพูด → คืน path ของ vocals.wav"""
    sep = Path(__file__).with_name("separate_vocals.py")
    subprocess.run([sys.executable, str(sep), src, "--out-dir", str(out_dir)], check=True)
    return str(Path(out_dir) / "vocals.wav")


def run_elevenlabs(audio_path: str, lang: str):
    import requests
    key = os.environ.get("ELEVENLABS_API_KEY")
    if not key:
        sys.exit("ไม่พบ ELEVENLABS_API_KEY ใน .env — ใส่ key ก่อน หรือใช้ --engine whisper")
    with open(audio_path, "rb") as f:
        r = requests.post(
            "https://api.elevenlabs.io/v1/speech-to-text",
            headers={"xi-api-key": key},
            data={"model_id": "scribe_v1", "language_code": lang or "",
                  "timestamps_granularity": "word", "diarize": "false"},
            files={"file": (os.path.basename(audio_path), f, "audio/wav")},
            timeout=600,
        )
    if r.status_code != 200:
        sys.exit(f"ElevenLabs error {r.status_code}: {r.text[:300]}")
    data = r.json()
    words = [{"w": w.get("text", ""), "start": w.get("start", 0.0), "end": w.get("end", 0.0)}
             for w in data.get("words", []) if w.get("type", "word") == "word"]
    return {"engine": "elevenlabs", "language": data.get("language_code", lang),
            "text": data.get("text", ""), "words": words}


# เก็บโมเดลไว้ในโฟลเดอร์ kit เอง (กันปัญหาไดรฟ์ C: เต็ม) — ผู้ใช้ override ได้ด้วย HF_HOME ใน .env
_KIT_ROOT = Path(__file__).resolve().parents[4]
os.environ.setdefault("HF_HOME", str(_KIT_ROOT / "models"))

PROGRESS_FILE = Path(tempfile.gettempdir()) / "devcut_progress.txt"


def write_progress(pct: int, label: str):
    """รายงานความคืบหน้าให้โปรแกรม Dev-Cut แสดงเป็นหลอด (พังก็ไม่เป็นไร)"""
    try:
        PROGRESS_FILE.write_text(f"{min(99, max(0, pct))}|{label}", encoding="utf-8")
    except OSError:
        pass


def _fmt(sec):
    return f"{int(sec // 60)}:{int(sec % 60):02d}"


def _load_model(model_size, compute_type, cpu_threads):
    """โหลด WhisperModel พร้อม fallback 2 ชั้น: compute_type ที่เครื่องไม่รองรับ → int8,
    และโมเดลไทยโหลดไม่ได้ (เน็ต/ดิสก์) → large-v3 มาตรฐาน"""
    from faster_whisper import WhisperModel
    for ct in (compute_type, "int8"):        # ถ้า compute_type แปลก ๆ เครื่องไม่รับ ถอยมา int8
        try:
            return WhisperModel(model_size, device="auto", compute_type=ct,
                                cpu_threads=cpu_threads)
        except ValueError:
            continue                          # compute_type ไม่รองรับบน device นี้ → ลองตัวถัดไป
        except Exception as e:
            if "/" in model_size:             # โมเดลไทยจาก HF โหลดไม่ได้ → ใช้ large-v3
                print(f"โหลดโมเดล '{model_size}' ไม่สำเร็จ ({e}) — ใช้ large-v3 มาตรฐานแทน")
                return WhisperModel("large-v3", device="auto", compute_type="int8",
                                    cpu_threads=cpu_threads)
            raise
    raise RuntimeError(f"โหลดโมเดล {model_size} ไม่สำเร็จ")


def run_whisper(audio_path: str, lang: str, model_size: str, hint: str = "",
                accuracy: str = "fast", compute_type: str = None):
    try:
        from faster_whisper import WhisperModel  # noqa: F401
    except ImportError:
        sys.exit("ยังไม่ได้ติดตั้ง faster-whisper — รัน: pip install faster-whisper")
    cpu_threads = os.cpu_count() or 4
    # int8 = เร็วสุดบน CPU / high ดันเป็น int8_float32 (แม่นขึ้น เครื่องไม่รับจะถอยเป็น int8 เอง)
    ct = compute_type or ("int8_float32" if accuracy == "high" else "int8")
    write_progress(0, "กำลังโหลดโมเดลถอดเสียง...")
    model = _load_model(model_size, ct, cpu_threads)

    tx = dict(language=lang or None, word_timestamps=True, vad_filter=True,
              hotwords=(hint or None))
    if accuracy == "high":
        # เฉพาะตัวที่ต่างจาก default จริงและช่วยความแม่น (temperature/threshold อื่น ๆ ตรง default อยู่แล้ว):
        #   beam_size กว้างขึ้น = ค้นทางเลือกมากขึ้น
        #   condition_on_previous_text=False = กันคำผิด/ซ้ำลามต่อกันบนเสียงยาก (พูดเร็ว/มีเพลง)
        #   initial_prompt = ใช้คำใบ้ช่วยสะกดชื่อเฉพาะ/คำทับศัพท์
        tx.update(beam_size=8, condition_on_previous_text=False,
                  initial_prompt=(hint or None))
    segments, info = model.transcribe(audio_path, **tx)
    total = info.duration or 1.0
    words, text_parts, raw_segments = [], [], []
    for seg in segments:
        stext = seg.text.strip()
        text_parts.append(stext)
        raw_segments.append({"text": stext, "start": round(seg.start, 3),
                             "end": round(seg.end, 3)})
        for w in seg.words or []:
            words.append({"w": w.word.strip(), "start": round(w.start, 3), "end": round(w.end, 3)})
        write_progress(int(seg.end / total * 100),
                       f"ถอดเสียง {_fmt(seg.end)}/{_fmt(total)}")
    try:
        PROGRESS_FILE.unlink()
    except OSError:
        pass
    return {"engine": f"whisper-{model_size}", "language": info.language,
            "text": " ".join(text_parts), "words": words, "raw_segments": raw_segments}


def _thai_tokens(t):
    """แตกข้อความเป็น 'คำ' ด้วย pythainlp (dictionary มากับตัว) — ต่อกันแล้วได้ข้อความเดิม
    ถ้าไม่มี pythainlp คืน None (ผู้เรียกจะ fallback เป็นตัดที่เว้นวรรคแทน)"""
    try:
        from pythainlp.tokenize import word_tokenize
        return word_tokenize(t, keep_whitespace=True)
    except Exception:
        return None


def _split_text(t, max_chars):
    """หั่นวลียาวเกินเป็นหลายบรรทัดโดย 'ไม่ตัดกลางคำไทย'
    - มี pythainlp → แพ็กทีละคำจริงจนเต็มบรรทัด
    - ไม่มี → ตัดที่เว้นวรรค; ถ้าช่วงเดียวยังยาวเกินก็เก็บทั้งช่วง (ยอมยาว ดีกว่าคำขาด)"""
    toks = _thai_tokens(t)
    if toks is None:                               # fallback: ยึดเว้นวรรคเป็นขอบ
        toks, parts = [], t.split(" ")
        for i, p in enumerate(parts):
            if i:
                toks.append(" ")
            toks.append(p)
    lines, cur = [], ""
    for tok in toks:
        if not tok:
            continue
        if not cur:
            cur = tok
        elif len(cur) + len(tok) <= max_chars:
            cur += tok
        else:
            lines.append(cur.strip()); cur = tok.lstrip()
    if cur.strip():
        lines.append(cur.strip())
    return lines or [t]


def build_captions(raw_segments, max_chars=32, max_gap=0.8):
    """สร้างซับจาก 'วลี' ที่โมเดลแบ่งมาเอง (สะกดครบ ไม่ตัดกลางคำ)
    - รวมวลีสั้นที่ติดกัน (ถ้าเสียงต่อเนื่องและรวมแล้วไม่ยาวเกิน) กันซับกระพริบถี่
    - หั่นวลีที่ยาวเกินที่ขอบคำ แบ่งเวลาตามสัดส่วนความยาว"""
    merged = []
    for s in raw_segments:
        if (merged and s["start"] - merged[-1]["end"] <= max_gap
                and len(merged[-1]["text"]) + 1 + len(s["text"]) <= max_chars):
            merged[-1]["text"] += " " + s["text"]
            merged[-1]["end"] = s["end"]
        else:
            merged.append(dict(s))

    out = []
    for s in merged:
        t = s["text"].strip()
        if len(t) <= max_chars:
            out.append({"text": t, "start": s["start"], "end": s["end"]})
            continue
        pieces = _split_text(t, max_chars)
        dur = max(s["end"] - s["start"], 0.001)
        total = sum(len(p) for p in pieces) or 1
        acc = s["start"]
        for p in pieces:
            seg_dur = dur * len(p) / total
            out.append({"text": p, "start": round(acc, 3), "end": round(acc + seg_dur, 3)})
            acc += seg_dur
    return out


def build_captions_from_words(words, max_chars=28, pause_gap=0.5):
    """สร้างบรรทัดซับจากคำที่มีเวลาจริง (refined/aligned) — 'พอดีกับเสียง'
    ขึ้นบรรทัดใหม่เมื่อ: เจอจังหวะหยุดพูด (ช่องว่างระหว่างคำ > pause_gap) หรือยาวเกิน max_chars
    เวลาบรรทัด = เวลาคำจริง → แก้ทั้ง 'ซับมาก่อนเสียง' และ 'บรรทัดยาวค้างจอ'
    words: [{'text','start','end'}, ...] เรียงเวลาแล้ว"""
    lines, cur = [], []

    def flush():
        if cur:
            lines.append({"text": "".join(w["text"] for w in cur),
                          "start": cur[0]["start"],
                          "end": max(cur[-1]["end"], cur[0]["start"] + 0.2),
                          "words": [dict(w) for w in cur]})

    for w in words:
        if cur:
            curlen = sum(len(x["text"]) for x in cur)
            if (w["start"] - cur[-1]["end"] > pause_gap
                    or curlen + len(w["text"]) > max_chars):
                flush(); cur = []
        cur.append(w)
    flush()
    return lines


def _char_times(words):
    """แผนที่เวลาแบบรายตัวอักษร (เกลี่ยเชิงเส้นภายในแต่ละคำ) สำหรับ reconstruct วลี→เวลา"""
    starts, ends = [], []
    for w in words:
        s, e, L = w["start"], w["end"], len(w["w"]) or 1
        for i in range(len(w["w"])):
            starts.append(s + (e - s) * i / L)
            ends.append(s + (e - s) * (i + 1) / L)
    return starts, ends


def reconstruct_raw_segments(text, words):
    """เผื่อ transcript เก่าที่ไม่มี raw_segments — สร้างวลี+เวลากลับจาก text (มีเว้นวรรค) + words"""
    starts, ends = _char_times(words)
    segs, pos = [], 0
    for ph in text.split():
        n = len(ph)
        if pos + n > len(starts):
            break
        segs.append({"text": ph, "start": round(starts[pos], 3),
                     "end": round(ends[pos + n - 1], 3)})
        pos += n
    return segs


def _thai_word_times(text, starts, ends):
    """map ตำแหน่งตัวอักษร→เวลา ให้เป็นเวลาราย 'คำไทย' (ตัดด้วย pythainlp) + de-overlap
    starts/ends: เวลาต่อตัวอักษร (index ตรงกับ text ที่ตัดเว้นวรรคออก) — มาจาก whisper หรือ forced alignment"""
    toks = _thai_tokens(text)
    if toks is None:                     # ไม่มี pythainlp → ใช้ช่วงคั่นเว้นวรรคเป็นหน่วย
        toks = text.split()
    out, pos = [], 0
    for tk in toks:
        if not tk.strip():               # โทเคนเว้นวรรค — ไม่มีใน char-times ข้าม
            continue
        n = len(tk)
        if pos + n > len(starts):
            break
        out.append({"text": tk, "start": round(starts[pos], 3),
                    "end": round(ends[pos + n - 1], 3)})
        pos += n
    # de-overlap: char-time หยาบ/ซ้ำทำให้คำเหลื่อม → บังคับคำต่อกันไม่ทับ
    # (start[i] ≥ end[i-1], end > start) karaoke/การตัดจะไม่ไฮไลต์คำก่อนหน้าค้าง
    prev_end = 0.0
    for w in out:
        if w["start"] < prev_end:
            w["start"] = round(prev_end, 3)
        if w["end"] <= w["start"]:
            w["end"] = round(w["start"] + 0.04, 3)
        prev_end = w["end"]
    return out


def word_timings(text, words):
    """เวลาเริ่ม/จบ 'จริง' ของแต่ละคำ — จาก char-timestamp ของ whisper
    (join(words) == text ไม่นับเว้นวรรค จึงแมปตำแหน่งตัวอักษร→เวลาได้ตรง)"""
    return _thai_word_times(text, *_char_times(words))


def _retime_by_chars(items, starts, ends):
    """ตั้งเวลา start/end ของแต่ละ item ('text' ต่อกัน = ข้อความเต็ม) จาก char-time ที่ให้มา — แก้ในที่
    ใช้กับ raw_segments (วลี) หลัง forced alignment ให้ขอบวลีตรงเสียงจริง"""
    pos = 0
    for it in items:
        t = re.sub(r"\s", "", it["text"])
        n = len(t)
        if n and pos + n <= len(starts):
            it["start"] = round(starts[pos], 3)
            it["end"] = round(ends[pos + n - 1], 3)
        pos += n
    return items


def attach_words(lines, wts):
    """ผูกเวลาคำจริง (word_timings แบบ flat) เข้าแต่ละบรรทัดซับตามลำดับ — บรรทัดหนึ่งได้ words ของตัวเอง"""
    wi = 0
    for ln in lines:
        target = re.sub(r"\s", "", ln["text"])
        acc, chosen = "", []
        while wi < len(wts) and len(acc) < len(target):
            acc += re.sub(r"\s", "", wts[wi]["text"])
            chosen.append(dict(wts[wi]))
            wi += 1
        ln["words"] = chosen
    return lines


def _speech_gate(audio_path, frame=0.025, hop=0.010, gate_frac=0.15, floor_pct=10):
    """คืน (speech: bool ต่อเฟรม, hop วินาที) จาก energy envelope ของไฟล์เสียง
    - RMS ต่อเฟรมด้วย cumulative-sum (เร็ว, หน่วยความจำ O(n))
    - threshold ปรับตามคลิป: noise floor (เปอร์เซ็นไทล์ต่ำ) + สัดส่วนช่วง dynamic
    ไม่มี numpy/soundfile → คืน None (ผู้เรียก skip refine แบบ graceful)"""
    try:
        import numpy as np
        import soundfile as sf
    except ImportError:
        return None
    try:
        audio, sr = sf.read(audio_path, dtype="float32")
    except Exception:
        return None
    if getattr(audio, "ndim", 1) > 1:
        audio = audio.mean(axis=1)
    n = len(audio)
    fl, hp = max(1, int(frame * sr)), max(1, int(hop * sr))
    if n < fl * 2:
        return None
    csum = np.concatenate(([0.0], np.cumsum(audio.astype(np.float64) ** 2)))
    nf = 1 + (n - fl) // hp
    starts = np.arange(nf) * hp
    env = np.sqrt((csum[starts + fl] - csum[starts]) / fl)
    mx = float(env.max())
    if mx <= 0:
        return None
    envn = env / mx
    floor = float(np.percentile(envn, floor_pct))
    thr = floor + gate_frac * (1.0 - floor)
    return (envn >= thr), float(hop)


def snap_boundaries(items, gate, window=0.15, lead=0.0):
    """snap ขอบเวลา (start→onset / end→offset ของพลังงานเสียงพูดจริง) — ทำให้ karaoke/การตัดคมขึ้น
    - ขยับเฉพาะเมื่อเจอ 'ขอบ' (frame ที่ speech สลับสถานะ) ภายในหน้าต่าง ±window ไม่งั้นคงค่าเดิม (ไม่ทำให้แย่ลง)
    - `lead`: ชดเชย early-bias ของ whisper (word start มักมาก่อนเสียงจริง ~80-200ms) —
      ใส่เฉพาะ start ที่ 'หา onset เสียงจริงไม่เจอ' (กลางวลีพูดเร็ว/snap พลาด) เพื่อ compose กับ acoustic snap ไม่ชนกัน
    - คงลำดับไม่ถอยหลัง + กันคำพลิก (end<=start) · แก้ items ในที่
    items: list ของ dict ที่มี key 'start','end' (วินาที) เรียงเวลาแล้ว"""
    if not items or not gate:
        return items
    speech, hop = gate
    nf = len(speech)
    W = max(1, int(round(window / hop)))

    def edge(t, onset):
        f0 = int(round(t / hop))
        lo, hi = max(1, f0 - W), min(nf - 1, f0 + W)
        best = None
        for f in range(lo, hi + 1):
            hit = (speech[f] and not speech[f - 1]) if onset else (speech[f - 1] and not speech[f])
            if hit and (best is None or abs(f - f0) < abs(best - f0)):
                best = f
        return best

    prev_start = 0.0
    for it in items:
        on = edge(it["start"], True)
        if on is not None:
            it["start"] = round(on * hop, 3)          # ขอบเสียงจริง — ใช้เลย ไม่ต้อง offset
        elif lead:
            it["start"] = round(it["start"] + lead, 3)  # ไม่มีขอบให้ยึด → ชดเชย early-bias
        off = edge(it["end"], False)
        if off is not None:
            it["end"] = round(off * hop, 3)
        if it["start"] < prev_start:
            it["start"] = prev_start
        if it["end"] <= it["start"]:
            it["end"] = round(it["start"] + 0.04, 3)
        prev_start = it["start"]
    return items


def to_srt(segments):
    def ts(t):
        h, rem = divmod(t, 3600); m, s = divmod(rem, 60)
        return f"{int(h):02}:{int(m):02}:{int(s):02},{int((s % 1) * 1000):03}"
    return "\n".join(f"{i+1}\n{ts(s['start'])} --> {ts(s['end'])}\n{s['text'].strip()}\n"
                     for i, s in enumerate(segments))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("--engine", choices=["auto", "elevenlabs", "whisper"], default="auto",
                    help="auto = ใช้ elevenlabs ถ้ามี key ใน .env, ไม่มีก็ใช้ whisper ฟรีอัตโนมัติ")
    ap.add_argument("--lang", default="th")
    ap.add_argument("--model", default=None,
                    help="whisper model (ค่าเริ่มต้น: โมเดลไทย Thonburian ถ้า lang=th, ไม่งั้น large-v3; "
                         "เครื่องช้าใช้ small)")
    ap.add_argument("--out-dir", default=".")
    ap.add_argument("--hint", default="",
                    help="คำใบ้: หัวข้อคลิป + ชื่อเฉพาะ/คำทับศัพท์ (ส่งแบบ hotwords ไม่รั่วเป็นซับ)")
    ap.add_argument("--separate-vocals", choices=["off", "auto", "on"], default="auto",
                    help="แยกเสียงพูดออกจากเพลงก่อนถอด (Demucs): auto (ปกติ) ตรวจเจอเพลงดังค่อยแยก | "
                         "on บังคับ | off ปิด — ช่วยคลิปเพลง/อนิเมะ/เกมให้ทั้งซับและ word timing แม่นขึ้น "
                         "(ไม่มีเพลง=ข้ามเอง แทบไม่เสียเวลา / ไม่มี Demucs=เตือนแล้วถอดต่อปกติ)")
    ap.add_argument("--accuracy", choices=["fast", "high"], default="fast",
                    help="fast = โมเดลกลาง เร็ว (ปกติ) | high = โมเดลใหญ่ไทย + จูน decoding "
                         "แม่นขึ้นตอนพูดเร็ว/ไม่ชัด แต่ช้าลง ~4-8x และครั้งแรกโหลดโมเดล ~1.5GB")
    ap.add_argument("--compute-type", default=None,
                    help="บังคับ compute_type ของ faster-whisper (เช่น float16 บน GPU) — ปกติเลือกให้อัตโนมัติ")
    ap.add_argument("--refine-words", choices=["on", "off"], default="on",
                    help="ปรับขอบเวลาคำ/วลีให้ตรงเสียงพูดจริงด้วย energy envelope (zero-dep) — "
                         "karaoke sync คมขึ้น + การตัดไม่กินคำ (on ปกติ / off ปิด)")
    ap.add_argument("--refine-window", type=float, default=0.15,
                    help="ระยะค้นหาขอบเสียงรอบเวลาที่ whisper เดา (วินาที)")
    ap.add_argument("--start-lead", type=float, default=0.12,
                    help="ชดเชย early-bias ของ whisper: เลื่อน start ของคำ/วลี ที่หา onset เสียงจริงไม่เจอ "
                         "ไปข้างหน้าเท่านี้ (วินาที) แก้อาการ 'ซับขึ้นก่อนเสียง' — 0 = ปิด (calibrate จากคลิปจริง)")
    ap.add_argument("--align", choices=["off", "wav2vec2"], default="off",
                    help="forced alignment ระดับตัวอักษรด้วย Thai wav2vec2 (high-tier) — แม่นสุดสำหรับพูดเร็ว/ต่อเนื่อง "
                         "ที่ energy-refine ทำไม่ได้ ต้องมี transformers + โมเดล ~1.2GB (ไม่พร้อม=fallback เวลาเดิม)")
    args = ap.parse_args()

    load_env()
    engine = args.engine
    if engine == "auto":
        # มาตรฐานของ Dev-Cut: Thonburian Whisper ในเครื่อง ฟรีตลอดชีพ
        # (elevenlabs ยังเรียกได้ด้วย --engine elevenlabs สำหรับผู้ใช้ขั้นสูงที่มี key)
        engine = "whisper"
    model = args.model
    if model is None:
        if args.lang == "th":
            # high = โมเดลไทยตัวใหญ่ (แม่นสุด แต่ต้องโหลด ~1.5GB ครั้งแรก) / fast = ตัวกลางที่โหลดไว้แล้ว
            if args.accuracy == "high":
                model = "Vinxscribe/biodatlab-whisper-th-large-v3-faster"
                print("โหมดแม่นสูง: ใช้โมเดลไทยตัวใหญ่ (ครั้งแรกจะโหลด ~1.5GB / ถอดช้าลง ~4-8x)")
            else:
                model = "Thaweewat/whisper-th-medium-ct2"
        else:
            model = "large-v3"
    out_dir = Path(args.out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    audio = extract_audio(args.input)

    # แยกเสียงพูดออกจากเพลงก่อนถอด (ถ้าสั่ง on หรือ auto แล้วตรวจเจอเพลง)
    sep_tmp = None
    do_sep = (args.separate_vocals == "on")
    if args.separate_vocals == "auto" and detect_music(audio):
        if demucs_available():
            print("ตรวจพบเพลง/เสียงต่อเนื่องดัง — แยกเสียงพูดก่อนถอดอัตโนมัติ (เพิ่มเวลา ~1-2x)")
            do_sep = True
        else:
            print("หมายเหตุ: คลิปนี้น่าจะมีเพลงดัง ซับอาจเพี้ยน — "
                  "ติดตั้ง 'ตัวแยกเสียงพูด' ในโปรแกรมแล้วลองใหม่เพื่อผลดีขึ้น")
    if do_sep:
        if not demucs_available():
            sys.exit("ยังไม่ได้ติดตั้งตัวแยกเสียง — กดปุ่ม 'ติดตั้งครั้งแรก' ในโปรแกรม "
                     "หรือรัน: pip install demucs soundfile")
        os.unlink(audio)
        sep_tmp = Path(tempfile.mkdtemp(prefix="devcut_tx_"))
        print("กำลังแยกเสียงพูดออกจากเพลง (ครั้งแรกจะโหลดโมเดล ~300MB)...")
        audio = extract_audio(run_separation(args.input, sep_tmp))

    refined = False
    result_aligned = False
    try:
        result = run_elevenlabs(audio, args.lang) if engine == "elevenlabs" \
            else run_whisper(audio, args.lang, model, args.hint,
                             accuracy=args.accuracy, compute_type=args.compute_type)
        # ปรับขอบเวลาให้ตรงเสียงพูดจริง — บนไฟล์ 'audio' ที่ป้อน whisper (= vocal ที่แยกแล้วถ้ามี)
        # ต้องทำก่อน finally ลบไฟล์เสียงทิ้ง
        if engine != "elevenlabs" and args.refine_words == "on" and result.get("words"):
            gate = _speech_gate(audio)
            if gate:
                snap_boundaries(result["words"], gate,
                                window=args.refine_window, lead=args.start_lead)
                snap_boundaries(result.get("raw_segments") or [], gate,
                                window=args.refine_window, lead=args.start_lead)
                refined = True
        # forced alignment (high-tier) — เขียนทับ words/raw_segments ด้วยเวลาจากอะคูสติกจริง
        if args.align == "wav2vec2" and engine != "elevenlabs" and result.get("text") and result.get("words"):
            achars = None
            try:
                sys.path.insert(0, str(Path(__file__).resolve().parent))
                import align_words
                print("กำลัง forced-align ด้วย Thai wav2vec2 (ครั้งแรกโหลดโมเดล ~1.2GB)...")
                achars = align_words.align(audio, result["text"])
            except Exception as e:
                print(f"forced alignment ข้าม ({e}) — ใช้เวลาเดิม")
            if achars:
                astarts = [c["start"] for c in achars]
                aends = [c["end"] for c in achars]
                tw = _thai_word_times(result["text"], astarts, aends)
                result["words"] = [{"w": w["text"], "start": w["start"], "end": w["end"]} for w in tw]
                _retime_by_chars(result.get("raw_segments") or [], astarts, aends)
                result_aligned = True
    finally:
        os.unlink(audio)
        if sep_tmp:
            shutil.rmtree(sep_tmp, ignore_errors=True)
    result["word_times_refined"] = refined
    result["aligned"] = result_aligned

    result["source"] = str(Path(args.input).resolve())
    raw = result.get("raw_segments") or reconstruct_raw_segments(result["text"], result["words"])
    # สร้างบรรทัดซับจากคำที่มีเวลาจริง (ขึ้นบรรทัดตามจังหวะหยุดพูด + เวลาบรรทัด=เวลาคำจริง)
    tw = word_timings(result["text"], result["words"]) if result.get("words") else []
    if tw:
        result["segments"] = build_captions_from_words(tw)
    else:                                            # ไม่มี word times (เช่น elevenlabs ล้วน) → วิธีเดิม
        result["segments"] = build_captions(raw)
        attach_words(result["segments"], tw)

    tj = out_dir / "transcript.json"
    tj.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    srt = out_dir / "captions.srt"
    srt.write_text(to_srt(result["segments"]), encoding="utf-8")
    tags = ("aligned(wav2vec2)" if result_aligned else ("refined" if refined else ""))
    print(f"OK: {tj}  ({len(result['words'])} words, engine={result['engine']}"
          f"{', ' + tags if tags else ''})")
    print(f"OK: {srt}  ({len(result['segments'])} caption segments)")


if __name__ == "__main__":
    main()
