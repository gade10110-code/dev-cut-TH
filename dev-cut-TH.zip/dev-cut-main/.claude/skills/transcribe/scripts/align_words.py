#!/usr/bin/env python3
"""Dev-Cut Kit - align_words: forced alignment ระดับตัวอักษรด้วย Thai wav2vec2 CTC (high-tier)
ปิด gap ที่ energy-refine ทำไม่ได้ — เสียงพูดเร็ว/ต่อเนื่องไม่มีช่องเงียบให้ยึด
เอา 'ข้อความ' จาก whisper มา align กับ 'อะคูสติกจริง' → ได้ขอบคำ frame-tight (~20ms) โดยไม่ต้องมีช่องเงียบ

โมดูลนี้ opt-in: ถ้า transformers/โมเดลไม่พร้อม จะคืน None ให้ผู้เรียก fallback ไปใช้เวลาเดิม (ไม่พัง pipeline)

ต้องมี: transformers, torch (มากับ demucs แล้ว), soundfile + โมเดล Thai wav2vec2 (~1.2GB, โหลดครั้งเดียว)
"""
import os
from pathlib import Path

# เก็บโมเดลในโฟลเดอร์ kit (กัน C: เต็ม) — เหมือน whisper/demucs
_KIT_ROOT = Path(__file__).resolve().parents[4]
os.environ.setdefault("HF_HOME", str(_KIT_ROOT / "models"))

DEFAULT_MODEL = "airesearch/wav2vec2-large-xlsr-53-th"


def ctc_forced_align(emission, tokens, blank=0):
    """CTC forced alignment (Viterbi) — คืน span (frame_start, frame_end) ของแต่ละ token
    emission: log-prob array [T, V] (numpy) · tokens: list ของ vocab id ที่จะ align (ไม่มี blank)
    เป็นแกนหลักที่ unit-test ได้โดยไม่ต้องมีโมเดล"""
    import numpy as np
    T = emission.shape[0]
    N = len(tokens)
    if N == 0 or T == 0:
        return []
    S = 2 * N + 1
    ext = np.full(S, blank, dtype=np.int64)
    ext[1::2] = tokens
    NEG = -1e30
    score = np.full(S, NEG, dtype=np.float64)
    back = np.zeros((T, S), dtype=np.int32)

    score[0] = emission[0, ext[0]]
    if S > 1:
        score[1] = emission[0, ext[1]]

    for t in range(1, T):
        new = np.full(S, NEG, dtype=np.float64)
        for s in range(S):
            best, bp = score[s], s                       # stay
            if s - 1 >= 0 and score[s - 1] > best:
                best, bp = score[s - 1], s - 1
            # ข้าม blank ระหว่าง 2 token ที่ต่างกันได้
            if s - 2 >= 0 and ext[s] != blank and ext[s] != ext[s - 2] and score[s - 2] > best:
                best, bp = score[s - 2], s - 2
            if best <= NEG:
                continue
            new[s] = best + emission[t, ext[s]]
            back[t, s] = bp
        score = new

    s_end = S - 1 if (S == 1 or score[S - 1] >= score[S - 2]) else S - 2
    path = np.zeros(T, dtype=np.int32)
    s = s_end
    for t in range(T - 1, -1, -1):
        path[t] = s
        s = back[t, s]

    spans = []
    for i in range(N):
        si = 2 * i + 1
        frames = np.where(path == si)[0]
        spans.append((int(frames[0]), int(frames[-1]) + 1) if len(frames) else None)
    return spans


def load_model(model_id=DEFAULT_MODEL):
    """โหลด wav2vec2 CTC + vocab — คืน (model, processor, vocab, blank_id) หรือ None ถ้าไม่พร้อม"""
    try:
        import torch  # noqa: F401
        from transformers import Wav2Vec2ForCTC, Wav2Vec2Processor
    except ImportError:
        return None
    try:
        processor = Wav2Vec2Processor.from_pretrained(model_id)
        model = Wav2Vec2ForCTC.from_pretrained(model_id)
        model.eval()
    except Exception as e:
        print(f"โหลดโมเดล align ไม่สำเร็จ ({e}) — ข้าม forced alignment")
        return None
    vocab = processor.tokenizer.get_vocab()
    blank_id = model.config.pad_token_id or 0
    return model, processor, vocab, blank_id


def _emission_chunked(model, processor, audio, sr, chunk_sec=25.0):
    """รัน wav2vec2 เป็นท่อน (กัน OOM บน CPU) → log-prob [T,V] ต่อกัน + frame_rate (เฟรม/วินาที)"""
    import numpy as np
    import torch
    step = int(chunk_sec * sr)
    outs, total_frames = [], 0
    with torch.no_grad():
        for i in range(0, len(audio), step):
            chunk = audio[i:i + step]
            if len(chunk) < int(0.05 * sr):
                continue
            iv = processor(chunk, sampling_rate=sr, return_tensors="pt").input_values
            logits = model(iv).logits[0]                 # [t, V]
            outs.append(torch.log_softmax(logits, dim=-1).cpu().numpy())
            total_frames += outs[-1].shape[0]
    if not outs:
        return None, 0.0
    emission = np.concatenate(outs, axis=0)
    frame_rate = total_frames / (len(audio) / sr)        # เฟรม/วินาที (≈50)
    return emission, frame_rate


def align(audio_path, text, model_id=DEFAULT_MODEL):
    """คืนเวลาระดับตัวอักษร [{ 'ch','start','end' }] ของ text ที่ align กับเสียงจริง — None ถ้าทำไม่ได้
    OOV char (อังกฤษ/ตัวเลข/สัญลักษณ์ที่ไม่มีใน vocab ไทย) จะถูกข้ามในการ align แล้วเกลี่ยเวลาจากเพื่อนบ้าน"""
    try:
        import numpy as np
        import soundfile as sf
    except ImportError:
        return None
    loaded = load_model(model_id)
    if not loaded:
        return None
    model, processor, vocab, blank_id = loaded
    try:
        audio, sr = sf.read(audio_path, dtype="float32")
    except Exception:
        return None
    if getattr(audio, "ndim", 1) > 1:
        audio = audio.mean(axis=1)
    if sr != 16000:
        return None                                      # wav2vec2 ต้อง 16k (extract_audio ให้ 16k อยู่แล้ว)

    emission, frame_rate = _emission_chunked(model, processor, audio, sr)
    if emission is None or frame_rate <= 0:
        return None

    chars = [c for c in text if not c.isspace()]         # ไทยไม่มีเว้นวรรคในคำ — ตัดช่องว่างออก
    in_vocab, ids = [], []
    for c in chars:
        cid = vocab.get(c)
        in_vocab.append(cid is not None)
        if cid is not None:
            ids.append(cid)
    if not ids:
        return None

    spans = ctc_forced_align(emission, ids, blank=blank_id)
    # แมป span (frame) กลับเป็นเวลา + เติม OOV char ด้วยการเกลี่ยเวลาเชิงเส้นจากเพื่อนบ้าน
    out, si = [], 0
    for c, ok in zip(chars, in_vocab):
        if ok and si < len(spans) and spans[si] is not None:
            fs, fe = spans[si]
            out.append({"ch": c, "start": round(fs / frame_rate, 3),
                        "end": round(fe / frame_rate, 3)})
        else:
            out.append({"ch": c, "start": None, "end": None})   # เติมทีหลัง
        if ok:
            si += 1
    # เติมช่องที่ None (OOV/align ไม่ติด) โดย interpolate จากเวลารอบข้าง
    _fill_gaps(out)
    return out


def _fill_gaps(chars):
    """เติมเวลา char ที่ None ด้วยการเกลี่ยเชิงเส้นระหว่าง anchor ที่มีเวลา"""
    n = len(chars)
    i = 0
    last = 0.0
    while i < n:
        if chars[i]["start"] is not None:
            last = chars[i]["end"]
            i += 1
            continue
        j = i
        while j < n and chars[j]["start"] is None:
            j += 1
        left = last
        right = chars[j]["start"] if j < n else left + 0.04 * (j - i)
        span = max(right - left, 0.001)
        for k in range(i, j):
            a = left + span * (k - i) / (j - i)
            b = left + span * (k - i + 1) / (j - i)
            chars[k]["start"], chars[k]["end"] = round(a, 3), round(b, 3)
        i = j


if __name__ == "__main__":
    import argparse, json
    ap = argparse.ArgumentParser(description="Thai wav2vec2 forced alignment (ทดสอบเดี่ยว)")
    ap.add_argument("audio")
    ap.add_argument("--text", required=True)
    ap.add_argument("--model", default=DEFAULT_MODEL)
    a = ap.parse_args()
    r = align(a.audio, a.text, a.model)
    print(json.dumps(r, ensure_ascii=False, indent=2) if r else "align ไม่สำเร็จ (ดู deps/โมเดล)")
