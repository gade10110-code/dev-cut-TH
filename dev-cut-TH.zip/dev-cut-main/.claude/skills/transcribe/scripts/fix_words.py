#!/usr/bin/env python3
"""Dev-Cut - fix_words: แก้คำที่ ASR ถอดผิด 'ทั้งไฟล์' ในทีเดียว (เร็ว ช่วยได้ทุกเครื่อง)
เหมาะกับชื่อเฉพาะ/คำทับศัพท์ที่ถอดผิดซ้ำ ๆ — แก้ที่เดียว ทั้งซับ + transcript อัปเดตให้ครบ
(เวลาคำ karaoke ของบรรทัดที่แก้จะเกลี่ยใหม่ตามความยาว บรรทัดที่ไม่แตะยังใช้เวลาจริงเดิม)

Usage:
  python fix_words.py --work work/proj --set "จิ๋นศรี=จิ๋นซี" --set "โพไซดอล=โพไซดอน"
  python fix_words.py --transcript work/transcript.json --srt work/captions.srt --set "ผิด=ถูก"
"""
import argparse, json, sys
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):  # กัน error ภาษาไทยบน Windows codepage
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

sys.path.insert(0, str(Path(__file__).resolve().parent))
from transcribe import to_srt, _thai_tokens   # ใช้ตัวเดียวกับตอนถอด (ตัดคำ/ทำ srt)


def parse_pairs(items):
    pairs = []
    for it in items or []:
        if "=" not in it:
            sys.exit(f"รูปแบบผิด: '{it}' — ต้องเป็น \"คำผิด=คำถูก\"")
        wrong, right = it.split("=", 1)
        wrong = wrong.strip()
        if not wrong:
            sys.exit(f"คำผิดว่างเปล่าใน '{it}'")
        pairs.append((wrong, right.strip()))
    return pairs


def apply_all(text, pairs):
    for wrong, right in pairs:
        text = text.replace(wrong, right)
    return text


def rebuild_words(seg):
    """สร้าง words ใหม่ของบรรทัดที่ข้อความเปลี่ยน — เกลี่ยเวลาในช่วง [start,end] ตามความยาวคำ
    (บรรทัดที่ไม่ถูกแก้จะไม่เรียกฟังก์ชันนี้ = คงเวลาคำจริงไว้)"""
    toks = _thai_tokens(seg["text"])
    words = [t for t in (toks or seg["text"].split()) if t.strip()]
    if not words:
        seg["words"] = []
        return
    total = sum(len(w) for w in words) or 1
    dur = max(seg["end"] - seg["start"], 0.0)
    acc, out = seg["start"], []
    for w in words:
        d = dur * len(w) / total
        out.append({"text": w, "start": round(acc, 3), "end": round(acc + d, 3)})
        acc += d
    seg["words"] = out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--work", help="โฟลเดอร์งาน (จะใช้ transcript.json + captions.srt ในนี้)")
    ap.add_argument("--transcript", help="ระบุ transcript.json เอง (แทน --work)")
    ap.add_argument("--srt", help="ระบุ captions.srt เอง (แทน --work)")
    ap.add_argument("--set", action="append", metavar='"ผิด=ถูก"',
                    help="คู่คำที่จะแก้ ใส่ได้หลายครั้ง")
    args = ap.parse_args()

    pairs = parse_pairs(args.set)
    if not pairs:
        sys.exit("ต้องใส่ --set \"คำผิด=คำถูก\" อย่างน้อยหนึ่งคู่")

    tj_path = Path(args.transcript) if args.transcript else \
        (Path(args.work) / "transcript.json" if args.work else None)
    srt_path = Path(args.srt) if args.srt else \
        (Path(args.work) / "captions.srt" if args.work else None)
    if not tj_path or not tj_path.exists():
        sys.exit(f"ไม่พบ transcript.json ({tj_path}) — ระบุ --work หรือ --transcript")

    tj = json.loads(tj_path.read_text(encoding="utf-8"))
    tj["text"] = apply_all(tj.get("text", ""), pairs)

    n_hits, n_lines = 0, 0
    for seg in tj.get("segments", []):
        new = apply_all(seg["text"], pairs)
        if new != seg["text"]:
            n_hits += sum(seg["text"].count(w) for w, _ in pairs)
            seg["text"] = new
            if "words" in seg:            # มีเวลาคำ → สร้างใหม่ให้ตรงข้อความที่แก้
                rebuild_words(seg)
            n_lines += 1

    tj_path.write_text(json.dumps(tj, ensure_ascii=False, indent=2), encoding="utf-8")
    if srt_path:                          # เขียน srt ใหม่จาก segments ที่แก้แล้ว
        srt_path.write_text(to_srt(tj["segments"]), encoding="utf-8")

    print("== Dev-Cut fix_words ==")
    print(f"แก้คำ {n_hits} จุด ใน {n_lines} บรรทัด")
    for w, r in pairs:
        print(f"  '{w}' → '{r}'")
    print(f"อัปเดต: {tj_path.name}" + (f" + {srt_path.name}" if srt_path else ""))
    print("รันสร้างโปรเจกต์ CapCut ใหม่ได้เลย (ซับ + karaoke จะใช้คำที่แก้แล้ว)")


if __name__ == "__main__":
    main()
