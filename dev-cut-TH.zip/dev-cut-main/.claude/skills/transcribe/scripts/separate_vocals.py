#!/usr/bin/env python3
"""Dev-Cut - separate_vocals: แยกเสียงพูดออกจากเพลง/เอฟเฟกต์ด้วย Demucs (ฟรี รันในเครื่อง)
ใช้ก่อนถอดเสียงเมื่อคลิปมี BGM ดัง — ความแม่นการถอดจะดีขึ้นมาก
Usage:
  python separate_vocals.py input.mp4 --out-dir work/
Output: work/vocals.wav  (เอาไฟล์นี้ไปเข้า transcribe.py ต่อ)
"""
import argparse, os, re, shutil, subprocess, sys, tempfile
from pathlib import Path

import sys as _sys
if hasattr(_sys.stdout, "reconfigure"):
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace")

# เก็บโมเดลไว้ในโฟลเดอร์ kit (กัน C: เต็ม)
_KIT_ROOT = Path(__file__).resolve().parents[4]
os.environ.setdefault("TORCH_HOME", str(_KIT_ROOT / "models" / "torch"))

PROGRESS_FILE = Path(tempfile.gettempdir()) / "devcut_progress.txt"


def write_progress(pct, label):
    try:
        PROGRESS_FILE.write_text(f"{min(99, max(0, int(pct)))}|{label}", encoding="utf-8")
    except OSError:
        pass


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("--out-dir", default=".")
    args = ap.parse_args()

    try:
        import demucs  # noqa: F401
    except ImportError:
        sys.exit("ยังไม่ได้ติดตั้งตัวแยกเสียง — กดปุ่ม 'ติดตั้งครั้งแรก' ในโปรแกรม Dev-Cut "
                 "หรือรัน: pip install demucs")

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    tmp = Path(tempfile.mkdtemp(prefix="devcut_sep_"))

    wav = tmp / "audio.wav"
    write_progress(2, "เตรียมไฟล์เสียง...")
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", args.input, "-vn",
                    "-ac", "2", "-ar", "44100", str(wav)], check=True)

    write_progress(5, "แยกเสียงพูดออกจากเพลง (ครั้งแรกจะโหลดโมเดล ~300MB)...")
    p = subprocess.Popen(
        [sys.executable, "-m", "demucs", "--two-stems", "vocals",
         "-n", "htdemucs", "-o", str(tmp), str(wav)],
        stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="replace")
    for line in p.stderr:
        m = re.search(r"(\d+)%", line)
        if m:
            write_progress(5 + int(m.group(1)) * 0.9, "แยกเสียงพูดออกจากเพลง")
    p.wait()
    if p.returncode != 0:
        sys.exit("แยกเสียงไม่สำเร็จ — ดูรายละเอียดด้านบน")

    src = tmp / "htdemucs" / wav.stem / "vocals.wav"
    if not src.exists():
        hits = list(tmp.rglob("vocals.wav"))
        if not hits:
            sys.exit("ไม่พบไฟล์ vocals.wav ที่แยกได้")
        src = hits[0]
    dest = out_dir / "vocals.wav"
    shutil.copy2(src, dest)
    shutil.rmtree(tmp, ignore_errors=True)
    try:
        PROGRESS_FILE.unlink()
    except OSError:
        pass
    print(f"OK: {dest}  (เอาไฟล์นี้เข้า transcribe.py ต่อ — เสียงพูดล้วน ไม่มีเพลงกวน)")


if __name__ == "__main__":
    main()
