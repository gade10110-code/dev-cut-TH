#!/usr/bin/env python3
"""Dev-Cut Kit - clean-cut: สร้างแผนการตัด (cutplan.json) โดยตัดช่วงเงียบ/ช่วงตายออกอัตโนมัติ
ค่าเริ่มต้นจะ "วางแผน" อย่างเดียว — ไฟล์ต้นฉบับไม่ถูกแก้ ใช้ --render ถ้าอยากได้ mp4 ที่ตัดแล้วจริง ๆ

สองโหมดหาช่วง keep:
  words   — ใช้ timestamp รายคำจาก transcript.json เป็น "ความจริง" ของช่วงพูด (แม่นสุด ไม่กินหัว-ท้ายคำ)
  silence — ตรวจช่วงเงียบด้วย ffmpeg silencedetect (ใช้เมื่อยังไม่มี transcript)
ค่าเริ่มต้น auto: มี transcript.json ในโฟลเดอร์งาน → ใช้ words, ไม่มี → ถอยไป silence

Usage:
  python clean_cut.py input.mp4 --out-dir work/                 # แผนอย่างเดียว (auto)
  python clean_cut.py input.mp4 --out-dir work/ --source words  # บังคับใช้ word timestamps
  python clean_cut.py input.mp4 --out-dir work/ --render        # + เรนเดอร์ mp4 ที่ตัดแล้ว
"""
import argparse, json, re, subprocess, sys
from pathlib import Path

import sys as _sys
if hasattr(_sys.stdout, "reconfigure"):  # กัน error ภาษาไทยบน Windows codepage
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace")


def detect_silences(src, noise_db, min_dur):
    r = subprocess.run(["ffmpeg", "-hide_banner", "-i", src, "-af",
                        f"silencedetect=noise={noise_db}dB:d={min_dur}", "-f", "null", "-"],
                       capture_output=True, text=True)
    starts = [float(x) for x in re.findall(r"silence_start: ([\d.]+)", r.stderr)]
    ends = [float(x) for x in re.findall(r"silence_end: ([\d.]+)", r.stderr)]
    return list(zip(starts, ends))


def duration_of(src):
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                        "-of", "csv=p=0", src], capture_output=True, text=True, check=True)
    return float(r.stdout.strip())


def merge_keeps(keeps, min_keep):
    """เรียง + รวมช่วงที่ทับ/ชนกัน + ทิ้งช่วงที่สั้นกว่า min_keep"""
    keeps = sorted((round(a, 3), round(b, 3)) for a, b in keeps if b - a >= min_keep)
    merged = []
    for a, b in keeps:
        if merged and a <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], b)
        else:
            merged.append([a, b])
    # cast เป็น float ธรรมดา — snap_zero_crossing อาจคืน np.float64 ซึ่ง json.dumps เขียนไม่ได้
    return [(round(float(a), 3), round(float(b), 3)) for a, b in merged]


def build_keeps_from_silence(silence_ranges, total, pad, min_keep):
    """invert silences -> keep ranges, padded so cuts don't clip words."""
    keeps, cursor = [], 0.0
    for s, e in silence_ranges:
        a, b = cursor, s + pad          # keep a little into the silence
        if b - a >= min_keep:
            keeps.append((max(0.0, a), min(b, total)))
        cursor = e - pad                # resume a little before speech starts
    if total - cursor >= min_keep:
        keeps.append((max(0.0, cursor), total))
    return merge_keeps(keeps, min_keep)


def load_words(transcript_path):
    """อ่าน words[] จาก transcript.json — คืน [{'start','end'}, ...] เรียงเวลา หรือ None ถ้าไม่มี/ว่าง"""
    p = Path(transcript_path)
    if not p.exists():
        return None
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    words = data.get("words") or []
    out = []
    for w in words:
        try:
            s, e = float(w["start"]), float(w["end"])
        except (KeyError, TypeError, ValueError):
            continue
        if e > s:
            out.append((s, e))
    out.sort()
    return out or None


def build_keeps_from_words(words, total, word_gap, pre_roll, tail, min_keep, gate=None):
    """สร้าง keeps จากช่วงพูดจริง (word timestamps) — 'ความจริง' คือคำ ไม่ใช่ระดับเสียง
    - รวมคำที่ติดกัน (ช่องว่างระหว่างคำ <= word_gap) เป็นก้อนพูดเดียว
    - ช่องว่างที่ยาวกว่า word_gap **และเงียบจริง** (gate ยืนยัน) = ช่วงตาย → ตัดออก
      ถ้าช่องนั้นยังมีเสียงพูด (whisper ให้เวลาเพี้ยน/คำหลุด) → 'ห้ามตัด' รวมเป็นก้อนเดียว กันคอนเทนต์หาย
    - เติม pre-roll หน้าคำแรก / tail ท้ายคำสุดท้ายของก้อน กันตัดโดนลมหายใจ/พยัญชนะระเบิด (plosive)
    คืน (keeps, n_guarded) — n_guarded = จำนวนช่องที่ 'จะตัดแต่มีเสียง เลยไม่ตัด'"""
    spans, guarded = [], 0
    cur_s, cur_e = words[0]
    for s, e in words[1:]:
        if s - cur_e <= word_gap:
            cur_e = max(cur_e, e)               # ยังเป็นก้อนพูดเดียวกัน
        elif gate is not None and gap_is_speechy(gate, cur_e, s):
            cur_e = max(cur_e, e)               # ช่องว่างยาวแต่ 'มีเสียงจริง' → ไม่ตัด (กันหลุด)
            guarded += 1
        else:
            spans.append((cur_s, cur_e))        # ช่วงตายเงียบจริง → ปิดก้อน (ตัดช่องนี้)
            cur_s, cur_e = s, e
    spans.append((cur_s, cur_e))

    keeps = [(max(0.0, s - pre_roll), min(total, e + tail)) for s, e in spans]
    return merge_keeps(keeps, min_keep), guarded


def decode_audio_mono(src, sr=16000):
    """ถอดเสียงทั้งไฟล์เป็น mono float32 ลง numpy (ไว้หา zero-crossing) — ไม่มี numpy คืน None"""
    try:
        import numpy as np
    except ImportError:
        return None
    try:
        r = subprocess.run(["ffmpeg", "-v", "error", "-i", src, "-vn", "-ac", "1",
                            "-ar", str(sr), "-f", "f32le", "-"],
                           capture_output=True, check=True)
    except (OSError, subprocess.CalledProcessError):
        return None
    return np.frombuffer(r.stdout, dtype=np.float32)


def speech_gate(audio, sr, frame=0.025, hop=0.010, gate_frac=0.15, floor_pct=10):
    """คืน (speech: bool ต่อเฟรม, hop วินาที) จาก energy envelope — ไว้ยืนยันว่าช่องว่าง 'เงียบจริง' ก่อนตัด"""
    import numpy as np
    n = len(audio)
    fl, hp = max(1, int(frame * sr)), max(1, int(hop * sr))
    if n < fl * 2:
        return None
    csum = np.concatenate(([0.0], np.cumsum(audio.astype(np.float64) ** 2)))
    nf = 1 + (n - fl) // hp
    starts = np.arange(nf) * hp
    env = np.sqrt((csum[starts + fl] - csum[starts]) / fl)
    mx = float(env.max())
    if mx <= 0:
        return None
    envn = env / mx
    floor = float(np.percentile(envn, floor_pct))
    thr = floor + gate_frac * (1.0 - floor)
    return (envn >= thr), hp / sr


def gap_is_speechy(gate, t0, t1, min_frac=0.35):
    """ช่องว่าง (t0,t1) มีเสียงพูดจริงไหม — ถ้าจริง 'ห้ามตัด' (whisper ให้เวลาเพี้ยน คำหลุดกลางประโยค)"""
    if not gate or t1 <= t0:
        return False
    import numpy as np
    speech, hop = gate
    a, b = max(0, int(round(t0 / hop))), min(len(speech), int(round(t1 / hop)))
    if b <= a:
        return False
    return float(np.mean(speech[a:b])) >= min_frac


def snap_zero_crossing(keeps, audio, sr, window_sec, total):
    """เลื่อนจุดตัดแต่ละอันไปยัง zero-crossing ที่ใกล้ที่สุดภายใน ±window — กันเสียง click/pop ตอนต่อคลิป
    หน้าต่างเล็กมาก (~15ms < ครึ่งเฟรม) จึงไม่ทำให้ตัดโดนคำ"""
    import numpy as np
    n = len(audio)
    w = max(1, int(window_sec * sr))

    def snap(t):
        i = int(round(t * sr))
        if i <= 0 or i >= n - 1:
            return t
        lo, hi = max(1, i - w), min(n - 1, i + w)
        seg = audio[lo:hi + 1]
        # ดัชนีที่สัญญาณสลับเครื่องหมาย (คูณกันแล้ว <= 0) = จุดตัดผ่านศูนย์
        cross = np.where(seg[:-1] * seg[1:] <= 0)[0]
        if len(cross) == 0:
            return t
        best = cross[np.argmin(np.abs(cross + lo - i))] + lo
        return round(best / sr, 3)

    out = []
    for a, b in keeps:
        na, nb = snap(a), snap(b)
        if nb - na > 0.01:                 # กันกรณี snap แล้วช่วงหดจนเพี้ยน
            out.append((na, nb))
        else:
            out.append((a, b))
    return out


def render(src, keeps, out_path):
    """Cut + concat losslessly-ish with one re-encode pass (accurate cuts)."""
    vf = "+".join(f"between(t,{a},{b})" for a, b in keeps)
    filt = (f"[0:v]select='{vf}',setpts=N/FRAME_RATE/TB[v];"
            f"[0:a]aselect='{vf}',asetpts=N/SR/TB[a]")
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", src, "-filter_complex", filt,
                    "-map", "[v]", "-map", "[a]", "-c:v", "libx264", "-preset", "fast",
                    "-crf", "18", "-c:a", "aac", "-b:a", "192k", str(out_path)], check=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("--out-dir", default=".")
    ap.add_argument("--source", choices=["auto", "words", "silence"], default="auto",
                    help="ที่มาของช่วง keep: auto (มี transcript ใช้ words ไม่มีใช้ silence) | "
                         "words (จาก word timestamps — แม่นสุด) | silence (จากระดับเสียงล้วน)")
    ap.add_argument("--transcript", default=None,
                    help="path ของ transcript.json (ปกติมองหา <out-dir>/transcript.json เอง)")
    # --- โหมด words ---
    ap.add_argument("--word-gap", type=float, default=0.6,
                    help="[words] ช่องว่างระหว่างคำยาวกว่านี้ (วินาที) ถือเป็นช่วงตาย → ตัดออก")
    ap.add_argument("--pre-roll", type=float, default=0.10,
                    help="[words] เผื่อหน้าคำแรกของแต่ละก้อน (วินาที) กันตัดหัวคำ")
    ap.add_argument("--tail", type=float, default=0.18,
                    help="[words] เผื่อท้ายคำสุดท้ายของแต่ละก้อน (วินาที) กันตัดหางคำ/ลมหายใจ")
    ap.add_argument("--no-zero-snap", action="store_true",
                    help="[words] ปิดการ snap จุดตัดไป zero-crossing")
    ap.add_argument("--zero-window", type=float, default=0.015,
                    help="[words] ระยะค้นหา zero-crossing รอบจุดตัด (วินาที)")
    # --- โหมด silence ---
    ap.add_argument("--noise-db", type=float, default=-35,
                    help="[silence] ความดังต่ำกว่านี้ถือว่าเงียบ (dB), เสียงรบกวนเยอะให้ลองใช้ -30")
    ap.add_argument("--min-silence", type=float, default=0.6,
                    help="[silence] เงียบนานกว่ากี่วินาทีถึงตัด")
    ap.add_argument("--pad", type=float, default=0.15,
                    help="[silence] กันขอบไว้กี่วินาที ไม่ให้ตัดโดนคำพูด")
    # --- ร่วม ---
    ap.add_argument("--min-keep", type=float, default=0.3,
                    help="ช่วง keep สั้นกว่านี้ทิ้งไป")
    ap.add_argument("--render", action="store_true", help="เรนเดอร์ mp4 ที่ตัดแล้วด้วย")
    args = ap.parse_args()

    out_dir = Path(args.out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    total = duration_of(args.input)

    tx_path = args.transcript or (out_dir / "transcript.json")
    words = load_words(tx_path)

    # ตัดสินใจโหมด
    source = args.source
    if source == "auto":
        source = "words" if words else "silence"
    if source == "words" and not words:
        print("หมายเหตุ: ไม่พบ word timestamps ใน transcript.json — ถอยไปใช้โหมด silence")
        source = "silence"

    zero_snapped = False
    guarded = 0
    if source == "words":
        # decode เสียงครั้งเดียว ใช้ทั้ง 'ยืนยันความเงียบก่อนตัด' และ zero-crossing snap
        audio = decode_audio_mono(args.input)
        gate = speech_gate(audio, 16000) if (audio is not None and len(audio)) else None
        keeps, guarded = build_keeps_from_words(words, total, args.word_gap,
                                                args.pre_roll, args.tail, args.min_keep, gate=gate)
        if not args.no_zero_snap and keeps and audio is not None and len(audio):
            keeps = snap_zero_crossing(keeps, audio, 16000, args.zero_window, total)
            keeps = merge_keeps(keeps, args.min_keep)   # snap อาจทำให้ชนกัน → รวมใหม่
            zero_snapped = True
    else:
        sil = detect_silences(args.input, args.noise_db, args.min_silence)
        keeps = build_keeps_from_silence(sil, total, args.pad, args.min_keep)

    if not keeps:                                            # กันคลิปที่ตัดจนไม่เหลืออะไร
        keeps = [(0.0, round(total, 3))]
    kept = sum(b - a for a, b in keeps)

    params = {"source": source, "min_keep": args.min_keep}
    if source == "words":
        params.update(word_gap=args.word_gap, pre_roll=args.pre_roll, tail=args.tail,
                      zero_snapped=zero_snapped, silence_guarded_cuts=guarded)
    else:
        params.update(noise_db=args.noise_db, min_silence=args.min_silence, pad=args.pad)

    plan = {
        "source": str(Path(args.input).resolve()),
        "source_duration": round(total, 3),
        "keep_source": source,               # words | silence — ให้ skill/คนอ่านรู้ที่มา
        "params": params,
        "keeps": [{"start": a, "end": b} for a, b in keeps],
        "kept_duration": round(kept, 3),
        "removed_duration": round(total - kept, 3),
    }
    pj = out_dir / "cutplan.json"
    pj.write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"== Dev-Cut clean-cut ==")
    label = "จาก word timestamps" + (" + snap zero-crossing" if zero_snapped else "") \
        if source == "words" else "จากช่วงเงียบ (silence)"
    print(f"โหมด: {label}")
    print(f"ต้นฉบับ {total:.1f}s → เหลือ {kept:.1f}s "
          f"(ตัดออก {total-kept:.1f}s, {len(keeps)} ช่วง keep)")
    if guarded:
        print(f"กันคอนเทนต์หาย: ไม่ตัด {guarded} ช่องที่ 'ยาวแต่มีเสียงพูด' (whisper ให้เวลาเพี้ยน)")
    print(f"OK: {pj}")

    if args.render:
        out_mp4 = out_dir / (Path(args.input).stem + "_cleancut.mp4")
        render(args.input, keeps, out_mp4)
        print(f"OK: {out_mp4}")


if __name__ == "__main__":
    main()
