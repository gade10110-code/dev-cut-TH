---
name: gen-assets
description: สร้างกราฟิกประกอบคลิปเองในเครื่อง ฟรี ไม่ใช้ API — title card, แถบชื่อ (lower third), end card, พื้นหลัง gradient, ไอคอน/สติกเกอร์ Lucide ~2,000 แบบ (แถมใน kit) รองรับภาษาไทย ใช้เมื่อผู้ใช้ขอ "ทำ title", "แถบชื่อ", "การ์ดปิดท้าย", "พื้นหลัง", "intro card", "ไอคอน", "สติกเกอร์" หรือเมื่อไม่มี key หา b-roll แล้วต้องการภาพประกอบ
---

# gen-assets — สร้างกราฟิกเอง

## วิธีใช้

```bash
python scripts/gen_assets.py title-card  --text "รีวิว 5 แอปฟรี" --sub "EP.12" --out <work>/assets/title.png
python scripts/gen_assets.py lower-third --text "สมชาย ใจดี" --sub "ช่างภาพ" --out <work>/assets/name.png
python scripts/gen_assets.py end-card    --text "ขอบคุณที่รับชม" --sub "กดติดตามด้วยนะ" --out <work>/assets/end.png
python scripts/gen_assets.py bg-gradient --color1 "#0f172a" --color2 "#3b0764" --out <work>/assets/bg.png
```

- แนวตั้ง TikTok: เพิ่ม `--width 1080 --height 1920`
- ปรับสี: `--color1/--color2` (พื้น gradient), `--accent` (แถบสี) — ถามธีมสี/แบรนด์ผู้ใช้ก่อนถ้ายังไม่รู้
- `lower-third` ได้ PNG โปร่งใสทั้งเฟรม → ลากวางบน track บนสุดใน CapCut ตรงตำแหน่งพอดีเลย
- ฟอนต์: หา **LINE Seed Sans TH** ในเครื่องก่อนอัตโนมัติ (ไม่มีก็ใช้ฟอนต์ไทยระบบ) — โหลดฟรีที่ seed.line.me

## ไอคอน / สติกเกอร์ (Lucide — แถมใน kit ~2,000 ไอคอน ออฟไลน์)

```bash
python scripts/gen_icon.py --list camera                    # ค้นชื่อไอคอน
python scripts/gen_icon.py camera --size 512 --color "#f59e0b" --out <work>/assets/camera.png
```

- ได้ PNG โปร่งใส ลากเข้า CapCut วางซ้อนได้เลย — ISC license ใช้เชิงพาณิชย์ได้ ไม่ต้องเครดิต
- ชื่อไอคอนเป็นอังกฤษ kebab-case เช่น `arrow-right`, `thumbs-up`, `shopping-cart` — ไม่แน่ใจให้ `--list` ก่อน
- ผู้ใช้ขอสไตล์อื่น (เช่นแบบ flaticon สีทึบการ์ตูน): อธิบายว่า kit ใช้ Lucide (เส้น minimal) เพราะฟรีขายได้ไม่ติดเงื่อนไข — flaticon ต้องสมัคร/ให้เครดิต/มีข้อจำกัด แนะนำให้โหลดเองถ้าจำเป็น

## เกินกว่า template — ออกแบบเองได้เลย

ถ้าผู้ใช้อยากได้ดีไซน์ที่ template ไม่มี (โลโก้ประกอบ, layout พิเศษ, infographic):
**เขียนสคริปต์ Pillow ใหม่เฉพาะงานนั้นได้เลย** — ใช้ `find_font()` จาก gen_assets.py เพื่อรองรับภาษาไทย
อย่าพยายามยัดทุกอย่างใส่ template เดิม

## เสียงประกอบ — ใช้ sfx-pack ที่แถมมา

โฟลเดอร์ `sfx-pack/` ที่ root ของ kit มีเสียง 18 ไฟล์พร้อมใช้ (whoosh, pop, ding, riser, impact ฯลฯ)
ลิขสิทธิ์เป็นของเจ้าของ kit — ใช้ได้อิสระ ไม่ต้องให้เครดิตใคร แนะนำผู้ใช้ก่อนไปหาจาก Freesound
อยากได้โทนต่างจากเดิม: แก้พารามิเตอร์ใน `sfx-pack/make_sfx.py` แล้วรันใหม่
