#!/usr/bin/env python3
"""Dev-Cut Kit - gen-assets: สร้างกราฟิกเองในเครื่อง (ไม่ต้องใช้ API ใด ๆ)
Templates: title-card | lower-third | end-card | bg-gradient
Usage:
  python gen_assets.py title-card --text "รีวิว 5 แอปฟรี" --sub "EP.12" --out work/assets/title.png
  python gen_assets.py lower-third --text "สมชาย ใจดี" --sub "ช่างภาพ" --out work/assets/name.png
  python gen_assets.py bg-gradient --color1 "#0f172a" --color2 "#3b0764" --out work/assets/bg.png
รองรับภาษาไทยอัตโนมัติ (หา font ไทยในเครื่องเอง) | แนวตั้ง: --width 1080 --height 1920
"""
import argparse, platform, sys
from pathlib import Path

import sys as _sys
if hasattr(_sys.stdout, "reconfigure"):  # กัน error ภาษาไทยบน Windows codepage
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace")


try:
    from PIL import Image, ImageDraw, ImageFilter, ImageFont
except ImportError:
    sys.exit("ยังไม่ได้ติดตั้ง Pillow — รัน: pip install pillow")

THAI_FONTS = {
    "Windows": ["C:/Windows/Fonts/leelawuib.ttf", "C:/Windows/Fonts/leelawui.ttf",
                "C:/Windows/Fonts/tahomabd.ttf", "C:/Windows/Fonts/tahoma.ttf"],
    "Darwin": ["/System/Library/Fonts/Supplemental/Thonburi.ttc",
               "/System/Library/Fonts/Supplemental/Sukhumvit Set.ttc",
               "/Library/Fonts/Arial Unicode.ttf"],
    "Linux": ["/usr/share/fonts/truetype/tlwg/Loma-Bold.ttf",
              "/usr/share/fonts/opentype/tlwg/Loma-Bold.otf",
              "/usr/share/fonts/truetype/tlwg/Garuda-Bold.ttf",
              "/usr/share/fonts/opentype/tlwg/Garuda-Bold.otf",
              "/usr/share/fonts/truetype/noto/NotoSansThai-Bold.ttf",
              "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"],
}


def _brand_font_files():
    """หา LINE Seed Sans TH (หรือฟอนต์แบรนด์) ที่ติดตั้งในเครื่องก่อนฟอนต์ระบบ"""
    import os
    dirs = [Path("C:/Windows/Fonts"),
            Path(os.environ.get("LOCALAPPDATA", "")) / "Microsoft" / "Windows" / "Fonts",
            Path.home() / "Library" / "Fonts", Path("/Library/Fonts"),
            Path("/usr/share/fonts"), Path.home() / ".fonts"]
    hits = []
    for d in dirs:
        if d.exists():
            hits += [p for p in d.rglob("*") if p.suffix.lower() in (".ttf", ".otf")
                     and "lineseed" in p.stem.replace(" ", "").lower()
                     and not p.name.startswith("._")          # ไฟล์ขยะ AppleDouble
                     and p.stat().st_size > 10_000]
    hits.sort(key=lambda p: ("_bd" not in p.stem.lower(), "bold" not in p.stem.lower()))
    return [str(p) for p in hits]


def find_font(size, custom=None):
    candidates = ([custom] if custom else []) + _brand_font_files() \
        + THAI_FONTS.get(platform.system(), []) + THAI_FONTS["Linux"]
    for p in candidates:
        if p and Path(p).exists():
            try:
                return ImageFont.truetype(p, size)
            except OSError:
                continue
    print("คำเตือน: ไม่พบ font ไทยในเครื่อง ใช้ font สำรอง (ระบุเองได้ด้วย --font)")
    return ImageFont.load_default(size)


def hex_rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def gradient(w, h, c1, c2, vertical=True):
    img = Image.new("RGB", (w, h))
    px = img.load()
    for y in range(h):
        for x in range(0, w, 4):
            k = (y / h) if vertical else (x / w)
            col = tuple(int(a + (b - a) * k) for a, b in zip(c1, c2))
            for dx in range(min(4, w - x)):
                px[x + dx, y] = col
    return img


def rounded_panel(draw, box, radius, fill):
    draw.rounded_rectangle(box, radius=radius, fill=fill)


def title_card(args, w, h):
    img = gradient(w, h, hex_rgb(args.color1), hex_rgb(args.color2))
    d = ImageDraw.Draw(img, "RGBA")
    # accent bar
    d.rectangle([int(w*0.08), int(h*0.44), int(w*0.08)+14, int(h*0.56)], fill=hex_rgb(args.accent))
    f1 = find_font(int(h * 0.11), args.font)
    f2 = find_font(int(h * 0.05), args.font)
    x = int(w * 0.11)
    if args.sub:
        d.text((x, int(h * 0.36)), args.sub, font=f2, fill=(255, 255, 255, 200))
    d.text((x, int(h * 0.44)), args.text, font=f1, fill="white")
    return img


def lower_third(args, w, h):
    """แถบชื่อโปร่งใส วางมุมล่างซ้าย — export เป็น PNG โปร่งใสทั้งเฟรม"""
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    f1 = find_font(int(h * 0.045), args.font)
    f2 = find_font(int(h * 0.03), args.font)
    pad = int(h * 0.02)
    tw = int(max(d.textlength(args.text, f1), d.textlength(args.sub or "", f2))) + pad * 4
    y0 = int(h * 0.78)
    box_h = int(h * 0.055) + (int(h * 0.045) if args.sub else 0) + pad * 2
    rounded_panel(d, [int(w*0.05), y0, int(w*0.05) + tw, y0 + box_h], 18, (15, 23, 42, 215))
    d.rectangle([int(w*0.05), y0, int(w*0.05) + 10, y0 + box_h], fill=hex_rgb(args.accent))
    d.text((int(w*0.05) + pad * 2, y0 + pad), args.text, font=f1, fill="white")
    if args.sub:
        d.text((int(w*0.05) + pad * 2, y0 + pad + int(h * 0.055)), args.sub,
               font=f2, fill=(203, 213, 225, 255))
    return img


def end_card(args, w, h):
    img = gradient(w, h, hex_rgb(args.color1), hex_rgb(args.color2))
    d = ImageDraw.Draw(img, "RGBA")
    f1 = find_font(int(h * 0.09), args.font)
    f2 = find_font(int(h * 0.045), args.font)
    tw = d.textlength(args.text, f1)
    d.text(((w - tw) / 2, int(h * 0.40)), args.text, font=f1, fill="white")
    if args.sub:
        tw2 = d.textlength(args.sub, f2)
        d.text(((w - tw2) / 2, int(h * 0.54)), args.sub, font=f2, fill=(255, 255, 255, 190))
    return img


def bg_gradient(args, w, h):
    img = gradient(w, h, hex_rgb(args.color1), hex_rgb(args.color2))
    return img.filter(ImageFilter.GaussianBlur(2))


TEMPLATES = {"title-card": title_card, "lower-third": lower_third,
             "end-card": end_card, "bg-gradient": bg_gradient}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("template", choices=TEMPLATES.keys())
    ap.add_argument("--text", default="")
    ap.add_argument("--sub", default="")
    ap.add_argument("--out", required=True)
    ap.add_argument("--width", type=int, default=1920)
    ap.add_argument("--height", type=int, default=1080)
    ap.add_argument("--color1", default="#0f172a")
    ap.add_argument("--color2", default="#1e3a8a")
    ap.add_argument("--accent", default="#f59e0b")
    ap.add_argument("--font", help="path ไปยังไฟล์ font เอง (เช่นซื้อ font แบรนด์มา)")
    args = ap.parse_args()

    out = Path(args.out); out.parent.mkdir(parents=True, exist_ok=True)
    img = TEMPLATES[args.template](args, args.width, args.height)
    img.save(out)
    print(f"OK: {out} ({args.width}x{args.height}, {args.template})")


if __name__ == "__main__":
    main()
