#!/usr/bin/env python3
"""Dev-Cut Kit - gen_icon: แปลงไอคอน Lucide (แถมมากับ kit ~2,000 ไอคอน) เป็น PNG โปร่งใสไว้ใช้ใน CapCut
ไอคอนอยู่ที่ icons/lucide/ (ISC license — ใช้เชิงพาณิชย์ได้ ไม่ต้องเครดิต) ทำงานออฟไลน์ 100%
Usage:
  python gen_icon.py camera --size 512 --color "#f59e0b" --out work/assets/camera.png
  python gen_icon.py --list heart          # ค้นหาชื่อไอคอนที่มีคำว่า heart
"""
import argparse, sys
from pathlib import Path

import sys as _sys
if hasattr(_sys.stdout, "reconfigure"):  # กัน error ภาษาไทยบน Windows codepage
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace")

ICON_DIR = Path(__file__).resolve().parents[4] / "icons" / "lucide"


def list_icons(term):
    names = sorted(p.stem for p in ICON_DIR.glob("*.svg"))
    hits = [n for n in names if term.lower() in n] if term else names
    for n in hits[:60]:
        print(" ", n)
    print(f"({len(hits)} รายการ" + (f" จากทั้งหมด {len(names)})" if term else ")"))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("name", nargs="?", help="ชื่อไอคอน เช่น camera, heart, arrow-right")
    ap.add_argument("--list", metavar="คำค้น", help="ค้นชื่อไอคอน")
    ap.add_argument("--size", type=int, default=512)
    ap.add_argument("--color", default="#ffffff")
    ap.add_argument("--stroke-width", type=float, default=2.0, help="ความหนาเส้น (1=บาง 3=หนา)")
    ap.add_argument("--out", help="ไฟล์ PNG ปลายทาง (default: <ชื่อไอคอน>.png)")
    args = ap.parse_args()

    if args.list is not None:
        return list_icons(args.list)
    if not args.name:
        sys.exit("ระบุชื่อไอคอน หรือใช้ --list <คำค้น> เพื่อค้นหา")

    src = ICON_DIR / f"{args.name}.svg"
    if not src.exists():
        near = [p.stem for p in ICON_DIR.glob("*.svg") if args.name.lower() in p.stem][:8]
        sys.exit(f"ไม่พบไอคอน '{args.name}'" + (f" — ใกล้เคียง: {', '.join(near)}" if near else
                 " — ลอง --list <คำค้น>"))

    try:
        import resvg_py
    except ImportError:
        sys.exit("ยังไม่ได้ติดตั้ง resvg-py — รัน: pip install resvg-py")

    svg = src.read_text(encoding="utf-8")
    svg = svg.replace('stroke="currentColor"', f'stroke="{args.color}"')
    if args.stroke_width != 2.0:
        svg = svg.replace('stroke-width="2"', f'stroke-width="{args.stroke_width}"')
    data = resvg_py.svg_to_bytes(svg_string=svg, width=args.size, height=args.size)
    out = Path(args.out or f"{args.name}.png")
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(bytes(data) if isinstance(data, list) else data)
    print(f"OK: {out} ({args.size}x{args.size}, {args.color}) — PNG โปร่งใส ลากเข้า CapCut ได้เลย")


if __name__ == "__main__":
    main()
