#!/usr/bin/env python3
"""Dev-Cut Kit - cutout: ลบพื้นหลังรูปภาพ/วิดีโอ (ได้ไฟล์โปร่งใสไปวางใน CapCut)
รูปภาพ → PNG โปร่งใส | วิดีโอ → WebM (VP9 + alpha) หรือ MOV (PNG codec)
ต้องติดตั้ง: pip install rembg[cpu] onnxruntime
Usage:
  python cutout.py photo.jpg --out-dir work/
  python cutout.py clip.mp4 --out-dir work/ --fps 15 --format webm
หมายเหตุ: วิดีโอใช้เวลานาน (ประมวลผลทีละเฟรม) — ลด --fps หรือใช้เฉพาะช่วงสั้น ๆ ด้วย --start/--end
"""
import argparse, subprocess, sys, tempfile
from pathlib import Path

import sys as _sys
if hasattr(_sys.stdout, "reconfigure"):  # กัน error ภาษาไทยบน Windows codepage
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace")


IMG_EXTS = {".jpg", ".jpeg", ".png", ".webp", ".bmp"}


def get_session(model):
    try:
        from rembg import new_session
    except ImportError:
        sys.exit("ยังไม่ได้ติดตั้ง rembg — รัน: pip install \"rembg[cpu]\"")
    return new_session(model)


def cutout_image(src: Path, out: Path, session):
    from rembg import remove
    out.write_bytes(remove(src.read_bytes(), session=session))
    print(f"OK: {out}")


def cutout_video(src: Path, out_dir: Path, session, fps, fmt, start, end):
    from rembg import remove
    frames_dir = Path(tempfile.mkdtemp(prefix="devcut_frames_"))
    seek = (["-ss", str(start)] if start else []) + (["-to", str(end)] if end else [])
    subprocess.run(["ffmpeg", "-v", "error", "-y", *seek, "-i", str(src),
                    "-vf", f"fps={fps}", str(frames_dir / "f_%05d.png")], check=True)
    frames = sorted(frames_dir.glob("f_*.png"))
    if not frames:
        sys.exit("แตกเฟรมไม่สำเร็จ")
    print(f"กำลังลบพื้นหลัง {len(frames)} เฟรม...")
    for i, f in enumerate(frames, 1):
        f.write_bytes(remove(f.read_bytes(), session=session))
        if i % 25 == 0 or i == len(frames):
            print(f"  {i}/{len(frames)}")
    if fmt == "webm":
        out = out_dir / (src.stem + "_cutout.webm")
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-framerate", str(fps),
                        "-i", str(frames_dir / "f_%05d.png"), "-c:v", "libvpx-vp9",
                        "-pix_fmt", "yuva420p", "-b:v", "2M", str(out)], check=True)
    else:  # mov (png codec, ไฟล์ใหญ่แต่คุณภาพเต็ม, CapCut รองรับ)
        out = out_dir / (src.stem + "_cutout.mov")
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-framerate", str(fps),
                        "-i", str(frames_dir / "f_%05d.png"), "-c:v", "png", str(out)],
                       check=True)
    print(f"OK: {out}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("--out-dir", default=".")
    ap.add_argument("--model", default="u2net_human_seg",
                    help="u2net_human_seg (คน, เร็ว) | u2net (ทั่วไป) | isnet-general-use (ละเอียด)")
    ap.add_argument("--fps", type=int, default=15, help="fps ของวิดีโอผลลัพธ์")
    ap.add_argument("--format", choices=["webm", "mov"], default="webm")
    ap.add_argument("--start", type=float, help="ตัดเฉพาะตั้งแต่วินาที")
    ap.add_argument("--end", type=float, help="ถึงวินาที")
    args = ap.parse_args()

    src = Path(args.input)
    out_dir = Path(args.out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    session = get_session(args.model)
    if src.suffix.lower() in IMG_EXTS:
        cutout_image(src, out_dir / (src.stem + "_cutout.png"), session)
    else:
        cutout_video(src, out_dir, session, args.fps, args.format, args.start, args.end)


if __name__ == "__main__":
    main()
