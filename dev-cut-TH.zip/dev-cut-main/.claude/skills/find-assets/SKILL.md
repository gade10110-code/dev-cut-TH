---
name: find-assets
description: ค้นหาและดาวน์โหลด asset ฟรีแบบถูกลิขสิทธิ์ — วิดีโอ b-roll, รูปภาพ, เสียงประกอบ (SFX) พร้อมไฟล์เครดิตอัตโนมัติ ใช้เมื่อผู้ใช้ขอ "หา b-roll", "หาเพลง/เสียงประกอบ", "หารูป", "find assets", "ขอ footage ประกอบ"
---

# find-assets — หา asset ฟรี

## วิธีใช้

```bash
python scripts/find_assets.py "<คำค้นภาษาอังกฤษ>" --type video --count 3 --out-dir <work>/assets
python scripts/find_assets.py "whoosh transition" --type sound --count 5 --out-dir <work>/assets
```

`--type`: `video` | `photo` | `sound`

## กติกาสำคัญ

1. **แปลคำค้นเป็นภาษาอังกฤษก่อนเสมอ** (API ไม่รองรับภาษาไทย) — "ตึกกรุงเทพตอนกลางคืน" → `"bangkok skyline night"`
2. ค้นหลาย ๆ คำค้นแคบ ๆ ดีกว่าคำเดียวกว้าง ๆ แล้วให้ผู้ใช้เลือก
3. ทุกไฟล์ถูกบันทึกเครดิตลง `assets/credits.json` — ตอน handoff ต้องเตือนผู้ใช้ก๊อปเครดิตไปใส่ description ของคลิป (เนื้อหา CC ส่วนใหญ่บังคับให้เครดิต)

## แหล่งข้อมูล — ทำงานได้แม้ไม่มี key เลย

| ประเภท | มี key | ไม่มี key (อัตโนมัติ) |
|--------|--------|----------------------|
| photo | Pexels / Pixabay | **Openverse + Wikimedia Commons** (ไม่ต้องสมัครอะไร) |
| sound | Freesound | **Openverse audio** + เสียงใน `sfx-pack/` ของ kit |
| video | Pexels / Pixabay | ไม่มีแหล่ง no-key — เสนอ 2 ทางเลือก: ใช้ `--type photo` หรือสร้างกราฟิกด้วย skill **gen-assets** |

- ก่อนค้นเสียงจากเน็ต **เช็ค `sfx-pack/` ก่อนเสมอ** — มี whoosh/pop/ding/riser ฯลฯ 18 เสียงพร้อมใช้ ไม่ต้องเครดิตใคร
- Keys (optional, สมัครฟรี): `PEXELS_API_KEY` (คุณภาพดีสุด), `PIXABAY_API_KEY`, `FREESOUND_API_KEY`
- ผู้ใช้อยากได้ b-roll วิดีโอบ่อย ๆ → แนะนำสมัคร Pexels (ฟรี 2 นาที ใช้ได้ถาวร)

ไฟล์ที่ได้ลากเข้า CapCut ได้ทันที
