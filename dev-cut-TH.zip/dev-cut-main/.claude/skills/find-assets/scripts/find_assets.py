#!/usr/bin/env python3
"""Dev-Cut Kit - find-assets: ค้นหา + ดาวน์โหลด asset ฟรี (วิดีโอ/รูป/เสียง) พร้อมไฟล์เครดิต
Sources: Pexels (วิดีโอ+รูป), Pixabay (วิดีโอ+รูป), Freesound (เสียงประกอบ)
ใส่ key ใน .env: PEXELS_API_KEY / PIXABAY_API_KEY / FREESOUND_API_KEY (ฟรีทุกตัว มีตัวไหนใช้ตัวนั้น)
Usage:
  python find_assets.py "city night" --type video --count 3 --out-dir work/assets/
  python find_assets.py "whoosh" --type sound --count 5 --out-dir work/assets/
"""
import argparse, json, os, re, sys
from pathlib import Path

import sys as _sys
if hasattr(_sys.stdout, "reconfigure"):  # กัน error ภาษาไทยบน Windows codepage
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace")



def load_env():
    for p in [Path.cwd() / ".env", Path(__file__).resolve().parents[4] / ".env"]:
        if p.exists():
            for line in p.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, _, v = line.partition("=")
                    os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


def dl(url, dest, headers=None):
    import requests
    with requests.get(url, headers=headers or {}, stream=True, timeout=120) as r:
        r.raise_for_status()
        with open(dest, "wb") as f:
            for chunk in r.iter_content(1 << 16):
                f.write(chunk)


def safe(name):
    return re.sub(r"[^\w\-]+", "_", name)[:60]


def search_pexels(query, kind, count):
    import requests
    key = os.environ.get("PEXELS_API_KEY")
    if not key:
        return []
    h = {"Authorization": key}
    if kind == "video":
        r = requests.get("https://api.pexels.com/videos/search",
                         params={"query": query, "per_page": count}, headers=h, timeout=60)
        items = r.json().get("videos", []) if r.ok else []
        out = []
        for v in items:
            files = sorted(v.get("video_files", []), key=lambda f: f.get("height") or 0)
            best = next((f for f in reversed(files) if (f.get("height") or 0) <= 1080), files[-1] if files else None)
            if best:
                out.append({"source": "pexels", "kind": "video", "id": v["id"],
                            "url": best["link"], "page": v.get("url", ""),
                            "credit": f"Video by {v.get('user', {}).get('name', 'Pexels creator')} on Pexels",
                            "ext": ".mp4"})
        return out
    else:
        r = requests.get("https://api.pexels.com/v1/search",
                         params={"query": query, "per_page": count}, headers=h, timeout=60)
        items = r.json().get("photos", []) if r.ok else []
        return [{"source": "pexels", "kind": "photo", "id": p["id"],
                 "url": p["src"]["large2x"], "page": p.get("url", ""),
                 "credit": f"Photo by {p.get('photographer', 'Pexels creator')} on Pexels",
                 "ext": ".jpg"} for p in items]


def search_pixabay(query, kind, count):
    import requests
    key = os.environ.get("PIXABAY_API_KEY")
    if not key:
        return []
    if kind == "video":
        r = requests.get("https://pixabay.com/api/videos/",
                         params={"key": key, "q": query, "per_page": count}, timeout=60)
        items = r.json().get("hits", []) if r.ok else []
        return [{"source": "pixabay", "kind": "video", "id": v["id"],
                 "url": (v["videos"].get("medium") or v["videos"]["small"])["url"],
                 "page": v.get("pageURL", ""),
                 "credit": f"Video by {v.get('user', 'Pixabay creator')} on Pixabay",
                 "ext": ".mp4"} for v in items]
    else:
        r = requests.get("https://pixabay.com/api/",
                         params={"key": key, "q": query, "per_page": count}, timeout=60)
        items = r.json().get("hits", []) if r.ok else []
        return [{"source": "pixabay", "kind": "photo", "id": p["id"],
                 "url": p.get("largeImageURL"), "page": p.get("pageURL", ""),
                 "credit": f"Image by {p.get('user', 'Pixabay creator')} on Pixabay",
                 "ext": ".jpg"} for p in items]


def search_freesound(query, count):
    import requests
    key = os.environ.get("FREESOUND_API_KEY")
    if not key:
        return []
    r = requests.get("https://freesound.org/apiv2/search/text/",
                     params={"query": query, "page_size": count,
                             "fields": "id,name,username,license,previews,url",
                             "token": key}, timeout=60)
    items = r.json().get("results", []) if r.ok else []
    return [{"source": "freesound", "kind": "sound", "id": s["id"],
             "url": s["previews"]["preview-hq-mp3"], "page": s.get("url", ""),
             "credit": f"\"{s['name']}\" by {s['username']} on Freesound ({s.get('license','')})",
             "ext": ".mp3"} for s in items]


UA = {"User-Agent": "DevCutKit/1.2 (video editing toolkit)"}


def search_openverse(query, kind, count):
    """Openverse (openverse.org) — ไม่ต้องมี key, เนื้อหา CC/public domain"""
    import requests
    endpoint = "audio" if kind == "sound" else "images"
    try:
        r = requests.get(f"https://api.openverse.org/v1/{endpoint}/",
                         params={"q": query, "page_size": count,
                                 "license_type": "commercial"},
                         headers=UA, timeout=60)
        items = r.json().get("results", []) if r.ok else []
    except Exception:
        return []
    out = []
    for it in items:
        url = it.get("url")
        if not url:
            continue
        ext = ".mp3" if kind == "sound" else Path(url.split("?")[0]).suffix or ".jpg"
        out.append({"source": "openverse", "kind": kind, "id": it.get("id", "")[:8],
                    "url": url, "page": it.get("foreign_landing_url", ""),
                    "credit": f"\"{it.get('title', 'untitled')}\" by {it.get('creator', 'unknown')} "
                              f"({it.get('license', 'cc').upper()}) via Openverse",
                    "ext": ext})
    return out


def search_wikimedia(query, count):
    """Wikimedia Commons — ไม่ต้องมี key"""
    import requests
    try:
        r = requests.get("https://commons.wikimedia.org/w/api.php",
                         params={"action": "query", "generator": "search",
                                 "gsrsearch": f"filetype:bitmap {query}",
                                 "gsrnamespace": 6, "gsrlimit": count,
                                 "prop": "imageinfo", "iiprop": "url|extmetadata",
                                 "format": "json"}, headers=UA, timeout=60)
        pages = r.json().get("query", {}).get("pages", {}) if r.ok else {}
    except Exception:
        return []
    out = []
    for p in pages.values():
        ii = (p.get("imageinfo") or [{}])[0]
        url = ii.get("url")
        if not url:
            continue
        meta = ii.get("extmetadata", {})
        artist = meta.get("Artist", {}).get("value", "unknown")
        artist = re.sub(r"<[^>]+>", "", artist)[:60]
        lic = meta.get("LicenseShortName", {}).get("value", "")
        out.append({"source": "wikimedia", "kind": "photo", "id": p.get("pageid"),
                    "url": url, "page": ii.get("descriptionurl", ""),
                    "credit": f"{p.get('title', '')} by {artist} ({lic}) via Wikimedia Commons",
                    "ext": Path(url).suffix or ".jpg"})
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("query")
    ap.add_argument("--type", choices=["video", "photo", "sound"], default="video")
    ap.add_argument("--count", type=int, default=3)
    ap.add_argument("--out-dir", default="assets")
    args = ap.parse_args()

    load_env()
    results = []
    if args.type == "sound":
        results = search_freesound(args.query, args.count)
        if not results:
            results = search_openverse(args.query, "sound", args.count)
        if not results:
            sys.exit("หาเสียงไม่เจอ — ลองคำค้นอื่น หรือใช้เสียงจาก sfx-pack/ ที่แถมมากับ kit "
                     "(อยากได้คลังใหญ่ขึ้น: ใส่ FREESOUND_API_KEY ฟรีที่ freesound.org/apiv2/apply)")
    elif args.type == "photo":
        results = search_pexels(args.query, "photo", args.count)
        results += search_pixabay(args.query, "photo", max(0, args.count - len(results)))
        if not results:
            results = search_openverse(args.query, "photo", args.count)
            results += search_wikimedia(args.query, max(0, args.count - len(results)))
        if not results:
            sys.exit("หารูปไม่เจอ — ลองคำค้นภาษาอังกฤษคำอื่น")
    else:  # video
        results = search_pexels(args.query, "video", args.count)
        results += search_pixabay(args.query, "video", max(0, args.count - len(results)))
        if not results and not (os.environ.get("PEXELS_API_KEY") or os.environ.get("PIXABAY_API_KEY")):
            sys.exit("b-roll วิดีโอต้องมี key (ฟรี): PEXELS_API_KEY หรือ PIXABAY_API_KEY\n"
                     "ทางเลือกไม่ใช้ key: --type photo (Openverse/Wikimedia) หรือสร้างกราฟิกเองด้วย skill gen-assets")

    out_dir = Path(args.out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    credits_path = out_dir / "credits.json"
    credits = json.loads(credits_path.read_text(encoding="utf-8")) if credits_path.exists() else []
    for item in results[: args.count]:
        fname = f"{item['source']}_{item['id']}_{safe(args.query)}{item['ext']}"
        dest = out_dir / fname
        print(f"ดาวน์โหลด {fname} ...")
        try:
            dl(item["url"], dest)
        except Exception as e:
            print(f"  ข้าม ({e})"); continue
        credits.append({"file": fname, "credit": item["credit"], "page": item["page"]})
    credits_path.write_text(json.dumps(credits, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"OK: {len(results[:args.count])} ไฟล์ → {out_dir}  (เครดิตอยู่ใน credits.json)")


if __name__ == "__main__":
    main()
