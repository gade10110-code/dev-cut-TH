#!/usr/bin/env python3
"""Dev-Cut Kit - capcut: สร้าง/อัปเดตโปรเจกต์ CapCut Desktop จาก cutplan.json + captions.srt
เปิด CapCut แล้วจะเห็นโปรเจกต์ใหม่ พร้อมคลิปที่ตัดช่วงเงียบแล้ว + ซับไตเติล — ลากแก้ต่อได้ทุกจุด
ซับถูก remap เวลาให้ตรงกับ timeline ที่ตัดแล้วอัตโนมัติ + ตั้งฟอนต์ซับได้ (ค่าเริ่มต้น: LINE Seed Sans TH ถ้าติดตั้งไว้)
Usage:
  python capcut_build.py --cutplan work/cutplan.json --srt work/captions.srt --name "คลิปรีวิว EP1"
  python capcut_build.py --video raw.mp4 --srt work/captions.srt --name "แค่ใส่ซับ"
"""
import argparse, json, os, platform, re, sys
from copy import deepcopy
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):  # กัน error ภาษาไทยบน Windows codepage
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

try:
    import pycapcut as cc
    from pycapcut import trange
except ImportError:
    sys.exit("ยังไม่ได้ติดตั้ง pycapcut — รัน: pip install pycapcut")


def default_draft_folder():
    system = platform.system()
    candidates = []
    if system == "Windows":
        local = os.environ.get("LOCALAPPDATA", "")
        candidates = [Path(local) / "CapCut" / "User Data" / "Projects" / "com.lveditor.draft"]
    elif system == "Darwin":
        candidates = [Path.home() / "Movies" / "CapCut" / "User Data" / "Projects" / "com.lveditor.draft"]
    for c in candidates:
        if c.exists():
            return str(c)
    return None


# ---------- font ----------

def font_dirs():
    system = platform.system()
    if system == "Windows":
        return [Path("C:/Windows/Fonts"),
                Path(os.environ.get("LOCALAPPDATA", "")) / "Microsoft" / "Windows" / "Fonts"]
    if system == "Darwin":
        return [Path.home() / "Library" / "Fonts", Path("/Library/Fonts"),
                Path("/System/Library/Fonts")]
    return [Path("/usr/share/fonts"), Path.home() / ".fonts"]


def find_font_file(name):
    """หาไฟล์ font ในเครื่องจากชื่อ (ตัดช่องว่าง เทียบแบบไม่สนตัวพิมพ์) เลือกน้ำหนัก Bold ก่อน"""
    want = re.sub(r"\s+", "", name).lower()
    hits = []
    for d in font_dirs():
        if not d.exists():
            continue
        for p in d.rglob("*"):
            if (p.suffix.lower() in (".ttf", ".otf")
                    and want in re.sub(r"\s+", "", p.stem).lower()
                    and not p.name.startswith("._")          # ไฟล์ขยะ AppleDouble จาก macOS
                    and p.stat().st_size > 10_000):          # ไฟล์ font จริงต้องใหญ่กว่า 10KB
                hits.append(p)
    if not hits:
        return None
    for pref in ("_bd", "bold", "_xbd"):
        for p in hits:
            if pref in p.stem.lower():
                return p
    return hits[0]


def apply_font_to_draft(draft_content_path, font_path):
    """แพตช์ draft JSON ให้ทุก text material ใช้ font จากไฟล์ในเครื่อง"""
    d = json.loads(Path(draft_content_path).read_text(encoding="utf-8"))
    fp = str(font_path).replace("\\", "/")
    n = 0
    for t in d.get("materials", {}).get("texts", []):
        try:
            c = json.loads(t["content"])
            for st in c.get("styles", []):
                st["font"] = {"id": "", "path": fp}
            t["content"] = json.dumps(c, ensure_ascii=False)
            t["font_path"] = fp
            t["font_name"] = Path(font_path).stem
            n += 1
        except (KeyError, json.JSONDecodeError):
            continue
    Path(draft_content_path).write_text(json.dumps(d, ensure_ascii=False), encoding="utf-8")
    return n


# ---------- style presets ----------

# แอนิเมชันซับตอน "โผล่" (ชื่อเข้าใจง่าย → ชื่อจริงใน CapCut) — คำเด้งแทนซับนิ่ง ๆ
SUB_ANIMS = {
    "bounce": "向上弹入",   # เด้งขึ้นจากล่าง — สไตล์ TikTok
    "pop":    "放大",       # ป่องออก/ซูมเข้า — เด้งดึ๋ง
    "glow":   "发光弹出",   # เรืองแสงแล้วเด้ง
    "type":   "打字机",     # พิมพ์ดีดทีละตัว
    "rise":   "向上擦除",   # ไล่โผล่ขึ้นจากล่าง
}

STYLE_PRESETS = {
    # ซับขาว ขอบดำบาง เรียบหรู — เหมาะ YouTube แนวนอน
    "clean": {"size": 7.0, "bold": False, "border_width": 25.0, "punch": False,
              "bg": None, "anim": None},
    # ซับใหญ่หนา ขอบดำหนัก + คำเด้งตอนโผล่ — TikTok/Reels เด่นแม้ดูบนมือถือ
    "bold": {"size": 11.0, "bold": True, "border_width": 70.0, "punch": False,
             "bg": None, "anim": "bounce"},
    # จัดเต็ม TikTok: แถบสีทึบหลังคำ + คำเด้ง ตัวใหญ่สุด — โดดเด่นสุด
    "pop": {"size": 12.0, "bold": True, "border_width": 0.0, "punch": False,
            "bg": {"color": "#000000", "alpha": 0.55, "round_radius": 20.0,
                   "height": 0.14, "width": 0.14}, "anim": "pop"},
    # แบบ bold + คำเด้ง + ซูมเข้าออกสลับทุกท่อนตัด (punch-in) ให้คลิปมีจังหวะแบบ vlogger
    "vlog": {"size": 9.0, "bold": True, "border_width": 55.0, "punch": True,
             "bg": None, "anim": "bounce"},
    "none": None,
}


def hex_to_rgb01(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))


# ---------- srt remap ----------

def parse_srt(path):
    text = Path(path).read_text(encoding="utf-8")
    blocks = []
    for m in re.finditer(r"(\d+:\d+:\d+[,.]\d+)\s*-->\s*(\d+:\d+:\d+[,.]\d+)\s*\n(.*?)(?:\n\s*\n|\Z)",
                         text, re.S):
        def ts(s):
            h, mnt, rest = s.split(":")
            sec = rest.replace(",", ".")
            return int(h) * 3600 + int(mnt) * 60 + float(sec)
        blocks.append({"start": ts(m.group(1)), "end": ts(m.group(2)),
                       "text": m.group(3).strip()})
    return blocks


def fmt_ts(t):
    h, rem = divmod(t, 3600); m, s = divmod(rem, 60)
    return f"{int(h):02}:{int(m):02}:{int(s):02},{int(round((s % 1) * 1000)):03}"


def make_to_timeline(keeps):
    """คืนฟังก์ชันแปลงเวลาต้นฉบับ → เวลาบน timeline ที่ตัดช่วงเงียบออกแล้ว + ความยาวรวม"""
    targets, acc = [], 0.0
    for a, b in keeps:
        targets.append(acc)
        acc += b - a
    total = acc

    def to_timeline(t):
        for (a, b), ts0 in zip(keeps, targets):
            if t < a:
                return ts0            # อยู่ในช่วงที่ถูกตัด → ดันไปต้นช่วง keep ถัดไป
            if t <= b:
                return ts0 + (t - a)  # อยู่ในช่วง keep → เลื่อนตาม offset
        return total

    return to_timeline, total


def remap_srt(srt_path, keeps, out_path):
    """แปลงเวลาซับจากเวลาในคลิปต้นฉบับ → เวลาบน timeline ที่ตัดช่วงเงียบออกแล้ว"""
    to_timeline, _ = make_to_timeline(keeps)
    blocks, kept = parse_srt(srt_path), []
    for blk in blocks:
        s, e = to_timeline(blk["start"]), to_timeline(blk["end"])
        if e - s < 0.15:              # ซับทั้งบรรทัดอยู่ในช่วงที่ถูกตัดทิ้ง
            continue
        kept.append({"start": s, "end": e, "text": blk["text"]})
    out = "\n".join(f"{i+1}\n{fmt_ts(b['start'])} --> {fmt_ts(b['end'])}\n{b['text']}\n"
                    for i, b in enumerate(kept))
    Path(out_path).write_text(out, encoding="utf-8")
    return len(blocks), len(kept)


# ---------- karaoke (ไฮไลต์คำที่กำลังพูด) ----------

def tokenize_ranges(text):
    """แตกข้อความเป็นคำ + ตำแหน่งตัวอักษร [(word, start, end)] เฉพาะคำจริง (ข้ามช่องว่าง)
    ใช้ pythainlp ถ้ามี ไม่งั้น fallback เป็นตัดที่เว้นวรรค"""
    try:
        from pythainlp.tokenize import word_tokenize
        toks = word_tokenize(text, keep_whitespace=True)
    except Exception:
        toks, parts = [], text.split(" ")
        for i, p in enumerate(parts):
            if i:
                toks.append(" ")
            toks.append(p)
    out, pos = [], 0
    for tk in toks:
        n = len(tk)
        if tk.strip():
            out.append((tk, pos, pos + n))
        pos += n
    return out


def build_karaoke_segments(srt_path, style, border, background, clip, intro):
    """สร้าง TextSegment ราย 'คำ' — แต่ละคำแสดงทั้งบรรทัด แต่คนละช่วงเวลา
    (post-process ทีหลังจะระบายสีคำที่ตรงเวลานั้น) คืน (segments, specs, n_lines)"""
    blocks = parse_srt(srt_path)
    segs, specs, n_lines = [], [], 0
    for blk in blocks:
        T = re.sub(r"\s*\n\s*", " ", blk["text"]).strip()
        wr = tokenize_ranges(T)
        if not wr:
            continue
        n_lines += 1
        # ทำงานเป็นจำนวนเต็มไมโครวินาที — ขอบ segment ชนกันเป๊ะ ไม่เหลื่อมจากปัดเศษ float
        t0_us, t1_us = round(blk["start"] * 1e6), round(blk["end"] * 1e6)
        dur_us = max(t1_us - t0_us, 50_000)
        total = sum(e - s for _, s, e in wr) or 1
        acc, first = t0_us, True
        for _w, cs, ce in wr:
            we = acc + round(dur_us * (ce - cs) / total)
            if we - acc < 80_000:            # คำเร็ว ๆ ให้ไฮไลต์อย่างน้อยพอเห็น (~0.08s)
                we = acc + 80_000
            we = min(we, t1_us)              # ห้ามเลยท้ายบรรทัด (กันซ้อนกับบรรทัดถัดไป)
            if we - acc <= 1_000:            # เวลาหมดพอดี — ข้ามคำที่เหลือ
                break
            seg = cc.TextSegment(T, trange(acc, we - acc),
                                 style=style, border=border, background=background,
                                 clip_settings=clip)
            if first and intro is not None:  # คำแรกของบรรทัด "เด้ง" เข้ามา
                seg.add_animation(intro, "0.3s")
                first = False
            segs.append(seg)
            specs.append((cs, ce))
            acc = we
    return segs, specs, n_lines


def build_karaoke_realtime(segments, keeps, style, border, background, clip, intro):
    """karaoke จาก 'เวลาคำจริง' ใน transcript.segments[].words — แม่นกว่าการเกลี่ยตามความยาว
    ไฮไลต์คำ i ตั้งแต่คำนั้นเริ่มพูด จนคำถัดไปเริ่ม (ต่อเนื่องไม่มีช่องว่าง) คืน (segments, specs, n_lines)"""
    to_tl = (make_to_timeline(keeps)[0] if keeps else (lambda x: x))
    out, specs, n_lines = [], [], 0
    for seg in segments:
        T = re.sub(r"\s*\n\s*", " ", seg["text"]).strip()
        words = seg.get("words") or []
        if not words:
            continue
        ls, le = to_tl(seg["start"]), to_tl(seg["end"])
        ls_us, le_us = round(ls * 1e6), round(le * 1e6)
        if le_us - ls_us < 150_000:          # ทั้งบรรทัดอยู่ในช่วงที่ถูกตัด → ข้าม
            continue
        # ตำแหน่งตัวอักษรของแต่ละคำใน T (นับเว้นวรรคด้วย) + จุดเริ่มไฮไลต์ (จำนวนเต็ม µs)
        ranges, bounds, pos = [], [ls_us], 0
        for i, w in enumerate(words):
            wt = w["text"]
            while pos < len(T) and T[pos].isspace():
                pos += 1
            ranges.append((pos, pos + len(wt)))
            pos += len(wt)
            if i > 0:                          # คำแรกเริ่มพร้อมบรรทัด (ให้ซับโผล่ทันเสียง)
                b = max(bounds[-1] + 30_000, round(to_tl(w["start"]) * 1e6))
                bounds.append(min(b, le_us))
        bounds.append(le_us)                   # จุดจบของคำสุดท้าย
        n_lines += 1
        first = True
        for i, (cs, ce) in enumerate(ranges):
            a, b = bounds[i], bounds[i + 1]
            if b - a < 50_000:                 # สั้นไป/หมดเวลาแล้ว
                continue
            s = cc.TextSegment(T, trange(a, b - a), style=style, border=border,
                               background=background, clip_settings=clip)
            if first and intro is not None:
                s.add_animation(intro, "0.3s")
                first = False
            out.append(s)
            specs.append((cs, ce))
    return out, specs, n_lines


def inject_karaoke(draft_content_path, specs, base_rgb, hl_rgb):
    """แพตช์ styles ของแต่ละ text material ให้มี 3 ช่วง: ก่อนคำ(สีปกติ) คำที่พูด(สีไฮไลต์) หลังคำ(สีปกติ)
    จับคู่ตามลำดับ segment ในแทร็ก text — ต้องเรียงตรงกับตอนสร้าง"""
    d = json.loads(Path(draft_content_path).read_text(encoding="utf-8"))
    tmap = {t["id"]: t for t in d.get("materials", {}).get("texts", [])}
    seg_ids = []
    for tr in d.get("tracks", []):
        if tr.get("type") == "text":
            seg_ids = [s["material_id"] for s in tr.get("segments", [])]
            break

    def paint(base_style, rng, color):
        st = deepcopy(base_style)
        st["range"] = [rng[0], rng[1]]
        st.setdefault("fill", {}).setdefault("content", {}).setdefault("solid", {})["color"] = list(color)
        return st

    n = 0
    for mid, (hs, he) in zip(seg_ids, specs):
        mat = tmap.get(mid)
        if not mat:
            continue
        c = json.loads(mat["content"])
        base = c["styles"][0]
        L = len(c.get("text", ""))
        he = min(he, L); hs = min(hs, he)
        styles = []
        if hs > 0:
            styles.append(paint(base, (0, hs), base_rgb))
        styles.append(paint(base, (hs, he), hl_rgb))
        if he < L:
            styles.append(paint(base, (he, L), base_rgb))
        c["styles"] = styles
        mat["content"] = json.dumps(c, ensure_ascii=False)
        n += 1
    Path(draft_content_path).write_text(json.dumps(d, ensure_ascii=False), encoding="utf-8")
    return n


# ---------- เพลงพื้นหลัง + auto-duck ----------

def speech_regions(srt_path, gap_merge=0.4):
    """รวมช่วงที่มีคนพูดจากซับ (บน timeline) — ช่วงห่างกัน < gap_merge ถือเป็นช่วงเดียว"""
    spans = sorted((b["start"], b["end"]) for b in parse_srt(srt_path))
    merged = []
    for s, e in spans:
        if merged and s - merged[-1][1] <= gap_merge:
            merged[-1][1] = max(merged[-1][1], e)
        else:
            merged.append([s, e])
    return merged


def place_music(script, music_path, total_us, regions, music_vol, duck_to, duck):
    """วางเพลงพื้นหลังเต็มคลิป (วนถ้าสั้นไป) + หรี่เสียงตอนคนพูดด้วย volume keyframe"""
    amat = cc.AudioMaterial(str(music_path))
    mdur = round(amat.duration) if getattr(amat, "duration", None) else 0
    if mdur <= 0:
        return None
    script.add_track(cc.TrackType.audio, "music")
    sp_us = [(round(s * 1e6), round(e * 1e6)) for s, e in regions]
    fade = 80_000
    pos = 0
    while pos < total_us:
        seglen = min(mdur, total_us - pos)
        seg = cc.AudioSegment(amat, trange(pos, seglen),
                              source_timerange=trange(0, seglen), volume=music_vol)
        if duck and sp_us:
            kf = {0: music_vol, seglen: music_vol}   # baseline หัว-ท้ายท่อน
            for s, e in sp_us:
                a, b = max(s, pos), min(e, pos + seglen)
                if b - a <= 0:
                    continue
                for to, v in ((a - pos - fade, music_vol), (a - pos, duck_to),
                              (b - pos, duck_to), (b - pos + 2 * fade, music_vol)):
                    kf[max(0, min(seglen, to))] = v
            for to in sorted(kf):
                seg.add_keyframe(to, kf[to])
        script.add_segment(seg, "music")
        pos += seglen
    return mdur


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cutplan", help="cutplan.json จาก clean-cut")
    ap.add_argument("--video", help="หรือใส่วิดีโอตรง ๆ (ไม่ตัด)")
    ap.add_argument("--srt", help="captions.srt จาก transcribe (เวลาอิงคลิปต้นฉบับ — remap ให้อัตโนมัติ)")
    ap.add_argument("--name", default="Dev-Cut Draft")
    ap.add_argument("--draft-folder", help="โฟลเดอร์ draft ของ CapCut (ปกติหาให้อัตโนมัติ)")
    ap.add_argument("--width", type=int, default=1920)
    ap.add_argument("--height", type=int, default=1080)
    ap.add_argument("--font-size", type=float, default=None,
                    help="ขนาดซับ (ปกติให้ preset เลือกให้)")
    ap.add_argument("--font", default="LINE Seed Sans TH",
                    help='ชื่อฟอนต์ซับ (หาไฟล์ในเครื่องอัตโนมัติ) | "none" = ฟอนต์ default ของ CapCut')
    ap.add_argument("--style", choices=list(STYLE_PRESETS) + ["auto"], default="auto",
                    help="preset ความสวย: clean (เรียบ) | bold (TikTok ซับใหญ่ขอบหนา) | "
                         "vlog (bold + ซูมสลับ) | none — auto=เลือกตามแนวจอ")
    ap.add_argument("--text-color", default="#ffffff", help="สีตัวหนังสือซับ (hex)")
    ap.add_argument("--sub-bg", default=None,
                    help='แถบสีทึบหลังตัวหนังสือ: hex เช่น "#000000" เปิดกล่อง | "none" ปิด '
                         "(ปกติตาม preset — pop มีกล่อง, อื่น ๆ ไม่มี)")
    ap.add_argument("--sub-anim", default=None,
                    help="แอนิเมชันซับตอนโผล่: bounce|pop|glow|type|rise | none ปิด "
                         "(ปกติตาม preset)")
    ap.add_argument("--allow-pro", action="store_true",
                    help="อนุญาตฟีเจอร์ที่ต้องมี CapCut Pro (เช่น animation ซับเด้ง) — "
                         "ปิดไว้เป็นค่าเริ่มต้นเพื่อให้ export ได้ฟรี ไม่มีป๊อปอัพ Pro")
    ap.add_argument("--karaoke", dest="karaoke", action="store_true", default=None,
                    help="ไฮไลต์คำที่กำลังพูดทีละคำ (rolling แบบ YouTube/viral) — บังคับเปิด "
                         "(ปกติเปิดอัตโนมัติสำหรับสไตล์แนวตั้ง bold/vlog/pop)")
    ap.add_argument("--no-karaoke", dest="karaoke", action="store_false", default=None,
                    help="บังคับปิด karaoke (ใช้ซับนิ่งทีละบรรทัดแทน)")
    ap.add_argument("--transcript", default=None,
                    help="transcript.json จาก transcribe — karaoke จะใช้ 'เวลาคำจริง' ให้ตรงเป๊ะ "
                         "(ปกติหาให้อัตโนมัติข้าง ๆ ไฟล์ srt)")
    ap.add_argument("--highlight-color", default="#ffe600",
                    help="สีคำที่กำลังพูดในโหมด karaoke (hex, ค่าเริ่มต้นเหลือง)")
    ap.add_argument("--transition", help="ชื่อ transition ระหว่างท่อน (จาก CapCut เช่น Pull_In) — ปกติไม่ใส่")
    ap.add_argument("--sfx", default=None,
                    help="ใส่เสียงเอฟเฟกต์ตรงรอยตัดทุกจุดอัตโนมัติ (เฉพาะคลิปที่ตัด jump cut): "
                         "auto=whoosh_soft | ชื่อไฟล์ใน sfx-pack เช่น whoosh_fast, pop, transition_hit "
                         "| none ปิด (ค่าเริ่มต้น)")
    ap.add_argument("--sfx-volume", type=float, default=0.6,
                    help="ความดังเสียง SFX (0-1, ค่าเริ่มต้น 0.6)")
    ap.add_argument("--music", default=None,
                    help="ไฟล์เพลงพื้นหลัง (ผู้ใช้เตรียมเอง) — วนยาวเต็มคลิป + หรี่เสียงตอนคนพูดอัตโนมัติ")
    ap.add_argument("--music-volume", type=float, default=0.18,
                    help="ความดังเพลงตอนไม่มีคนพูด (0-1, ค่าเริ่มต้น 0.18)")
    ap.add_argument("--duck-to", type=float, default=0.06,
                    help="ความดังเพลงตอนคนพูด (auto-duck, ค่าเริ่มต้น 0.06)")
    ap.add_argument("--no-duck", action="store_true",
                    help="ปิด auto-duck (เพลงดังเท่ากันตลอด)")
    ap.add_argument("--fill", action="store_true",
                    help="(เก่า — ตอนนี้ระบบเลือกวิธีเต็มเฟรมให้อัตโนมัติอยู่แล้ว)")
    ap.add_argument("--fit-mode", choices=["auto", "zoom", "blur", "fit"], default="auto",
                    help="วิธีจัดคลิปให้เต็มเฟรม: auto=เลือกให้ (ซูมนิดหน่อยถ้าพอไหว, "
                         "เกิน 1.6x ใช้พื้นหลังเบลอแทน) | zoom=ครอปเต็มจอ | "
                         "blur=วิดีโอพอดี+ฉากหลังเบลอ | fit=วางพอดีเฉย ๆ")
    args = ap.parse_args()

    if args.style == "auto":
        args.style = "bold" if args.height > args.width else "clean"

    # karaoke default = auto: เปิดเองสำหรับสไตล์แนวตั้ง/viral (bold/vlog/pop) ที่ดูบนมือถือ
    # ปิดสำหรับ clean (YouTube แนวนอน) ที่ซับนิ่งอ่านง่ายกว่า — override ด้วย --karaoke / --no-karaoke
    karaoke_on = args.karaoke
    if karaoke_on is None:
        karaoke_on = args.style in ("bold", "vlog", "pop")

    if not args.cutplan and not args.video:
        sys.exit("ต้องใส่ --cutplan หรือ --video อย่างใดอย่างหนึ่ง")

    folder = args.draft_folder or default_draft_folder()
    if not folder:
        sys.exit("หาโฟลเดอร์ draft ของ CapCut ไม่เจอ — เปิด CapCut Desktop สักครั้ง "
                 "หรือระบุเองด้วย --draft-folder")

    if args.cutplan:
        plan = json.loads(Path(args.cutplan).read_text(encoding="utf-8"))
        source = plan["source"]
        keeps = [(k["start"], k["end"]) for k in plan["keeps"]]
        did_cut = True
    else:
        source = str(Path(args.video).resolve())
        keeps = None
        did_cut = False

    if not Path(source).exists():
        sys.exit(f"ไม่พบไฟล์วิดีโอต้นฉบับ: {source}")

    df = cc.DraftFolder(folder)
    script = df.create_draft(args.name, args.width, args.height, allow_replace=True)
    script.add_track(cc.TrackType.video, "main")

    mat = cc.VideoMaterial(source)
    if keeps is None:
        keeps = [(0.0, mat.duration / 1_000_000)]

    preset = STYLE_PRESETS[args.style]
    punch = bool(preset and preset["punch"]) and did_cut and len(keeps) > 1

    # จัดคลิปให้เต็มเฟรม: คำนวณ scale ที่ต้องใช้ แล้วเลือกวิธีที่ภาพไม่พัง
    fill_scale, use_blur, fit_mode = 1.0, False, args.fit_mode
    if mat.width and mat.height:
        canvas_ar = args.width / args.height
        src_ar = mat.width / mat.height
        need = round(max(src_ar / canvas_ar, canvas_ar / src_ar), 3)
        if fit_mode == "auto":
            if need <= 1.05:
                fit_mode = "fit"          # สัดส่วนใกล้กันอยู่แล้ว
            elif need <= 1.6:
                fit_mode = "zoom"         # ซูมนิดหน่อย รับได้
            else:
                fit_mode = "blur"         # ซูมเยอะไป → ฉากหลังเบลอ (ภาพชัด ดูโปร)
        if fit_mode == "zoom":
            fill_scale = need
        elif fit_mode == "blur":
            use_blur = True

    trans_type = None
    if args.transition:
        trans_type = getattr(cc.TransitionType, args.transition, None)
        if trans_type is None:
            print(f"คำเตือน: ไม่รู้จัก transition '{args.transition}' — ข้ามไป")

    t = 0.0
    segs = []
    cut_times = []          # เวลาบน timeline ของ "รอยตัด" แต่ละจุด (ไว้วาง SFX)
    for i, (a, b) in enumerate(keeps):
        dur = b - a
        if dur <= 0:
            continue
        if segs:            # ไม่ใช่ท่อนแรก → t ตอนนี้คือจุดเริ่มท่อนนี้ = รอยตัด
            cut_times.append(t)
        clip_s = cc.ClipSettings(scale_x=fill_scale, scale_y=fill_scale) \
            if fill_scale != 1.0 else None
        seg = cc.VideoSegment(mat, trange(f"{t}s", f"{dur}s"),
                              source_timerange=trange(f"{a}s", f"{dur}s"),
                              clip_settings=clip_s)
        if use_blur:
            try:
                seg.add_background_filling("blur", 0.75)
            except Exception:
                pass
        if punch:
            # ซูมนุ่มต่อเนื่อง: ท่อนคู่ซูมเข้า 100→104% ท่อนคี่ถอยกลับ — ภาพขยับตลอดแบบเนียน
            zin = round(fill_scale * 1.04, 3)
            z0, z1 = (fill_scale, zin) if i % 2 == 0 else (zin, fill_scale)
            seg.add_keyframe(cc.KeyframeProperty.uniform_scale, "0s", z0)
            seg.add_keyframe(cc.KeyframeProperty.uniform_scale, f"{dur}s", z1)
        if trans_type and segs:
            segs[-1].add_transition(trans_type)
        script.add_segment(seg, "main")
        segs.append(seg)
        t += dur

    # ---- SFX อัตโนมัติตรงรอยตัด (เฉพาะคลิป jump cut) ----
    sfx_used = None
    if args.sfx and args.sfx.lower() != "none":
        if not cut_times:
            print("หมายเหตุ: SFX ตรงรอยตัดใช้ได้เฉพาะคลิปที่ตัด jump cut (หลายท่อน) — คลิปนี้ไม่มีรอยตัด ข้าม")
        else:
            sfx_name = "whoosh_soft" if args.sfx.lower() == "auto" else args.sfx
            sfx_file = Path(__file__).resolve().parents[4] / "sfx-pack" / f"{sfx_name}.wav"
            if not sfx_file.exists():
                print(f"คำเตือน: ไม่พบเสียง '{sfx_name}' ใน sfx-pack — ข้าม SFX")
            else:
                script.add_track(cc.TrackType.audio, "sfx")
                amat = cc.AudioMaterial(str(sfx_file))
                sfx_us = round(amat.duration) if getattr(amat, "duration", None) else 500_000
                lead_us, last_end, placed = 120_000, 0, 0   # เริ่มก่อนรอยตัดนิดให้พีคตรงตัด
                cuts_us = [round(c * 1e6) for c in cut_times]
                for idx, ct in enumerate(cuts_us):
                    s = max(last_end, ct - lead_us)          # กันซ้อนกับ SFX ตัวก่อน
                    d = sfx_us
                    if idx + 1 < len(cuts_us):               # กันซ้อนกับรอยตัดถัดไป
                        d = min(d, (cuts_us[idx + 1] - lead_us) - s)
                    if d <= 50_000:
                        continue
                    aseg = cc.AudioSegment(amat, trange(s, d), volume=args.sfx_volume)
                    script.add_segment(aseg, "sfx")
                    placed += 1
                    last_end = s + d
                sfx_used = f"{sfx_name} ×{placed}"

    n_caps = dropped = 0
    anim_used = None
    bg_on = False
    karaoke_pending = None
    karaoke_mode = None
    srt_to_use = args.srt
    if args.srt and Path(args.srt).exists():
        if did_cut:  # remap เวลาให้ตรง timeline ที่ตัดแล้ว (จุดที่เคยทำซับเหลื่อม)
            srt_to_use = str(Path(args.srt).with_name("captions_timeline.srt"))
            n_total, n_kept = remap_srt(args.srt, keeps, srt_to_use)
            n_caps, dropped = n_kept, n_total - n_kept
        script.add_track(cc.TrackType.text, "captions")
        size = args.font_size or (preset["size"] if preset else 8.0)
        bw = preset["border_width"] if preset else 0
        if args.height > args.width:      # จอแนวตั้ง: ซับต้องใหญ่ขึ้นถึงอ่านง่ายบนมือถือ
            size = round(size * 1.3, 1)
            bw = round(bw * 1.2, 1)
        style = cc.TextStyle(size=size, align=1, color=hex_to_rgb01(args.text_color),
                             bold=bool(preset and preset["bold"]), auto_wrapping=True,
                             max_line_width=0.85)
        border = cc.TextBorder(width=bw) if (preset and bw) else None

        # แถบสีทึบหลังคำ (highlight box) — เปิดตาม preset หรือ --sub-bg
        bg_cfg = (preset or {}).get("bg")
        if args.sub_bg is not None:
            bg_cfg = None if args.sub_bg.lower() == "none" else {
                "color": args.sub_bg, "alpha": 0.55, "round_radius": 20.0,
                "height": 0.14, "width": 0.14}
        background = None
        if bg_cfg:
            background = cc.TextBackground(color=bg_cfg["color"], alpha=bg_cfg["alpha"],
                                           round_radius=bg_cfg["round_radius"],
                                           height=bg_cfg["height"], width=bg_cfg["width"])
            bg_on = True

        clip = cc.ClipSettings(transform_y=-0.72)

        # แอนิเมชันซับตอนโผล่ (คำเด้ง)
        anim_key = (preset or {}).get("anim")
        if args.sub_anim is not None:
            anim_key = None if args.sub_anim.lower() == "none" else args.sub_anim
        # animation ซับของ CapCut เป็นฟีเจอร์ Pro — ปิดเป็นค่าเริ่มต้นให้ export ได้ฟรี ไม่เจอป๊อปอัพ Pro
        if anim_key and not args.allow_pro:
            print(f"ℹ ปิด animation ซับ '{anim_key}' (เป็นฟีเจอร์ CapCut Pro) — "
                  f"โปรเจกต์นี้ export ได้ฟรี ไม่มีป๊อปอัพ Pro · อยากได้ใส่ --allow-pro (ต้องมี CapCut Pro)")
            anim_key = None
        elif anim_key and args.allow_pro:
            print(f"⚠ ใช้ animation ซับ '{anim_key}' ซึ่งต้องมี CapCut Pro ตอน export "
                  f"(ไม่มี Pro จะเจอป๊อปอัพให้อัปเกรด)")
        intro = None
        if anim_key:
            anim_cn = SUB_ANIMS.get(anim_key, anim_key)  # เผื่อผู้ใช้ใส่ชื่อจริงของ CapCut
            intro = getattr(cc.TextIntro, anim_cn, None)
            if intro is not None:
                anim_used = anim_key
            else:
                print(f"คำเตือน: ไม่รู้จักแอนิเมชันซับ '{anim_key}' — ข้ามไป")

        if karaoke_on:
            # หา transcript.json (มีเวลาคำจริง) — ระบุเอง หรือข้าง ๆ srt ต้นฉบับ
            tj_path = args.transcript
            if not tj_path:
                cand = Path(args.srt).with_name("transcript.json")
                tj_path = str(cand) if cand.exists() else None
            tj_words = None
            if tj_path and Path(tj_path).exists():
                tj = json.loads(Path(tj_path).read_text(encoding="utf-8"))
                if any(s.get("words") for s in tj.get("segments", [])):
                    tj_words = tj["segments"]

            if tj_words:  # เวลาคำจริง — ตรงเป๊ะ
                ksegs, kspecs, n_lines = build_karaoke_realtime(
                    tj_words, keeps if did_cut else None,
                    style, border, background, clip, intro)
                karaoke_mode = "เวลาคำจริง"
            else:         # ไม่มี transcript → เกลี่ยตามความยาวคำ (ประมาณ)
                print("⚠ karaoke ใช้ 'เวลาเกลี่ย' (ไม่แม่น) เพราะไม่พบ transcript.json ที่มี words ข้าง ๆ srt\n"
                      "  → วาง transcript.json ไว้โฟลเดอร์เดียวกับ srt หรือระบุ --transcript <path> "
                      "เพื่อให้ karaoke ตรงคำจริง (ผลของ refine/align จะได้ไม่หล่น)")
                ksegs, kspecs, n_lines = build_karaoke_segments(
                    srt_to_use, style, border, background, clip, intro)
                karaoke_mode = "เกลี่ยเวลา (ไม่พบ word times)"
            for s in ksegs:
                script.add_segment(s, "captions")
            karaoke_pending = (kspecs, hex_to_rgb01(args.text_color),
                               hex_to_rgb01(args.highlight_color))
            if not did_cut:
                n_caps = n_lines
        else:
            # create_from_template ก็อป box + animation ให้ทุกบรรทัดอัตโนมัติ
            ref = cc.TextSegment("", trange("0s", "1s"), style=style, border=border,
                                 background=background, clip_settings=clip)
            if intro is not None:
                ref.add_animation(intro, "0.4s")
            script.import_srt(srt_to_use, "captions", style_reference=ref, clip_settings=clip)
            if not did_cut:
                n_caps = Path(srt_to_use).read_text(encoding="utf-8").count("-->")

    # ---- เพลงพื้นหลัง + auto-duck ----
    music_used = None
    if args.music:
        music_path = Path(args.music)
        if not music_path.exists():
            print(f"คำเตือน: ไม่พบไฟล์เพลง '{args.music}' — ข้ามเพลงพื้นหลัง")
        else:
            regions = (speech_regions(srt_to_use)
                       if (srt_to_use and Path(srt_to_use).exists()) else [])
            duck = (not args.no_duck) and bool(regions)
            mdur = place_music(script, music_path, round(t * 1e6), regions,
                               args.music_volume, args.duck_to, duck)
            if mdur:
                music_used = (f"{music_path.name} (vol {args.music_volume}"
                              + (f", duck→{args.duck_to} ตอนพูด" if duck else "") + ")")

    script.save()

    draft_json = Path(folder) / args.name / "draft_content.json"
    if karaoke_pending:  # ระบายสีคำที่พูด — ต้องทำก่อนแพตช์ฟอนต์ (ให้ฟอนต์ลงทุกช่วงสี)
        kspecs, base_rgb, hl_rgb = karaoke_pending
        inject_karaoke(draft_json, kspecs, base_rgb, hl_rgb)

    font_msg = ""
    if args.srt and args.font.lower() != "none":
        f = find_font_file(args.font)
        if f:
            patched = apply_font_to_draft(draft_json, f)
            font_msg = f"  ฟอนต์ซับ: {f.name} ({patched} บรรทัด)"
        else:
            font_msg = (f"  ฟอนต์ '{args.font}' ยังไม่ได้ติดตั้งในเครื่อง — ใช้ฟอนต์ default ไปก่อน\n"
                        f"  (LINE Seed โหลดฟรี: https://seed.line.me แล้วรันใหม่ หรือเปลี่ยนฟอนต์เองใน CapCut)")

    print("== Dev-Cut capcut ==")
    print(f"สร้างโปรเจกต์: {args.name}")
    print(f"  คลิป: {len(keeps)} ช่วง รวม {t:.1f}s")
    if n_caps:
        print(f"  ซับไตเติล: {n_caps} บรรทัด (remap เวลาตาม cutplan แล้ว"
              + (f", ตัดทิ้ง {dropped} บรรทัดที่อยู่ในช่วงเงียบ)" if dropped else ")"))
    fitdesc = ""
    if use_blur:
        fitdesc = " + ฉากหลังเบลอเต็มเฟรม"
    elif fill_scale != 1.0:
        fitdesc = f" + ซูมเต็มเฟรม {fill_scale}x"
    print(f"  สไตล์: {args.style}"
          + (f" + karaoke ไฮไลต์คำ ({args.highlight_color}, {karaoke_mode})" if karaoke_pending else "")
          + (" + แถบสีหลังคำ" if bg_on else "")
          + (f" + คำเด้ง({anim_used})" if anim_used else "")
          + (" + ซูมนุ่มต่อเนื่อง" if punch else "")
          + (f" + SFX รอยตัด ({sfx_used})" if sfx_used else "")
          + (f" + เพลง {music_used}" if music_used else "")
          + (f" + transition {args.transition}" if trans_type else "") + fitdesc)
    if font_msg:
        print(font_msg)
    print(f"  ที่: {folder}")
    print("เปิด CapCut Desktop แล้วเลือกโปรเจกต์นี้ได้เลย "
          "(ถ้า CapCut เปิดค้างอยู่ ให้ปิด-เปิดใหม่เพื่อรีเฟรชรายการ)")


if __name__ == "__main__":
    main()
