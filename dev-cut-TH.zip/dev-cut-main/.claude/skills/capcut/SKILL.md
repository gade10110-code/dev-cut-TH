---
name: capcut
description: สร้างโปรเจกต์ CapCut Desktop จากผลงานของ skill อื่น (cutplan + ซับไตเติล) — เปิด CapCut แล้วเจอโปรเจกต์พร้อมแก้ต่อทันที ใช้เมื่อผู้ใช้ขอ "ใส่เข้า CapCut", "สร้างโปรเจกต์", "เอาซับใส่ CapCut" หรือเป็นขั้นสุดท้ายของ pipeline ตัดต่อ
---

# capcut — สร้างโปรเจกต์ CapCut

## วิธีใช้

```bash
# เส้นทางหลัก: คลิปที่ตัดช่วงเงียบแล้ว + ซับ (style เลือกอัตโนมัติ: แนวตั้ง=bold, แนวนอน=clean)
python scripts/capcut_build.py --cutplan <work>/cutplan.json --srt <work>/captions.srt --name "<ชื่อโปรเจกต์>"

# คลิปพูดคนเดียวให้มีจังหวะ: ซูมสลับท่อน
python scripts/capcut_build.py --cutplan ... --srt ... --name "<ชื่อ>" --style vlog

# แค่ใส่ซับให้คลิปเดิม (ไม่ตัด)
python scripts/capcut_build.py --video <คลิป.mp4> --srt <work>/captions.srt --name "<ชื่อ>"
```

รายละเอียด preset ความสวย (clean/bold/vlog, สี, transition) อยู่ใน skill **style**

สคริปต์หาโฟลเดอร์ draft ของ CapCut อัตโนมัติ (Windows: `%LOCALAPPDATA%\CapCut\...` / macOS: `~/Movies/CapCut/...`)
ถ้าหาไม่เจอ ให้ผู้ใช้เปิด CapCut Desktop สักครั้ง หรือระบุ `--draft-folder` เอง

## กติกาสำคัญ

1. **ห้ามตั้งชื่อซ้ำกับโปรเจกต์จริงของผู้ใช้** — `allow_replace=True` จะทับโปรเจกต์เดิมชื่อเดียวกัน ตั้งชื่อใหม่เสมอ ยกเว้นผู้ใช้สั่งทับเอง
2. ทุกการตัดยังลาก/ยืดแก้ได้ใน CapCut (source_timerange ถูกเก็บครบ) — บอกผู้ใช้เสมอว่านี่คือ rough cut ให้รีวิวก่อน export
3. ขนาดโปรเจกต์แนวตั้ง (TikTok/Reels) ใช้ `--width 1080 --height 1920`
4. **เวลาซับถูก remap ให้ตรง timeline ที่ตัดแล้วอัตโนมัติ** (สร้าง `captions_timeline.srt`) — ห้าม import `captions.srt` ต้นฉบับเข้าโปรเจกต์ที่ตัดด้วย cutplan เอง เพราะเวลาจะเหลื่อม
5. **ฟอนต์ซับ**: ค่าเริ่มต้นพยายามใช้ LINE Seed Sans TH จากเครื่องผู้ใช้ (ถ้ายังไม่ติดตั้ง สคริปต์จะบอกลิงก์โหลดฟรี seed.line.me) — เปลี่ยนได้ด้วย `--font "<ชื่อฟอนต์>"` หรือ `--font none`
6. ซับถูกวางไว้ล่างจอ (transform_y=-0.75) ขนาด 8 — ตัวใหญ่ใช้ `--font-size 10`
7. ถ้า CapCut เปิดค้างอยู่ตอนสร้างโปรเจกต์ ให้ผู้ใช้ปิด-เปิดใหม่เพื่อรีเฟรชรายการโปรเจกต์
8. **อย่าลบ/ย้ายไฟล์วิดีโอต้นฉบับ** หลังสร้างโปรเจกต์ — CapCut อ้างอิง path เดิม

## CapCut Pro — ค่าเริ่มต้นคือ "export ได้ฟรี" (สำคัญต่อลูกค้า)

- **animation ซับ (คำเด้ง bounce/pop/glow) เป็นฟีเจอร์ CapCut Pro** — ถ้าใส่ ลูกค้าที่ไม่มี Pro จะเจอป๊อปอัพ "ฟีเจอร์ Pro" ตอน export
- **ค่าเริ่มต้นปิด animation Pro อัตโนมัติ** → โปรเจกต์ export ได้ฟรี ไม่มีป๊อปอัพ (karaoke ไฮไลต์สี + ซูมสลับท่อน + ฟอนต์ = ฟรีทั้งหมด)
- ลูกค้าที่มี CapCut Pro อยากได้ animation เด้ง → ใส่ `--allow-pro` (สคริปต์จะเตือนว่าต้องมี Pro)
- **บอกลูกค้าเสมอ**: ผลลัพธ์มาตรฐาน export ฟรีได้ ไม่ต้องสมัคร CapCut Pro
- ยังไม่ยืนยัน: ฉากหลังเบลอ (fit-mode blur, ใช้เฉพาะคลิปแนวนอน→ตั้งเกิน 1.6x) — ถ้าลูกค้าเจอป๊อปอัพจากอันนี้ให้ใช้ `--fit-mode fit` แทน

## Pipeline เต็มของ Dev-Cut Kit

```
analyze → transcribe → clean-cut → capcut  (+ cutout / find-assets ตามต้องการ) → handoff
```
