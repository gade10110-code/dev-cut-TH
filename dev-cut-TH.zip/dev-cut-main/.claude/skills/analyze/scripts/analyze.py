#!/usr/bin/env python3
"""Dev-Cut Kit - analyze: วิเคราะห์ footage ก่อนตัด — ข้อมูลไฟล์, ความดัง, ช่วงเงียบ, จุดเปลี่ยนฉาก
Usage:
  python analyze.py input.mp4 --out-dir work/
Output: analysis.json + สรุปอ่านง่ายทาง stdout
"""
import argparse, json, re, subprocess, sys
from pathlib import Path

import sys as _sys
if hasattr(_sys.stdout, "reconfigure"):  # กัน error ภาษาไทยบน Windows codepage
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace")



def ffprobe_info(src):
    r = subprocess.run(["ffprobe", "-v", "error", "-print_format", "json",
                        "-show_format", "-show_streams", src],
                       capture_output=True, text=True, check=True)
    data = json.loads(r.stdout)
    v = next((s for s in data["streams"] if s["codec_type"] == "video"), {})
    a = next((s for s in data["streams"] if s["codec_type"] == "audio"), {})
    fps = None
    if v.get("avg_frame_rate") and v["avg_frame_rate"] != "0/0":
        num, den = v["avg_frame_rate"].split("/")
        fps = round(float(num) / float(den), 3) if float(den) else None
    return {
        "duration": float(data["format"].get("duration", 0)),
        "size_mb": round(int(data["format"].get("size", 0)) / 1e6, 1),
        "video": {"codec": v.get("codec_name"), "width": v.get("width"),
                  "height": v.get("height"), "fps": fps},
        "audio": {"codec": a.get("codec_name"), "sample_rate": a.get("sample_rate"),
                  "channels": a.get("channels")},
    }


def loudness(src):
    r = subprocess.run(["ffmpeg", "-hide_banner", "-i", src, "-af",
                        "loudnorm=print_format=json", "-f", "null", "-"],
                       capture_output=True, text=True)
    m = re.search(r"\{[^{}]*\"input_i\"[^{}]*\}", r.stderr, re.S)
    if not m:
        return {}
    d = json.loads(m.group(0))
    return {"integrated_lufs": float(d.get("input_i", "nan")),
            "true_peak_db": float(d.get("input_tp", "nan"))}


def silences(src, noise_db=-35, min_dur=0.5):
    r = subprocess.run(["ffmpeg", "-hide_banner", "-i", src, "-af",
                        f"silencedetect=noise={noise_db}dB:d={min_dur}", "-f", "null", "-"],
                       capture_output=True, text=True)
    starts = [float(x) for x in re.findall(r"silence_start: ([\d.]+)", r.stderr)]
    ends = [float(x) for x in re.findall(r"silence_end: ([\d.]+)", r.stderr)]
    return [{"start": round(s, 2), "end": round(e, 2), "dur": round(e - s, 2)}
            for s, e in zip(starts, ends)]


def scene_changes(src, threshold=0.4):
    r = subprocess.run(["ffmpeg", "-hide_banner", "-i", src, "-vf",
                        f"select='gt(scene,{threshold})',metadata=print", "-an",
                        "-f", "null", "-"], capture_output=True, text=True)
    times = re.findall(r"pts_time:([\d.]+)", r.stderr)
    return [round(float(t), 2) for t in times]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("--out-dir", default=".")
    ap.add_argument("--noise-db", type=float, default=-35)
    ap.add_argument("--min-silence", type=float, default=0.5)
    ap.add_argument("--scene-threshold", type=float, default=0.4)
    args = ap.parse_args()

    out_dir = Path(args.out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    info = ffprobe_info(args.input)
    sil = silences(args.input, args.noise_db, args.min_silence)
    total_sil = round(sum(s["dur"] for s in sil), 1)
    result = {
        "source": str(Path(args.input).resolve()),
        "info": info,
        "loudness": loudness(args.input),
        "silences": sil,
        "silence_total_sec": total_sil,
        "scene_changes": scene_changes(args.input, args.scene_threshold),
    }
    (out_dir / "analysis.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")

    d = info["duration"]
    print(f"== Dev-Cut analyze ==")
    print(f"ไฟล์: {args.input}  ({info['size_mb']} MB)")
    print(f"ความยาว: {d:.1f}s | {info['video']['width']}x{info['video']['height']} "
          f"@{info['video']['fps']}fps | audio {info['audio']['codec']}")
    if result["loudness"]:
        print(f"ความดังเฉลี่ย: {result['loudness']['integrated_lufs']} LUFS "
              f"(เป้าหมาย YouTube ≈ -14)")
    print(f"ช่วงเงียบ: {len(sil)} ช่วง รวม {total_sil}s "
          f"({(total_sil/d*100 if d else 0):.0f}% ของคลิป) → clean-cut จะช่วยลดได้")
    print(f"จุดเปลี่ยนฉาก: {len(result['scene_changes'])} จุด")
    print(f"OK: {out_dir/'analysis.json'}")


if __name__ == "__main__":
    main()
