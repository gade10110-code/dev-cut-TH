# Third-party dependencies

Dev-Cut Kit เรียกใช้โครงการ open source เหล่านี้ (ติดตั้งผ่าน pip/ระบบ ไม่ได้แจกจ่ายรวมมาในตัว kit):

| โครงการ | ใช้ทำอะไร | License |
|---------|-----------|---------|
| [ffmpeg](https://ffmpeg.org) | ตัด/แปลง/วิเคราะห์วิดีโอ | LGPL/GPL |
| [pycapcut](https://github.com/GuanYixuan/pyCapCut) | สร้างไฟล์โปรเจกต์ CapCut | ตาม repo |
| [faster-whisper](https://github.com/SYSTRAN/faster-whisper) | ถอดเสียงฟรีออฟไลน์ | MIT |
| [rembg](https://github.com/danielgatis/rembg) | ลบพื้นหลัง | MIT |
| [requests](https://github.com/psf/requests) | เรียก API | Apache 2.0 |
| [Thonburian Whisper](https://github.com/biodatlab/thonburian-whisper) | โมเดลถอดเสียงไทย (โหลดจาก HuggingFace) | Apache 2.0 |
| [resvg-py](https://pypi.org/project/resvg-py/) | แปลงไอคอน SVG → PNG | MPL-2.0 |
| [Pillow](https://python-pillow.org) | สร้างกราฟิก | MIT-CMU |

**แจกจ่ายรวมมาใน kit:**

| อะไร | ที่มา | License |
|------|-------|---------|
| ไอคอน ~2,000 ตัวใน `icons/lucide/` | [Lucide](https://lucide.dev) | ISC (ใช้เชิงพาณิชย์ได้ ไฟล์ license แนบใน icons/lucide/) |
| เสียงทั้งหมดใน `sfx-pack/` | สังเคราะห์ขึ้นเองโดยสคริปต์ make_sfx.py | ลิขสิทธิ์ของเจ้าของ kit |

ฟอนต์แนะนำ (ผู้ใช้โหลดติดตั้งเอง ไม่ได้แจกรวม): [LINE Seed Sans TH](https://seed.line.me) — ฟรีสำหรับใช้งานทั่วไปตามเงื่อนไขของ LINE

บริการภายนอก (ผู้ใช้สมัครและถือ key เอง — ทั้งหมด optional):
ElevenLabs (ถอดเสียง), Pexels / Pixabay (asset ฟรี), Freesound (เสียงประกอบ)
แหล่งไม่ต้องมี key: Openverse, Wikimedia Commons

แรงบันดาลใจด้าน workflow: [hyperframes-helper](https://github.com/robonuggets/hyperframes-helper) โดย RoboNuggets (CC BY 4.0) — โค้ดทั้งหมดใน kit นี้เขียนขึ้นใหม่
