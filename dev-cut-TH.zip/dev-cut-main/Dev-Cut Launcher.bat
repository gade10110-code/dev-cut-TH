@echo off
rem Dev-Cut - double-click to open
cd /d "%~dp0"
start "" conhost.exe --headless powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0launcher\run.ps1"
