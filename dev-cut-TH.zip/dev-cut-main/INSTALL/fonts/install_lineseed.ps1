﻿# Dev-Cut Kit - ติดตั้งฟอนต์ LINE Seed Sans TH อัตโนมัติ (Windows, ไม่ต้องใช้สิทธิ์ admin)
# ฟอนต์เป็นของ LY Corporation แจกฟรีภายใต้ SIL Open Font License 1.1 — ดาวน์โหลดจากเว็บทางการ
$ErrorActionPreference = "Stop"
$FontsDir = "$env:LOCALAPPDATA\Microsoft\Windows\Fonts"
$RegPath = "HKCU:\Software\Microsoft\Windows NT\CurrentVersion\Fonts"

# มีอยู่แล้ว?
$existing = @(Get-ChildItem "$FontsDir", "C:\Windows\Fonts" -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -replace '\s','' -match 'LINESeed.*TH' })
if ($existing.Count -gt 0) {
    Write-Host "-> LINE Seed Sans TH ติดตั้งอยู่แล้ว ($($existing.Count) ไฟล์)" -ForegroundColor Green
    exit 0
}

Write-Host "-> ดาวน์โหลด LINE Seed Sans TH จาก seed.line.me ..."
$tmp = Join-Path $env:TEMP "lineseed_th"
New-Item -ItemType Directory -Force -Path $tmp | Out-Null
$zip = Join-Path $tmp "LINE_Seed_Sans_TH.zip"
Invoke-WebRequest -Uri "https://seed.line.me/src/images/fonts/LINE_Seed_Sans_TH.zip" -OutFile $zip
Expand-Archive -Path $zip -DestinationPath $tmp -Force

# เลือกไฟล์ TTF ก่อน (ถ้าไม่มีใช้ OTF) ข้ามพวก webfont
$files = @(Get-ChildItem $tmp -Recurse -Include *.ttf | Where-Object { $_.FullName -notmatch 'web' })
if ($files.Count -eq 0) { $files = @(Get-ChildItem $tmp -Recurse -Include *.otf | Where-Object { $_.FullName -notmatch 'web' }) }
if ($files.Count -eq 0) { Write-Host "ไม่พบไฟล์ฟอนต์ใน zip — โครงสร้างไฟล์อาจเปลี่ยน ลองติดตั้งเองจาก seed.line.me" -ForegroundColor Yellow; exit 1 }

New-Item -ItemType Directory -Force -Path $FontsDir | Out-Null
if (-not (Test-Path $RegPath)) { New-Item -Path $RegPath -Force | Out-Null }
foreach ($f in $files) {
    $dest = Join-Path $FontsDir $f.Name
    Copy-Item $f.FullName $dest -Force
    $suffix = if ($f.Extension -eq ".otf") { "(OpenType)" } else { "(TrueType)" }
    New-ItemProperty -Path $RegPath -Name "$($f.BaseName) $suffix" -Value $dest -PropertyType String -Force | Out-Null
    Write-Host "   + $($f.Name)"
}
Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "-> ติดตั้งฟอนต์เสร็จ ($($files.Count) ไฟล์) — โปรแกรมที่เปิดค้างอยู่ต้องปิด-เปิดใหม่ถึงเห็นฟอนต์" -ForegroundColor Green
