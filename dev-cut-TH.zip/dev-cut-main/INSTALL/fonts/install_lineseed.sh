#!/bin/bash
# Dev-Cut Kit - ติดตั้งฟอนต์ LINE Seed Sans TH อัตโนมัติ (macOS)
# ฟอนต์เป็นของ LY Corporation แจกฟรีภายใต้ SIL Open Font License 1.1 — ดาวน์โหลดจากเว็บทางการ
set -e
FONTS_DIR="$HOME/Library/Fonts"

if ls "$FONTS_DIR" 2>/dev/null | grep -qi "LINESeed.*TH"; then
  echo "-> LINE Seed Sans TH ติดตั้งอยู่แล้ว"
  exit 0
fi

echo "-> ดาวน์โหลด LINE Seed Sans TH จาก seed.line.me ..."
TMP=$(mktemp -d)
curl -sL -o "$TMP/lineseed.zip" "https://seed.line.me/src/images/fonts/LINE_Seed_Sans_TH.zip"
unzip -qo "$TMP/lineseed.zip" -d "$TMP"

mkdir -p "$FONTS_DIR"
FILES=$(find "$TMP" -iname "*.ttf" ! -ipath "*web*")
[ -z "$FILES" ] && FILES=$(find "$TMP" -iname "*.otf" ! -ipath "*web*")
if [ -z "$FILES" ]; then
  echo "ไม่พบไฟล์ฟอนต์ใน zip — ลองติดตั้งเองจาก seed.line.me"
  exit 1
fi
echo "$FILES" | while read -r f; do
  cp "$f" "$FONTS_DIR/"
  echo "   + $(basename "$f")"
done
rm -rf "$TMP"
echo "-> ติดตั้งฟอนต์เสร็จ — โปรแกรมที่เปิดค้างอยู่ต้องปิด-เปิดใหม่ถึงเห็นฟอนต์"
