#!/bin/bash
# Dev-Cut Kit - ตัวติดตั้งสำหรับ macOS
set -e
cd "$(dirname "$0")/../.."
echo "== Dev-Cut Kit installer (macOS) =="

# 1. Homebrew + ffmpeg
if ! command -v ffmpeg >/dev/null 2>&1; then
  if ! command -v brew >/dev/null 2>&1; then
    echo "ไม่พบ Homebrew — ติดตั้งก่อนที่ https://brew.sh แล้วรันสคริปต์นี้ใหม่"
    exit 1
  fi
  echo "-> ติดตั้ง ffmpeg ..."
  brew install ffmpeg
else
  echo "-> ffmpeg มีแล้ว ✓"
fi

# 2. Python
if ! command -v python3 >/dev/null 2>&1; then
  echo "ไม่พบ Python 3 — ติดตั้งด้วย: brew install python@3.12"
  exit 1
fi
echo "-> Python: $(python3 --version) ✓"

# 3. Python packages (ใน virtualenv ของ kit เอง)
echo "-> สร้าง virtualenv และติดตั้ง packages ..."
python3 -m venv .venv
./.venv/bin/pip install -q --upgrade pip
./.venv/bin/pip install -q -r requirements.txt
echo "-> packages ✓  (เรียกใช้สคริปต์ด้วย ./.venv/bin/python)"

# 4. .env
if [ ! -f .env ]; then
  cp .env.example .env
  echo "-> สร้าง .env แล้ว (ไม่ใส่ key ก็ใช้งานได้)"
fi

# 5. ฟอนต์ LINE Seed Sans TH (ฟอนต์มาตรฐานของ kit)
bash "$(dirname "$0")/../fonts/install_lineseed.sh" || \
  echo "-> ติดตั้งฟอนต์ไม่สำเร็จ (ข้ามได้) — ติดตั้งเองที่ seed.line.me"

echo ""
echo "== ติดตั้งเสร็จ! =="
echo "ขั้นต่อไป: เปิดโฟลเดอร์นี้ใน Claude Code แล้วเริ่มสั่งงานได้เลย"
