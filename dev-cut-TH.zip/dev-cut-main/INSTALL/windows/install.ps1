﻿# Dev-Cut Kit - ตัวติดตั้งสำหรับ Windows (PowerShell)
$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "..\..")
Write-Host "== Dev-Cut Kit installer (Windows) ==" -ForegroundColor Cyan

# 1. ffmpeg (ผ่าน winget)
if (-not (Get-Command ffmpeg -ErrorAction SilentlyContinue)) {
    Write-Host "-> ติดตั้ง ffmpeg ผ่าน winget ..."
    winget install --id Gyan.FFmpeg -e --accept-source-agreements --accept-package-agreements
    Write-Host "   (ถ้าเพิ่งติดตั้ง อาจต้องปิด-เปิด PowerShell ใหม่ให้ ffmpeg เข้า PATH)"
} else {
    Write-Host "-> ffmpeg มีแล้ว" -ForegroundColor Green
}

# 2. Python
if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    Write-Host "-> ติดตั้ง Python ผ่าน winget ..."
    winget install --id Python.Python.3.12 -e --accept-source-agreements --accept-package-agreements
    Write-Host "   ปิด-เปิด PowerShell ใหม่ แล้วรันสคริปต์นี้อีกครั้ง"
    exit
}
Write-Host "-> Python: $(python --version)" -ForegroundColor Green

# 3. Python packages (virtualenv ของ kit)
Write-Host "-> สร้าง virtualenv และติดตั้ง packages ..."
python -m venv .venv 2>&1 | Out-Host
$venvPy = ".\.venv\Scripts\python.exe"
if (Test-Path $venvPy) {
    & $venvPy -m ensurepip --upgrade 2>$null | Out-Null
    & $venvPy -m pip install -q --upgrade pip
    & $venvPy -m pip install -q -r requirements.txt
    Write-Host "-> packages เสร็จ (เรียกสคริปต์ด้วย .\.venv\Scripts\python.exe)" -ForegroundColor Green
} else {
    Write-Host "-> สร้าง virtualenv ไม่สำเร็จ — ติดตั้งลง Python หลักแทน (ใช้งานได้เหมือนกัน)" -ForegroundColor Yellow
    python -m pip install -q --user -r requirements.txt
    Write-Host "-> packages เสร็จ (เรียกสคริปต์ด้วย python)" -ForegroundColor Green
}

# 4. .env
if (-not (Test-Path ".env")) {
    Copy-Item ".env.example" ".env"
    Write-Host "-> สร้าง .env แล้ว (ไม่ใส่ key ก็ใช้งานได้)" -ForegroundColor Yellow
}

# 5. ฟอนต์ LINE Seed Sans TH (ฟอนต์มาตรฐานของ kit)
try {
    & powershell -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot "..\fonts\install_lineseed.ps1")
} catch {
    Write-Host "-> ติดตั้งฟอนต์ไม่สำเร็จ (ข้ามได้ ไม่กระทบการใช้งาน) — ติดตั้งเองที่ seed.line.me" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "== ติดตั้งเสร็จ! ==" -ForegroundColor Cyan
Write-Host "ขั้นต่อไป: เปิดโฟลเดอร์นี้ใน Claude Code แล้วเริ่มสั่งงานได้เลย"
